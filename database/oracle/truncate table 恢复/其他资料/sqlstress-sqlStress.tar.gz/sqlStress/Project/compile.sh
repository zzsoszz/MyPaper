export CLASSPATH=$CLASSPATH:./ojdbc14_g.jar:.
javac -d . functionConfig.java >> compile.log
javac -d . XMLReader.java >> compile.log
javac -d . connThread.java >> compile.log
javac -d . TestStress.java > compile.log
#rm sqlstress.jar
#jar cvfm sqlstress.jar manifest.mf teststress
jar uvf sqlstress.jar manifest.mf teststress
