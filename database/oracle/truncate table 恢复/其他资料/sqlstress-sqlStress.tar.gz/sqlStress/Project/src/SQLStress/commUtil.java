package SQLStress;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class commUtil 
{
  public static FileWriter fwLog; // log file writer
  public static boolean isTrialVersion = true; // is this a trial version
  public static int trialLimit = 5; // is this a trial version
  public static String versionNum = "v1.12";
  public static String versionInfo = "SQL Stress. Version: "+versionNum+" \n"+"By: HuangWei. ";  // version information

  public commUtil()
  {
    // initialize log file
    try{
      DateFormat logDateFormat = new SimpleDateFormat("yyyyMMdd_kkmmss"); //ʱ���ʽ
      String logFile = "sqlstress" + logDateFormat.format(new java.util.Date()) + ".log";
      fwLog = new FileWriter(logFile, true);
    }
    catch (Exception e){
      System.out.println("ERROR: "+e.getMessage());
    }
  }

  public static void log(String logMessage)
  {
    try
    {
      System.out.println(logMessage);
      fwLog.write(logMessage + "\n");
      fwLog.flush();
    }
    catch (IOException ex){
      System.out.println("ERROR: "+" Write log file failed!");
      System.out.println(ex.getMessage());
    }
  }
  
  public void sayGoodBy()
  {
    // close log file
    try
    {
      fwLog.close();
    }
    catch (IOException e)
    {
      System.out.println("ERROR: Close Log file failed!");
      System.out.println(e.getMessage());
    }
  }
}