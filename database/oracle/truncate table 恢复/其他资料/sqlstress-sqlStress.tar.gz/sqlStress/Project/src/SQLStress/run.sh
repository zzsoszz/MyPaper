#java teststress.TestStress
#java -jar sqlstress.jar
java -jar sqlstress.jar
