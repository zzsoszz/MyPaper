//Source File Name:   cryptoTest.java 
import java.io.*; 
import java.lang.reflect.Method; 
import java.security.GeneralSecurityException; 
import java.security.SecureRandom; 
import java.util.Enumeration; 
import java.util.Hashtable; 
import java.util.zip.*; 
import javax.crypto.*;  //javax.crypto?1.4.0??????,???? 
import javax.crypto.spec.DESKeySpec; 
public class cryptoTest extends ClassLoader 
{ 

   private Hashtable htSizes; 
   private Hashtable htJarContents; 
   private String jarFileName; 
   private SecretKey key; 
   private Cipher cipher; 

   public cryptoTest(SecretKey secretkey, String s) 
       throws GeneralSecurityException, IOException 
   { 
       htSizes = new Hashtable(); 
       htJarContents = new Hashtable(); 
       key = secretkey; 
       jarFileName = s; 
       String s1 = "DES"; 
       SecureRandom securerandom = new SecureRandom(); 
       cipher = Cipher.getInstance(s1);//???? 
       cipher.init(2, secretkey, securerandom); 
       initvalue(s + ".jar"); 
   } 
   
   

   public static void main(String args[]) 
       throws Exception 
   { 
       String s = args[1]; 
       String s1 = args[2]; 
       String args1[] = new String[args.length - 3]; 
       System.arraycopy(args, 3, args1, 0, args.length - 3); 
       byte abyte0[];
       //byte abyte0[] = Util.readFile(s); 
       DESKeySpec deskeyspec = new DESKeySpec(abyte0); 
       SecretKeyFactory secretkeyfactory = SecretKeyFactory.getInstance("DES"); 
       SecretKey secretkey = secretkeyfactory.generateSecret(deskeyspec); 
       cryptoTest cryptoTest = new cryptoTest(secretkey, s1); 
       Class class1 = cryptoTest.loadClass(s1); 
       String args2[] = new String[1]; 
       Class aclass[] = { 
           (new String[1]).getClass() 
       }; 
       Method method = class1.getMethod("main", aclass); 
       Object aobj[] = { 
           args1 
       }; 
       method.invoke(null, aobj); 
   } 

   private void initvalue(String s) 
   { 
       try 
       { 
           ZipFile zipfile = new ZipFile(s); 
           ZipEntry zipentry; 
           for(Enumeration enumeration = zipfile.entries(); enumeration.hasMoreElements();  

htSizes.put(zipentry.getName(), new Integer((int)zipentry.getSize()))) 
               zipentry = (ZipEntry)enumeration.nextElement(); 

           zipfile.close(); 
           FileInputStream fileinputstream = new FileInputStream(s); 
           BufferedInputStream bufferedinputstream = new BufferedInputStream(fileinputstream); 
           ZipInputStream zipinputstream = new ZipInputStream(bufferedinputstream); 
           for(ZipEntry zipentry1 = null; (zipentry1 = zipinputstream.getNextEntry()) != null;) 
               if(!zipentry1.isDirectory()) 
               { 
                   int i = (int)zipentry1.getSize(); 
                   if(i == -1) 
                       i = ((Integer)htSizes.get(zipentry1.getName())).intValue(); 
                   byte abyte0[] = new byte[i]; 
                   int j = 0; 
                   boolean flag = false; 
                   int k; 
                   for(; i - j > 0; j += k) 
                   { 
                       k = zipinputstream.read(abyte0, j, i - j); 
                       if(k == -1) 
                           break; 
                   } 

                   htJarContents.put(zipentry1.getName(), abyte0); 
               } 

       } 
       catch(NullPointerException nullpointerexception) 
       { 
           nullpointerexception.printStackTrace(); 
       } 
       catch(FileNotFoundException filenotfoundexception) 
       { 
           filenotfoundexception.printStackTrace(); 
       } 
       catch(IOException ioexception) 
       { 
           ioexception.printStackTrace(); 
       } 
   } 

   public byte[] getJarResource(String s) 
   { 
       return (byte[])htJarContents.get(s); 
   } 

   public Class loadClass(String s, boolean flag) 
       throws ClassNotFoundException 
   { 
       try 
       { 
           Class class1 = null; 
           class1 = findLoadedClass(s); 
           if(class1 != null) 
               return class1; 
           byte abyte0[] = getJarResource(s + ".class"); 
           if(abyte0 != null) 
           { 
               byte abyte1[] = cipher.doFinal(abyte0); 
               class1 = defineClass(s, abyte1, 0, abyte1.length); 
           } 
           if(class1 == null) 
               class1 = findSystemClass(s); 
           if(flag && class1 != null) 
               resolveClass(class1); 
           return class1; 
       } 
       catch(GeneralSecurityException generalsecurityexception) 
       { 
           throw new ClassNotFoundException(generalsecurityexception.toString()); 
       } 
   } 
} 
