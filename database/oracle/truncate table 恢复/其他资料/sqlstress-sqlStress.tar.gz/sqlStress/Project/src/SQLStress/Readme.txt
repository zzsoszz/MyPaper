Requirement: 
java 1.4.2.09 or up

Set up:
in windows:
set CLASSPATH=%CLASSPATH%;.;<ORACLE_HOME>\jdbc\lib;<ORACLE_HOME>\jdbc\lib\ojdbc14_g.jar
in unix:
export CLASSPATH=$CLASSPATH:.:<ORACLE_HOME>\jdbc\lib:<ORACLE_HOME>\jdbc\lib\ojdbc14_g.jar
where <ORACLE_HOME> is the Oracle home directory.

to test the demo:
1. execute the demo.sql
2. config the init.xml follow its comments.
3. run the SQLStress.bat


WARNING: Strong suggest do NOT run SQLStres in the host which running your Oralce!
WARNING: SQLStress may general high stress, be careful when you using it. 

The trial version limit 5 functions, and 5 threads of each function.

Manual:
1. Config init.xml file follow the comments;
2. run SQLStress.exe
