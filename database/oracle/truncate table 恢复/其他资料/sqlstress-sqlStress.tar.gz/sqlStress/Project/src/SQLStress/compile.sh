javac -d . functionConfig.java
javac -d . XMLReader.java
javac -d . connThread.java
javac -d . TestStress.java
del sqlstress.jar
rm  sqlstress.jar
jar cvfm sqlstress.jar manifest.mf ojdbc14_g.jar SQLStress

#jar cmf manifest.mf sqlstress.jar ojdbc14_g.jar SQLStress