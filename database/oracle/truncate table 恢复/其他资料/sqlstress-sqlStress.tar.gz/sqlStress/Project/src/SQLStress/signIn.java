package SQLStress;

import java.io.IOException;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.security.spec.RSAPublicKeySpec;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.InvalidKeyException;
import java.security.SignatureException;
import java.security.spec.RSAKeyGenParameterSpec;

import java.sql.*;
import oracle.jdbc.driver.OracleDriver;

/**
 * This is a command line utility that accepts an RSA key file name,
 * a file name and a signature file name on the command line that are
 * used to verify that the signature is for the file and supplied
 * public key.
 */
public class signIn {
  private String connURL;
  private String dbName;
  private String dbPWD;
  private String eMail;
  private String versionNum;

  /**
  * No instance of SignFile is actually created.
  */
  public signIn (String connURL, String dbName, String dbPWD, String eMail, String versionNum) {
    this.connURL = connURL;
    this.dbName = dbName;
    this.dbPWD = dbPWD;
    this.eMail = eMail;
    this.versionNum = versionNum;
  }
  
  private String getDBID()
  {
    String dbID = null;
    Connection conn = null;
    Statement querySQL = null;
    ResultSet rs = null;
    
    try
    {
      DriverManager.registerDriver(new OracleDriver());
  
      //��������
      conn = DriverManager.getConnection(connURL, dbName, dbPWD);
      querySQL = conn.createStatement();
      querySQL.execute("select dbid from v$database");
      rs = querySQL.getResultSet();
      
      if (rs.next())
      {
        dbID = rs.getString(1);
      }
      else
      {
        log("ERROR: get database id error!");
        dbID = "";
      }

      if (rs != null)
        rs.close();
      if (querySQL != null)
        querySQL.close();
      if (conn != null)
        conn.close();
    }
    catch (SQLException e)
    {
      log("ERROR: connect to database failed!");
      log(e.getMessage());
      System.exit(1);
      dbID = "";
    }
    finally
    {
    }

    return dbID;
  }
  
  public boolean checkIn(){
    KeyFactory keyFactory = null;
    PublicKey publicKey = null;
    Signature signer = null;
  
    try
    {
      RawRSAKey rawKey = RawRSAKey.getInstance("licence.key");
      RSAPublicKeySpec publicSpec = new RSAPublicKeySpec(rawKey.getModulus(), rawKey.getExponent());

      keyFactory = KeyFactory.getInstance("RSA");
      publicKey = keyFactory.generatePublic(publicSpec);
      signer = Signature.getInstance("MD5withRSA");
      signer.initVerify(publicKey);
    }
    catch(NoSuchAlgorithmException noAlgorithm) {
      log("ERROR: signature invalid. Please check if the DBID and Email are the ones you rigistered.");
//      System.out.println(noAlgorithm);
      return false;
    }
    catch(InvalidKeySpecException badSpec) {
      log("ERROR: signature invalid. Please check if the DBID and Email are the ones you rigistered.");
//      System.out.println(badSpec);
      return false;
    }
    catch(InvalidKeyException badKey) {
      log("ERROR: signature invalid. Please check if the DBID and Email are the ones you rigistered.");
//      System.out.println(badKey);
      return false;
    }
    catch(IOException e)
    {
      log("ERROR: licence.key file read error! please put your licence.key file under the same folder of SQLStress!");
      log(e.getMessage());
      return false;
    }
    
    
    String singatureString = eMail+"-"+versionNum+"-"+getDBID();
    
    byte[] fileData = singatureString.getBytes();
    try {
      signer.update(fileData, 0, singatureString.length());
    }
    catch (SignatureException signError) {
      log("ERROR: signature invalid. Please check if the DBID and Email are the ones you rigistered.");
      return false;
    }

    ByteArrayOutputStream theSignature = new ByteArrayOutputStream(2000);
    
    try
    {
      FileInputStream signatureIn = new FileInputStream("licence.sig");
      byte[] signatureData = new byte[100];
      int numberSignatureBytesRead = 0;
      do {
        if ( numberSignatureBytesRead > 0 ) {
          theSignature.write(signatureData, 0, numberSignatureBytesRead);
        }
        numberSignatureBytesRead = signatureIn.read(signatureData);
      } while ( numberSignatureBytesRead != -1 );
      signatureIn.close();
    }
    catch(IOException e)
    {
      log("ERROR: licence.key file read error! please put your licence.key file under the same folder of SQLStress!");
      log(e.getMessage());
      return false;
    }
    
    
    boolean signatureVerified = false;
    try {
      signatureVerified = signer.verify(theSignature.toByteArray());
    }
    catch (SignatureException signError) {
      log("ERROR: signature invalid. Please check if the DBID and Email are the ones you rigistered.");
//      System.out.println(signError);
      return  false;
    }
    
    System.out.println("===========================================================");
    if ( signatureVerified ) {
//      System.out.println("The signature is valid for the file.");
      return true;
    }
    else {
      log("ERROR: licence ERROR. Please check if the DBID and Email are the ones you rigistered.");
      return false;
    }
  }

  private void log(String logMessage)
  {
    commUtil.log(logMessage);
  }
}
