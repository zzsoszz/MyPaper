package SQLStress;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class TestStress {
  XMLReader initXMLReader = new XMLReader();//xml��ȡ��
  int funcNum;//��������
  connThread Threads[][] = new connThread[100][100];//�߳�
  String initFile = null;//��ʼ���ļ�

  private long beginExecTime; // the time when start stress
  private boolean hasInitThreads=false; // flag to check if has initialized threads
  private boolean hasPaused = false; // if SQLStress process has been paused

  public TestStress(String iFile){
    initFile = iFile;
    doExitApplication();
  }

  // for anti crack
  public static Throwable fake(Throwable throwable, Throwable throwable1)
  {
    try
    {
      throwable.getClass().getMethod("initCause", new Class[] 
      {
        java.lang.Throwable.class
      }).invoke(throwable, new Object[] {
        throwable1
      });
    }
    catch(Exception exception) { }
    return throwable;
  }
  
  //��׽�����˳��¼���
  private void doExitApplication()
  {
    Runtime.getRuntime().addShutdownHook(new Thread() {
      public void run() 
      {
        try
        {
          if (hasInitThreads)
          {
            long wholeFuncExecutions = 0;
            long wholeTotalCaps = 0;
            long wholeFuncSuccess = 0;
            long wholeFuncFail = 0;
            float wholeFuncSuccessRatio = 0;
            long wholeFuncexecTime = 0;
  
            for (int j = 0; j < 100; j++) {
              if (initXMLReader.funConfig[j] != null &&
                  initXMLReader.funConfig[j].hasConfiged)
              {
                int i = 0;
                long totalFuncExecutions = 0;
                long totalFuncexecTime = 0;
                String totalFuncexecTimeFormat = null;
                float totalFuncCaps = 0;
                long totalFuncSuccess = 0;
                long totalFuncFail = 0;
                float totalFuncSuccessRatio = 0;
    
                do {
                  Threads[j][i].endThread();
    
                  totalFuncExecutions = Threads[j][i].execNum;
                  log(Threads[j][i].ThreadName + " Total Executions=" +
                                     Threads[j][i].execNum);
    
                  totalFuncexecTime = totalFuncexecTime = Threads[j][i].wholeExecTime;
                  log(Threads[j][i].ThreadName +
                                     " whole execute time=" +
                                     Threads[j][i].wholeExecTimeFormat);
                  totalFuncCaps = totalFuncCaps + (float)Threads[j][i].execNum * 1000 /
                           (float)Threads[j][i].wholeExecTime;
                  log(Threads[j][i].ThreadName + " Caps=" +
                                     (float)Threads[j][i].execNum * 1000 /
                                     (float)Threads[j][i].wholeExecTime);
    
                  totalFuncSuccess = totalFuncSuccess + Threads[j][i].successful;
                  log(Threads[j][i].ThreadName + " sussful=" +
                                     Threads[j][i].successful);
    
                  totalFuncFail = totalFuncFail + Threads[j][i].fail;
                  log(Threads[j][i].ThreadName + " fail=" +
                                     Threads[j][i].fail);
    
                  log(Threads[j][i].ThreadName +
                                     " sucessful/total=" +
                                     Threads[j][i].successRatio);
    
                  i++;
                }
                while (i < initXMLReader.funConfig[j].threadNum);
    
                totalFuncexecTimeFormat = formatTimeMillis(totalFuncexecTime);
                
                if (totalFuncExecutions > 0)
                  totalFuncSuccessRatio = (float)totalFuncSuccess/totalFuncExecutions;
    
                log(initXMLReader.funConfig[j].functionName + " Total Executions=" +
                                   totalFuncExecutions);
    
                log(initXMLReader.funConfig[j].functionName +
                                   " whole execute time=" +
                                   totalFuncexecTimeFormat);
    
                log(initXMLReader.funConfig[j].functionName + " Caps=" +
                                   totalFuncCaps);
    
                log(initXMLReader.funConfig[j].functionName + " sussful=" +
                                   totalFuncSuccess);
    
                log(initXMLReader.funConfig[j].functionName + " fail=" +
                                   totalFuncFail);
    
                log(initXMLReader.funConfig[j].functionName +
                                   " sucessful/total=" +
                                   totalFuncSuccessRatio);
                
                // compute whole statistics
                wholeFuncExecutions = wholeFuncExecutions + totalFuncExecutions;
                wholeFuncSuccess = wholeFuncSuccess + totalFuncSuccess;
                wholeFuncFail = wholeFuncFail + totalFuncFail;
              }
            }
            log("whole statistics:");
            wholeFuncexecTime = System.currentTimeMillis() - beginExecTime;
            log("Execution Time: " + formatTimeMillis(wholeFuncexecTime));
            log("Caps= " + (float)wholeFuncExecutions * 1000/wholeFuncexecTime);
            log("sum of sussfuls = " + wholeFuncSuccess);
            log("sum of fails = " + wholeFuncFail);
            if (wholeFuncExecutions > 0)
              wholeFuncSuccessRatio = (float)wholeFuncSuccess/wholeFuncExecutions;
            log("sucessful/total=" + wholeFuncSuccessRatio);
          }
        }
        catch (Exception ex){
          log("ERROR: "+ex.getMessage());
        }

        //�˳�J������ʾ
        log("Stress end!!!");
      }
    });
  }
  
  private String inputMail()
  {
    System.out.println("");
    System.out.println("");
    System.out.print("Please input your email registered: ");
    return getInputCommand().toLowerCase();
  }
  
  // read email from file
  private String readMailFromFile()
  {
    String eMail;
    try
    {
      BufferedReader emailReader = new BufferedReader(new FileReader("conf.raw"));
      if (emailReader != null)
      {
        eMail = emailReader.readLine();
        emailReader.close();
      }
      else
        return inputMail();
      
      if (eMail == null || eMail.equalsIgnoreCase(""))
        return inputMail();
      else
        return eMail.trim().toLowerCase();
    }
    catch (IOException e)
    {
      return inputMail();
    }
  }

  // write email to file
  private void writeMailToFile(String eMail)
  {
    try
    {
      FileWriter fw = new FileWriter("conf.raw");
      fw.write(eMail);
      fw.close();
    }
    catch (IOException e)
    {
    }
    
    return;
  }

  // initialize stress process
  public void initStress()
  {
    log(commUtil.versionInfo);
    
    System.out.println();

    initXML();
    initXMLReader.readConnConfig(); // get the connect inform
    
    String eMail = readMailFromFile();
    signIn si = new signIn(initXMLReader.connURL, initXMLReader.userName,
                           initXMLReader.userPWD, eMail, commUtil.versionNum);
    writeMailToFile(eMail);
    
    // check licence
    if (!si.checkIn())
    {
      log("ERROR: Licence invalid or unmatch your version!");
      log("       You can just try the trial version, with limit 5 functions and 5 threads per function.");
      commUtil.isTrialVersion = true;
      try
      {
        Thread.currentThread().sleep(2000);
      }
      catch (InterruptedException e)
      {
      }
    }
    else
        commUtil.isTrialVersion = false;

    log("begin initialize stress process ...");

    // get the functions' config
    initXMLReader.readFunctionConfig();
    funcNum = initXMLReader.funcNum;

    initAllThreads();
    log("init end!");
  }

  //��ȡ��ʼ���ļ�
  protected void initXML()
  {
    try {
      initXMLReader.init(initFile); //��ʼ��XML�ļ���ȡ��
    }
    catch (Exception e) {
      System.out.println("ERROR: "+"init xml file:"+initFile+" failed!");
      System.out.println(e.getMessage());
    }
  }
  
  // initialize one function's threads
  protected void initFuncThreads(int funID)
  {
    int i = 0;
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      do {
        Threads[funID][i] = new connThread(initXMLReader.funConfig[funID].
                                              functionName + " Thread" + i + 1,
                                              i, initXMLReader, funID);
        log(initXMLReader.funConfig[funID].functionName +
                           " init thread " + i);
        Threads[funID][i].init(commUtil.fwLog);

        i++;
      }
      while (i < initXMLReader.funConfig[funID].threadNum);
    }
  }

  //��ʼ���߳�
  protected void initAllThreads()
  {
    hasInitThreads = true;
    beginExecTime = System.currentTimeMillis();
    
    for (int j = 0; j < 100; j++) {
      initFuncThreads(j);
    }
  }

  // start stress process
  public void startStress()
  {
    log("Starting stress");
    startAllThreads();
    log("Stress has been startup");
  }
  
  // start one function's threads
  protected void startFuncThreads(int funID)
  {
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      int i = 0;
      do {
        if (Threads[funID][i] != null)
        {
          Threads[funID][i].start();
          log(initXMLReader.funConfig[funID].functionName +
                             " start thread " + i);
        }

        i++;
      }
      while (i < initXMLReader.funConfig[funID].threadNum);
    }
  }

  //�����߳�
  protected void startAllThreads()
  {
    for (int j = 0; j < 100; j++) {
      startFuncThreads(j);
    }
  }
  
  // stop stress process
  public void stopStress()
  {
    log("begein stop stress process...");
    interruptAllThreads();
    log("Stress process has been shutdown!\n");
  }
  
  // interrupt one function's threads
  protected void interruptFuncThreads(int funID)
  {
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      int i = 0;
      do {
        if (Threads[funID][i] != null)
        {
          if (!Threads[funID][i].isStop)
          {
            Threads[funID][i].interrupt();
          }

          log(initXMLReader.funConfig[funID].functionName +
                             " stop thread " + i);
        }

        i++;
      }
      while (i < initXMLReader.funConfig[funID].threadNum);
    }
  }

  // interrupt the stresss threads  
  protected void interruptAllThreads()
  {
    for (int j = 0; j < 100; j++) {
      interruptFuncThreads(j);
    }
  }

  public static void main(String args[]) { //throws SQLException
  
    try
    {
      int threadIndex = 0;
  //    int funcNum = 0;
  //    connThread Threads[] = new connThread[1000];
  //    XMLReader initXMLReader = new XMLReader();
  
      //��ȡ��ʼ���ļ�
      String initFile = null;
      if (args.length < 1) {
        initFile = "init.xml";
      }
      else {
        initFile = args[0];
      }
  
      TestStress sqlStress = new TestStress(initFile);
  
      commUtil cu = new commUtil();
  
      sqlStress.initStress();//��ʼ���������߳�
      sqlStress.startStress();//�����߳�
      
      sqlStress.commandLine();
  
      cu.sayGoodBy();
    }
    catch (Exception e)
    {
      IllegalArgumentException illegalargumentexception = new IllegalArgumentException(e.toString());
      fake(illegalargumentexception, e);
      throw illegalargumentexception;
    }
  }

  public static void log(String logMessage)
  {
    commUtil.log(logMessage);
  }
  
  // format the time in milli-senconds
  private String formatTimeMillis(long timeMillis)
  {
    String formattedTime = new String();
    formattedTime = (int) timeMillis / (3600 * 1000) + " hours, " +
                                   (int) ( (timeMillis -
                                            ( (long) timeMillis / (3600 * 1000)) *
                                            3600 * 1000) / 60000) + " mins, " +
                                   (int) ( (timeMillis -
                                            ( (long) timeMillis / 60000) * 60000) /
                                          1000) + "secs, " +
                                   (int) (timeMillis -
                                          ( (long) timeMillis / 1000) * 1000) +
                                   " ms.";
    return formattedTime;
  }
  
  private void commandLine()
  {
    System.out.print("SQLStress CMD>");
    while (true)
    {
      parseCMD(getInputCommand());
      System.out.print("SQLStress CMD>");
    }
  }
  
  private String[] splitCommand(String initialCommand)
  {
    Pattern pSplit = Pattern.compile("[\\\\ ]+");
    String[] splittedCommand = pSplit.split(initialCommand);
    return splittedCommand;
  }
  
  private String getInputCommand()
  {
    String inputCommand= "";
    try
    {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in),1); 
      inputCommand = br.readLine();
    }
    catch (IOException e)
    {
      System.out.println("ERROR: Read command failed!");
      System.out.println(e.getMessage());
    }

    return inputCommand.trim();
  }
  
  private boolean parseYesOrNo()
  {
    boolean commandCorrect = false;
    while (!commandCorrect)
    {
      String inputString = getInputCommand();
      if (inputString == null || 
          inputString.equalsIgnoreCase("") ||
          inputString.equalsIgnoreCase("No") ||
          inputString.equalsIgnoreCase("N"))
      {
        commandCorrect = true;
        return false;
      }

      if (inputString.equalsIgnoreCase("Yes") ||
          inputString.equalsIgnoreCase("Y"))
      {
        commandCorrect = true;
        return true;
      }
      
      System.out.println("");
      System.out.print("Please input Y(es) or N(o)! >");
    }
    
    return false;
  }
  
  private void listAllFunctions()
  {
    for (int j = 0; j < 100; j++) {
      if (initXMLReader.funConfig[j] != null && initXMLReader.funConfig[j].hasConfiged)
      {
        System.out.println("  function ID  : " + j);
        System.out.println("  function Name: " + initXMLReader.funConfig[j].functionName);
      }
    }
  }
  
  private void ListFunctionInform(int functionID)
  {
    if (initXMLReader.funConfig[functionID] != null && 
        initXMLReader.funConfig[functionID].hasConfiged)
    {
      System.out.println("  function ID                : " + functionID);
      System.out.println("  function Name              : " + initXMLReader.funConfig[functionID].functionName);
      System.out.println("  Stress thread number       : " + initXMLReader.funConfig[functionID].threadNum);
      String tempInfo = new String("");
      if (initXMLReader.funConfig[functionID].execNumPerThread < 0)
        tempInfo = "No limited";
      else
        tempInfo = "" + initXMLReader.funConfig[functionID].execNumPerThread;
      System.out.println("  Execution times per thread : " + tempInfo);
      if (initXMLReader.funConfig[functionID].execNumPerSec < 0)
        tempInfo = "No limited";
      else
        tempInfo = "" + initXMLReader.funConfig[functionID].execNumPerSec;
      System.out.println("  Execution times per second : " + tempInfo);
    }
    else
      System.out.println("  function ID " + functionID + " does not exist, Please select a correct one!");
  }
  
  // show the running status of the stress process
  private boolean showProcessStatus(boolean showInfo)
  {
    if (hasPaused)
    {
      if (showInfo)
        System.out.println("stress process has been paused!");
      return false;
    }
  
    int runningFunction = 0;
    for (int j = 0; j < 100; j++) {
      int i = 0;
      if (initXMLReader.funConfig[j] != null && initXMLReader.funConfig[j].hasConfiged)
      {
        boolean isFunctionRuning = showFunctionStatus(j, false);
        if (isFunctionRuning)
        {
          runningFunction++;
        }

        if (isFunctionRuning && showInfo)
        {
          System.out.println("Function \""+j+"\" \""+initXMLReader.funConfig[j].functionName + "\" is running");
        }
      }
    }
    
    if (runningFunction > 0)
    {
      if (showInfo)
        System.out.println("\nThere are "+runningFunction+" function(s) being stressed!");
      return true;
    }
    else
      if (showInfo)
        System.out.println("\nThere is no function being stressed!");
      return false;
  }
  
  // show the running status of the stress function
  private boolean showFunctionStatus(int funID, boolean showInfo)
  {
    if (hasPaused)
    {
      if (showInfo)
        System.out.println("stress process has been paused!");
      return false;
    }

    int runningThreads = 0;
    int i = 0;
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      do {
        if (Threads[funID][i] != null)
        {
          if (!Threads[funID][i].isStop)
          {
            runningThreads++;
          }
        }

        i++;
      }
      while (i < initXMLReader.funConfig[funID].threadNum);
    }
    
    if (runningThreads > 0)
    {
      if (showInfo)
        System.out.println("There are " + runningThreads + " thread(s) running to stress funtion \""+funID+"\" \""+initXMLReader.funConfig[funID].functionName+"\"");
      return true;
    }
    else
    {
      if (showInfo)
        System.out.println("There is no thread running to stress funtion \""+funID+"\" \""+initXMLReader.funConfig[funID].functionName+"\"");
      return false;
    }
  }
  
  // pause stress process
  public void pauseStress()
  {
    hasPaused = true;
    
    for (int j = 0; j < 100; j++) {
      int i = 0;
      if (initXMLReader.funConfig[j] != null && initXMLReader.funConfig[j].hasConfiged)
      {
        pauseFunction(j);
      }
    }
  }
  
  // pause a function
  protected void pauseFunction(int funID)
  {
    int i = 0;
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      do {
        if (Threads[funID][i] != null)
        {
          Threads[funID][i].pauseStress();
        }

        i++;
      }
      while (i < initXMLReader.funConfig[funID].threadNum);
    }
  }
  
  // resume stress process
  public void resumeStress()
  {
    hasPaused = false;
    
    for (int j = 0; j < 100; j++) {
      int i = 0;
      if (initXMLReader.funConfig[j] != null && initXMLReader.funConfig[j].hasConfiged)
      {
        resumeFunction(j);
      }
    }
  }
  
  // resume a function
  protected void resumeFunction(int funID)
  {
    int i = 0;
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      do 
      {
        if (Threads[funID][i] != null)
        {
          Threads[funID][i].resumeStress();
        }

        i++;
      }
      while (i < initXMLReader.funConfig[funID].threadNum);
    }
  }
  
  // reset stress process
  public void resetStress()
  {
    stopStress();
    initStress();
    startStress();
  }
  
  // set the stress thread number of a function
  private boolean setFuncThreadNum(int funID, int setValue)
  {
    // thread limit for trial version
    if (commUtil.isTrialVersion &&
        setValue >= commUtil.trialLimit)
      setValue = commUtil.trialLimit;
          
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      // set a value less then current thread number, interrupt the redundant threads.
      if (setValue < initXMLReader.funConfig[funID].threadNum)
      {
        int i = initXMLReader.funConfig[funID].threadNum - 1;
        do {
          if (Threads[funID][i] != null)
          {
            if (!Threads[funID][i].isStop)
            {
              Threads[funID][i].interrupt();
            }
  
            log(initXMLReader.funConfig[funID].functionName +
                               " stop thread " + i);
          }
          i--;
        }
        while (i >= setValue);
        initXMLReader.funConfig[funID].threadNum = setValue;
      }
      
      // set a value more then current thread number, start new threads.
      if (setValue > initXMLReader.funConfig[funID].threadNum)
      {
        int i = initXMLReader.funConfig[funID].threadNum;
        do {
          Threads[funID][i] = new connThread(initXMLReader.funConfig[funID].
                                                functionName + " Thread" + i + 1,
                                                i, initXMLReader, funID);
          log(initXMLReader.funConfig[funID].functionName +
                             " init thread " + i);
          Threads[funID][i].init(commUtil.fwLog);
          Threads[funID][i].start();
  
          i++;
        }
        while (i < setValue);
        initXMLReader.funConfig[funID].threadNum = setValue;
      }
      
      return true;
    }

    return false;
  }

  // set the stress thread number of a function
  private boolean setFuncExecNumPerThread(int funID, int setValue)
  {
    int i = 0;
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      initXMLReader.funConfig[funID].execNumPerThread = setValue;
      return true;
    }

    return false;
  }

  // set the stress thread number of a function
  private boolean setFuncExecNumPerSec(int funID, int setValue)
  {
    int i = 0;
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      initXMLReader.funConfig[funID].execNumPerSec = setValue;
      return true;
    }

    return false;
  }

  // set the funtion's parameter  
  private boolean setfunctionValue(int funID, String paramName, int setValue)
  {
    if (paramName.trim().equalsIgnoreCase("threadNum"))
    {
      if (setFuncThreadNum(funID, setValue))
        return true;
    }
    if (paramName.trim().equalsIgnoreCase("execNumPerThread"))
    {
      if (setFuncExecNumPerThread(funID, setValue))
        return true;
    }
    if (paramName.trim().equalsIgnoreCase("execNumPerSec"))
    {
      if (setFuncExecNumPerSec(funID, setValue))
        return true;
    }

    return false;
  }
  
  // check if function has been stopped
  protected boolean hasFunctionStop(int funID)
  {
    boolean hasStop = true;
    int i = 0;
    if (initXMLReader.funConfig[funID] != null && initXMLReader.funConfig[funID].hasConfiged)
    {
      do {
        if (Threads[funID][i] != null)
        {
          if (!Threads[funID][i].isStop)
          {
            hasStop = false;
            break;
          }
        }

        i++;
      }
      while (i < initXMLReader.funConfig[funID].threadNum);
    }
    
    return hasStop;
  }
  
  // check if stress has been stopped
  public boolean hasStressStop()
  {
    boolean hasStop = true;
    
    for (int j = 0; j < 100; j++) 
    {
      if (!hasFunctionStop(j))
      {
        hasStop = false;
        break;
      }
    }
    
    return hasStop;
  }
  
  private boolean parseCMD(String initialCommand)
  {
    String[] commandString = splitCommand(initialCommand.trim());
    if (commandString == null || commandString.length ==0 ||commandString[0].equalsIgnoreCase(""))
      return false;
    
    if (commandString.length==1 &&
        (commandString[0].equalsIgnoreCase("Help") ||
         commandString[0].equalsIgnoreCase("H")))
    {
      System.out.println("");
      System.out.println("Command Set:");
      System.out.println(" H(elp)                : get help inform;");
      System.out.println(" V(ersion)             : show version of SQLStress;");
      System.out.println(" L(ist) [function_id]  : list function(s) inform;");
      System.out.println(" E(xit)                : exit stress process;");
      System.out.println(" P(ause) [function_id] : pause stress process/function;");
      System.out.println(" Resume [function_id]  : resume stress process/function;");
      System.out.println(" NoLog(Thread)         : do not record the thread's log into log file;");
      System.out.println(" Log(Thread)           : record the thread's log into log file;");
      System.out.println(" Status [function_id]  : show the status of function/stress process;");
      System.out.println(" Startup [function_id] : Startup one function / stress process");
      System.out.println(" Shutdown [function_id]: shutdown one function / stress process");
      System.out.println(" Reset                 : reset all function's parameter as the values configured in init file");
      System.out.println(" Set function_id parameter value: set function stress parameter value,");
      System.out.println("    including:");
      System.out.println("    threadNum");
      System.out.println("     --- how many threads should the function stress.");
      System.out.println("    execNumPerThread");
      System.out.println("     --- how many times should one funtion execute. -1 means no limited.");
      System.out.println("    execNumPerSec");
      System.out.println("     --- how many times should one funtion execute in one second. -1 means no limited.");
      System.out.println("");
      System.out.println(" Examples:");
      System.out.println("    Stop 1");
      System.out.println("     --- will stop function with function id \"1\"");
      System.out.println("    Set 1 threadNum 5");
      System.out.println("     --- will set function with function id \"1\" to have \"5\" threads to stress.");
      System.out.println("");
      
      return true;
    }
    
    // ^_^
    if (initialCommand.equalsIgnoreCase("I Love fuyuncat"))
    {
      System.out.println("");
      System.out.println("Fuyuncat love you, too!");
      System.out.println("");

      return true;
    }
    
    // shutdown stress process/funtion
    if ((commandString.length==1 || commandString.length==2) &&
        commandString[0].equalsIgnoreCase("shutdown"))
    {
      System.out.println("");
      
      // shutdown stress process
      if (commandString.length == 1)
      {
        if (hasStressStop())
        {
          System.out.println("ERROR: Stress process has been shutdown. Startup it first!");
          System.out.println("");
          return false;
        }
        interruptAllThreads();
      }
      
      // shutdown one function
      if (commandString.length == 2)
      {
        int funID = 0;
        try 
        {
          funID = Integer.valueOf(commandString[1]).intValue();
        }
        catch (Exception e)
        {
          System.out.println("");
          System.out.println("ERROR: Please input a valid number!");
          return false;
        }
        if (hasFunctionStop(funID))
        {
          System.out.println("Function \""+funID+"\" has been shutdown. Startup it first!");
          System.out.println("");
          return false;
        }
        interruptFuncThreads(funID);
        System.out.println("Function \""+funID+"\" stress has been shutdown!");
        System.out.println("");
      }

      System.out.println("");
      
      return true;
    }
    
    // startup stress process/funtion
    if ((commandString.length==1 || commandString.length==2) &&
        commandString[0].equalsIgnoreCase("Startup"))
    {
      System.out.println("");

      // startup stress process
      if (commandString.length == 1)
      {
        if (!hasStressStop())
        {
          System.out.println("ERROR: Stress process is running. shutdown it first!");
          System.out.println("");
          return false;
        }
        initAllThreads();
        startAllThreads();
        System.out.println("");
      }
      
      // startup one function
      if (commandString.length == 2)
      {
        int funID = 0;
        try 
        {
          funID = Integer.valueOf(commandString[1]).intValue();
        }
        catch (Exception e)
        {
          System.out.println("");
          System.out.println("ERROR: Please input a valid number!");
          return false;
        }
        if (!hasFunctionStop(funID))
        {
          System.out.println("Function \""+funID+"\" is running. shutdown it first!");
          System.out.println("");
          return false;
        }
        initFuncThreads(funID);
        startFuncThreads(funID);
        System.out.println("Function \""+funID+"\" stress has been started!");
        System.out.println("");
      }

      return true;
    }
    
    // set stress parameter of function 
    if (commandString.length==4 &&
        commandString[0].equalsIgnoreCase("set"))
    {
      System.out.println("");
      int funID = 0;
      try 
      {
        funID = Integer.valueOf(commandString[1]).intValue();
      }
      catch (Exception e)
      {
        System.out.println("");
        System.out.println("ERROR: Please input a valid number!");
        return false;
      }
      
      int setValue = 0;
      try 
      {
        setValue = Integer.valueOf(commandString[3]).intValue();
      }
      catch (Exception e)
      {
        System.out.println("");
        System.out.println("ERROR: Please input a valid number!");
        return false;
      }
      
      if (!setfunctionValue(funID, commandString[2].trim(), setValue))
        System.out.println("ERROR: Parameter set failed! Please check if the parameter name is valid!");
      else
        System.out.println("parameter \""+commandString[2].trim()+"\" of function \""+funID+"\" has been set as "+"\""+setValue+"\"!");
      
      System.out.println("");

      return true;
    }
    
    // show version
    if (commandString.length==1 &&
        commandString[0].equalsIgnoreCase("Reset"))
    {
      System.out.println("");
      System.out.print("Are you sure you want to reset the stress process? (Yes or No) >");
      if (parseYesOrNo())
      {
        resetStress();
        System.out.println("Stress process has been reset!");
      }
      System.out.println("");
      
      return true;
    }
    
    // resume stess
    if ((commandString.length==1 || commandString.length==2) &&
        commandString[0].equalsIgnoreCase("Resume"))
    {
      System.out.println("");
      if (commandString.length == 1)
      {
        resumeStress();
        System.out.println("Stress process has been resumed!");
      }
      if (commandString.length == 2)
      {
        int funID = 0;
        try 
        {
          funID = Integer.valueOf(commandString[1]).intValue();
        }
        catch (Exception e)
        {
          System.out.println("");
          System.out.println("ERROR: Please input a valid number!");
          return false;
        }
        resumeFunction(funID);
        System.out.println("Function \""+funID+"\" stress has been resumed!");
      }
      System.out.println("");
      
      return true;
    }
    
    // pause stess
    if ((commandString.length==1 || commandString.length==2) &&
        (commandString[0].equalsIgnoreCase("Pause") ||
         commandString[0].equalsIgnoreCase("P")))
    {
      System.out.println("");
      if (commandString.length == 1)
      {
        pauseStress();
        System.out.println("Stress process has been paused!");
      }
      if (commandString.length == 2)
      {
        int funID = 0;
        try 
        {
          funID = Integer.valueOf(commandString[1]).intValue();
        }
        catch (Exception e)
        {
          System.out.println("");
          System.out.println("ERROR: Please input a valid number!");
          return false;
        }
        pauseFunction(funID);
        System.out.println("Function \""+funID+"\" stress has been paused!");
      }
      System.out.println("");
      
      return true;
    }
    
    // show stauts of function/stress process
    if ((commandString.length==1 || commandString.length==2) &&
        (commandString[0].equalsIgnoreCase("Status") ||
         commandString[0].equalsIgnoreCase("S")))
    {
      System.out.println("");
      if (commandString.length == 1)
        showProcessStatus(true);
      if (commandString.length == 2)
      {
        int funID = 0;
        try 
        {
          funID = Integer.valueOf(commandString[1]).intValue();
        }
        catch (Exception e)
        {
          System.out.println("");
          System.out.println("ERROR: Please input a valid number!");
          return false;
        }
        showFunctionStatus(funID, true);
      }
      System.out.println("");
      
      return true;
    }
    
    // show version
    if (commandString.length==1 &&
        (commandString[0].equalsIgnoreCase("Version") ||
         commandString[0].equalsIgnoreCase("V")))
    {
      System.out.println("");
      System.out.println(commUtil.versionInfo);
      System.out.println("");
      
      return true;
    }
    
    // list the function infomation
    if ((commandString.length==1 || commandString.length==2) &&
        (commandString[0].equalsIgnoreCase("List") ||
         commandString[0].equalsIgnoreCase("L")))
    {
      System.out.println("");
      if (commandString.length==1)
        listAllFunctions();
      if (commandString.length==2)
      {
        int funID = 0;
        try 
        {
          funID = Integer.valueOf(commandString[1]).intValue();
        }
        catch (Exception e)
        {
          System.out.println("");
          System.out.println("ERROR: Please input a valid number!");
          return false;
        }
        ListFunctionInform(funID);
      }
      System.out.println("");
      
      return true;
    }
    
    // do not log thread details
    if (commandString.length==1 &&
        (commandString[0].equalsIgnoreCase("NoLogThread") ||
         commandString[0].equalsIgnoreCase("NoLog")))
    {
      initXMLReader.shouldLogThread = false;
      System.out.println("");
      System.out.print("Logging threads inform has been stopped!");
      System.out.println("");
      
      return true;
    }
    
    // log thread details
    if (commandString.length==1 &&
        (commandString[0].equalsIgnoreCase("LogThread") ||
         commandString[0].equalsIgnoreCase("Log")))
    {
      initXMLReader.shouldLogThread = true;
      System.out.println("");
      System.out.print("Logging threads inform has been started!");
      System.out.println("");
      
      return true;
    }
    
    // exit stress process
    if (commandString.length==1 &&
        (commandString[0].equalsIgnoreCase("Exit") ||
         commandString[0].equalsIgnoreCase("E")))
    {
      System.out.println("");
      System.out.print("Are you sure you want to exit stressing? (Yes or No) >");
      if (parseYesOrNo())
        System.exit(0);
      System.out.println("");

      return true;
    }
    
    System.out.println("");
    System.out.println(initialCommand + " is not a valid command. Please type HELP to get help inform.");
    System.out.println("");
    
    return false;
  }
}