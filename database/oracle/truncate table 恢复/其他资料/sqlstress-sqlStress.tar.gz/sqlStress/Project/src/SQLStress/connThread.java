package SQLStress;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.sql.*;
import oracle.jdbc.driver.OracleDriver;
import java.util.*;
import java.text.*;
import java.io.*;

public class connThread
    extends Thread {
  String ThreadName = ""; //�߳�����
  int ranseed = 0;//���������
  Connection conn = null;//���ݿ�����
  PreparedStatement psql = null;//SQL����
  CallableStatement cfunc = null;//��������
  boolean isSQLStatement = false;
  ResultSet rset = null;//�����
  XMLReader initXMLReader = null;//��XML�ļ��ж�ȡ��ʼ������
  int functionIndex = 0;//�����ļ��е��ĸ�����
  int threadIndex = 0; //thread index in one function
  Calendar a = Calendar.getInstance();

  long wholeBeginTime = System.currentTimeMillis();
  long wholeExecTime = 0;
  long execNum = 0;//��ִ�д���
  int successful = 0; //�ɹ�����
  int fail = 0; //ʧ�ܴ���
  int resultSuccessful = 0;//����ִ�з��سɹ�����
  int resultFail = 0;//����ִ�з���ʧ�ܴ���
  double successRatio = 0;//�ɹ���
  float caps = 0;//caps
  String wholeExecTimeFormat = null;//��ִ��ʱ��

  private FileWriter fwLog;            // log file writer
  public boolean isStop = false;      // thread should be stopped
  public boolean isPause = false;      // thread should be paused

  private String paraValue[] = new String[100];//����ֵ
//  a.set(104,3,21,9,0,0);

  public connThread(String sName, int iThreadID, XMLReader xmlXMLReader, int fIndex) {
    this.ThreadName = sName;
    this.ranseed = iThreadID;
    this.threadIndex = iThreadID;
    this.initXMLReader = xmlXMLReader;
    this.functionIndex = fIndex;
    doShutDownHook();
  }

  public void endThread()
  {
//    initXMLReader.funConfig[functionIndex].isRunning[threadIndex] = false;
    wholeExecTime = System.currentTimeMillis() - wholeBeginTime;
    caps = (float)execNum * 1000 / wholeExecTime;

    wholeExecTimeFormat = formatTimeMillis(wholeExecTime);
     successRatio = 0.00;
     if (execNum > 0)
       successRatio = (float)successful / execNum;

    isStop = true;
  }
  
  public void interrupt()
  {
    if (!isStop)
    {
//      initXMLReader.funConfig[functionIndex].isRunning[threadIndex] = false;
      isStop = true;
  
      Thread.currentThread().interrupt();
    }
//    Thread.currentThread().destroy();
  }
  
  protected void doShutDownHook() {
    Runtime.getRuntime().addShutdownHook(new Thread() {
      //�߳̽���������ͳ������
      public void run() {
//        DateFormat logDateFormat = new SimpleDateFormat("yyyyMMdd_kkmmss"); //ʱ���ʽ
//        String logFile = "sqlstress" + logDateFormat.format(new java.util.Date()) + ".log";
//        String logFile = "sqlstress.log";

//        try
        {
//          FileWriter fw = new FileWriter(logFile, true);

//          initXMLReader.funConfig[functionIndex].isRunning[threadIndex] = false;
          wholeExecTime = System.currentTimeMillis() - wholeBeginTime;
          caps = (float)execNum * 1000 / wholeExecTime;

//          log(ThreadName+" Total=" + execNum);

          wholeExecTimeFormat = formatTimeMillis(wholeExecTime);

//          log(ThreadName+" whole execute time=" + wholeExecTimeFormat);

//          log(ThreadName+" exec per sec=" + execNum * 1000 / wholeExecTime);

//          log(ThreadName+" sussful=" + successful);

//          log(ThreadName+" fail=" + fail);

          successRatio = 0.00;
          if (execNum > 0)
            successRatio = (float)successful / execNum;
//            log(ThreadName+" sucessful/total=" + dd);

          isStop = true;

        }
//        catch (IOException ex) {
//          log(" Write log file:"+logFile+" failed!");
//          log(ex.getMessage());
//        }

      }
    });
  }

  public void run() {
    try {
      isStop = false;
//      initXMLReader.funConfig[functionIndex].isRunning[threadIndex] = true;
      runStress();//����Oracle
//      initXMLReader.funConfig[functionIndex].isRunning[threadIndex] = false;
      isStop = true;
    }
    catch (SQLException ex) {
      log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" connect oracle failed!");
      log(ex.toString());
      System.exit(1);
    }
  }

  public void init(FileWriter fw) {
    fwLog = fw;
//    initXMLReader.funConfig[functionIndex].isRunning[threadIndex] = false;
    isStop = false;
    isPause = false;
    
    try {
      initSQL();//��ʼ������
    }
    catch (SQLException ex) {
      log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" init oracle failed!");
      log(ex.toString());
      System.exit(1);
    }

  }

  private void initSQL() throws SQLException {
    try {
      //ע������
      DriverManager.registerDriver(new OracleDriver());
      //String  url="jdbc:oracle:thin:@(DESCRIPTION =( ADDRESS_LIST =( ADDRESS = (PROTOCOL = TCP)(HOST =aip1)(PORT = 1521 ) )( ADDRESS = (PROTOCOL = TCP)(HOST = aip2)(PORT = 1521 ) )( LOAD_BALANCE = YES ))( CONNECT_DATA =( SERVER = DEDICATED )( SERVICE_NAME = RING )))";
      //String url = "jdbc:oracle:oci:@(DESCRIPTION =( ADDRESS_LIST =( ADDRESS = (PROTOCOL = TCP)(HOST = 10.71.111.140)(PORT = 1521 ) )( ADDRESS = (PROTOCOL = TCP)(HOST = 10.71.111.142)(PORT = 1521 ) )( LOAD_BALANCE = on ))( CONNECT_DATA =( SERVER = DEDICATED )( SERVICE_NAME = ring )))";
      //String url = "jdbc:oracle:thin:@(DESCRIPTION =( ADDRESS_LIST =( ADDRESS = (PROTOCOL = TCP)(HOST = 10.71.111.140)(PORT = 1521 ) )( ADDRESS = (PROTOCOL = TCP)(HOST = 10.71.111.142)(PORT = 1521 ) )( LOAD_BALANCE = on ))( CONNECT_DATA =( SERVER = DEDICATED )( SERVICE_NAME = ring )))";
      //String url = "jdbc:oracle:oci:@p5";
      //String url = "jdbc:oracle:thin:@(DESCRIPTION =( ADDRESS_LIST =( ADDRESS = (PROTOCOL = TCP)(HOST = 10.71.111.171)(PORT = 1521 ) )( ADDRESS = (PROTOCOL = TCP)(HOST = 10.71.111.171)(PORT = 1521 ) )( LOAD_BALANCE = YES ))( CONNECT_DATA =( SERVER = DEDICATED )( SERVICE_NAME = ptl )))";
      //String url = "jdbc:oracle:thin:@(DESCRIPTION =( ADDRESS_LIST =( ADDRESS = (PROTOCOL = TCP)(HOST = 10.71.111.140)(PORT = 1521 ) )( LOAD_BALANCE = YES ))( CONNECT_DATA =( SERVER = DEDICATED )( SERVICE_NAME = ring )))";
      //String  url="jdbc:oracle:thin:@10.71.111.140:1521:ring2";
      //String url = "jdbc:oracle:oci:@(DESCRIPTION=(LOAD_BALANCE=ON)(FAILOVER=ON)(ADDRESS=(PROTOCOL=TCP)(HOST=10.71.111.231)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=10.71.111.232)(PORT=1522))(CONNECT_DATA=(SERVICE_NAME=P5)(FAILOVER_METHOD=(TYPE=SESSION)(METHOD=BASIC))))";
      //String url = "jdbc:oracle:oci:@(DESCRIPTION=(LOAD_BALANCE=ON)(ADDRESS=(PROTOCOL=TCP)(HOST=10.71.111.231)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=10.71.111.232)(PORT=1522))(CONNECT_DATA=(SERVICE_NAME=P5)))";

      //���Ը��ɷֵ�
      //String url = "jdbc:oracle:thin:@p5";
      String url = initXMLReader.connURL;//��ȡ�����ַ���
      //String url = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(LOAD_BALANCE=ON)(ADDRESS=(PROTOCOL=TCP)(HOST=10.71.111.231)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=10.71.111.232)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=P5)))";

      //��������
      conn = DriverManager.getConnection(url, initXMLReader.userName, initXMLReader.userPWD);

      //���ݺ�������ȷ�����÷�ʽ
      if (initXMLReader.funConfig[functionIndex].functionType.equalsIgnoreCase("function")) {
        String funcStatement = "{? = call " + initXMLReader.funConfig[functionIndex].functionName + "(";
        for (int i=0; i< initXMLReader.funConfig[functionIndex].paraNum; i++)
        {
          funcStatement = funcStatement + initXMLReader.funConfig[functionIndex].paraName[i] + " => ?";
          if (i< initXMLReader.funConfig[functionIndex].paraNum -1)
          {
            funcStatement = funcStatement+",";
          }
        }
        funcStatement = funcStatement + ")}";
        cfunc = conn.prepareCall(funcStatement);
      }
      else if (initXMLReader.funConfig[functionIndex].functionType.equalsIgnoreCase("procedure")){
        String funcStatement = "{call " + initXMLReader.funConfig[functionIndex].functionName + "(";
        for (int i=0; i< 100; i++)
        {
          if (initXMLReader.funConfig[functionIndex].paraName[i] != null &&
              !initXMLReader.funConfig[functionIndex].paraName[i].equalsIgnoreCase(""))
          {
            funcStatement = funcStatement + initXMLReader.funConfig[functionIndex].paraName[i] + " => ?";
            if (i< initXMLReader.funConfig[functionIndex].paraNum -1)
            {
              funcStatement = funcStatement+",";
            }
          }
        }
        funcStatement = funcStatement + ")}";
        cfunc = conn.prepareCall(funcStatement);
      }
      else if (initXMLReader.funConfig[functionIndex].functionType.equalsIgnoreCase("sqlStatement")){
        psql = conn.prepareStatement(
            initXMLReader.funConfig[functionIndex].functionName);
        isSQLStatement = true;
      }
      else
      {
        log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+"'s funtction type invalid!");
        System.exit(1);
      }
    }
    catch (Exception e) {
      log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" init sql failed");
      log(e.getMessage());
      System.exit(1);
    }
  }

  //��ȡ������������
  private int getType(String typeName) {
    if (typeName.equalsIgnoreCase("int")) {
      return Types.INTEGER;
    }
    else if (typeName.equalsIgnoreCase("String")) {
      return Types.CHAR;
    }
    else if (typeName.equalsIgnoreCase("Float")) {
      return Types.FLOAT;
    }
    else if (typeName.equalsIgnoreCase("Date")) {
      return Types.DATE;
    }
    else if (typeName.equalsIgnoreCase("Cursor")) {
      return oracle.jdbc.OracleTypes.CURSOR;
    }
    else
    {
      log("ERROR: The type "+typeName+" is invalid!");
      System.exit(1);
      return 0;
    }
  }

  //�����������滻@<num>@
  private String parseValue(String valueString)
  {
    String parsedString = null;
    parsedString = valueString;//SQL����
    int replaceIndex = parsedString.indexOf("@");//������������滻
    while (replaceIndex >= 0)
    {
      int nextIndex = parsedString.indexOf("@",replaceIndex+1);
      parsedString = parsedString.replaceAll(parsedString.substring(replaceIndex, nextIndex+1), paraValue[Integer.parseInt(parsedString.substring(replaceIndex+1, nextIndex))]);
      replaceIndex = parsedString.indexOf("@");
    }
    return parsedString;
  }
  
  // execute funtion in Oracle
  private void executeFunction(Random iran){
    long beginTime = System.currentTimeMillis();
    execNum++;

    try {
      int paraIndexStart = 1;

      //�������Ϊ���������з���ֵ
      if (initXMLReader.funConfig[functionIndex].functionType.equalsIgnoreCase("function")) {
        cfunc.registerOutParameter(1, getType(initXMLReader.funConfig[functionIndex].resultType));
        paraIndexStart = 2;
      }

      //ѭ�����ò���ֵ
      for (int i = paraIndexStart; i < paraIndexStart + initXMLReader.funConfig[functionIndex].paraNum;
           i++) {
        //����λ��
        //int paraIndex = initXMLReader.funConfig[functionIndex].paraIndex[i - paraIndexStart];
        int paraIndex = i - paraIndexStart;

        //������������������Ҫ��������ֵ
        if (initXMLReader.funConfig[functionIndex].inorputPut[i -
            paraIndexStart].equalsIgnoreCase("in") || initXMLReader.funConfig[functionIndex].inorputPut[i -
            paraIndexStart].equalsIgnoreCase("inout")) {
          //�������ȡֵ�������б�������б������ȡһ��
          if (initXMLReader.funConfig[functionIndex].rangeType[i -
              paraIndexStart].equalsIgnoreCase("LIST")) 
          {
            if (initXMLReader.funConfig[functionIndex].valueNum[i - paraIndexStart] > 1 )
            {
              paraValue[paraIndex] = initXMLReader.funConfig[functionIndex].value[i -
                  paraIndexStart][iran.nextInt(initXMLReader.funConfig[functionIndex].valueNum[i - paraIndexStart] - 1)];
            }
            else
            {
              paraValue[paraIndex] = initXMLReader.funConfig[functionIndex].value[i - paraIndexStart][0];
            }
            paraValue[paraIndex] = parseValue(paraValue[paraIndex]);
          }
          //�������ȡֵ�����Ƿ�Χ��������ֵ����Сֵ֮��ȡһ��ֵ
          else if (initXMLReader.funConfig[functionIndex].rangeType[i -
                   paraIndexStart].equalsIgnoreCase("RANGE")) 
          {
            String minValue = parseValue(initXMLReader.funConfig[functionIndex].minValue[i - paraIndexStart]);
            String maxValue = parseValue(initXMLReader.funConfig[functionIndex].maxValue[i - paraIndexStart]);

            //ȡֵ�����Ǹ���
            if (initXMLReader.funConfig[functionIndex].dataType[i -
                paraIndexStart].equalsIgnoreCase("Float")) {
              paraValue[paraIndex] = "" +
                  (Float.parseFloat( minValue+
                   iran.nextFloat()*(Float.parseFloat(maxValue) -
                                Float.parseFloat(minValue))));
            }
            //ȡֵ����������
            else if (initXMLReader.funConfig[functionIndex].dataType[i -
                     paraIndexStart].equalsIgnoreCase("int")) {
              paraValue[paraIndex] = "" +
                  (Long.parseLong(minValue) +
                   (long) ( (Long.parseLong(maxValue) -
                             Long.parseLong(minValue)) *
                           iran.nextFloat()));
            }
            //ȡֵ�������ַ���
            else if (initXMLReader.funConfig[functionIndex].dataType[i -
                     paraIndexStart].equalsIgnoreCase("String")) {
              byte[] stringBytes = new byte[20];
              iran.nextBytes( stringBytes );
              paraValue[paraIndex] = new String(stringBytes);
            }
            //ȡֵ������ʱ��
            else if (initXMLReader.funConfig[functionIndex].dataType[i -
                     paraIndexStart].equalsIgnoreCase("Date")) {
              Calendar dateMinValue = Calendar.getInstance(); //ʱ�����͵���Сֵ
              Calendar dateMaxValue = Calendar.getInstance(); //ʱ���������ֵ
              DateFormat dateValueFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");//ʱ���ʽ
              Calendar dateValue = Calendar.getInstance(); //ʱ��ֵ

              try
              {
                  dateMinValue.setTime(dateValueFormat.parse(minValue));
                  dateMaxValue.setTime(dateValueFormat.parse(maxValue));
              }
              catch (Exception e)
              {
                log("WARNING: "+initXMLReader.funConfig[functionIndex].functionName+" set date value of "+initXMLReader.funConfig[functionIndex].paraName[i - paraIndexStart]+ " failed!");
                log(e.getMessage());
              }
              dateValue.setTimeInMillis((long)(dateMinValue.getTimeInMillis() + (dateMaxValue.getTimeInMillis() - dateMinValue.getTimeInMillis())*iran.nextFloat()));
              paraValue[paraIndex] =  dateValueFormat.format(dateValue.getTime());
            }
            else
            {
              log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+initXMLReader.funConfig[functionIndex].paraName[i - paraIndexStart]+"'s dataValue type invalid!");
              System.exit(1);
            }
          }
          //�������ȡֵ�������漴
          else if (initXMLReader.funConfig[functionIndex].rangeType[i -
                   paraIndexStart].equalsIgnoreCase("RANDOM")) 
          {
            //ȡֵ�����Ǹ���
            if (initXMLReader.funConfig[functionIndex].dataType[i -
                paraIndexStart].equalsIgnoreCase("Float")) {
              paraValue[paraIndex] = "" + iran.nextFloat();
            }
            //ȡֵ����������
            else if (initXMLReader.funConfig[functionIndex].dataType[i -
                     paraIndexStart].equalsIgnoreCase("int")) {
              paraValue[paraIndex] = "" + iran.nextLong();
            }
            //ȡֵ�������ַ���
            else if (initXMLReader.funConfig[functionIndex].dataType[i -
                     paraIndexStart].equalsIgnoreCase("String")) {
              byte[] stringBytes = new byte[20];
              iran.nextBytes( stringBytes );
              paraValue[paraIndex] = new String(stringBytes);
            }
            //ȡֵ������ʱ��
            else if (initXMLReader.funConfig[functionIndex].dataType[i -
                     paraIndexStart].equalsIgnoreCase("Date")) {
              DateFormat dateValueFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");//ʱ���ʽ
              Calendar dateValue = Calendar.getInstance(); //ʱ��ֵ

              dateValue.setTime(dateValue.getTime());
              dateValue.setTimeInMillis(dateValue.getTimeInMillis() + iran.nextLong());
              paraValue[paraIndex] =  dateValueFormat.format(dateValue.getTime());
            }
            else
            {
              log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+initXMLReader.funConfig[functionIndex].paraName[i - paraIndexStart]+"'s dataValue type invalid!");
              System.exit(1);
            }
          }
          else if (initXMLReader.funConfig[functionIndex].rangeType[i -
                    paraIndexStart].equalsIgnoreCase("SQL")) 
          {
             String sqlString = null;//SQL���
             PreparedStatement getValueSQL = null; //SQL����
/*               sqlString = "select " +
                 initXMLReader.funConfig[functionIndex].selectValue[i -
                 paraIndexStart] +
                 " from ( select " +
                 initXMLReader.funConfig[functionIndex].selectValue[i -
                 paraIndexStart] +
                 " from " +
                 initXMLReader.funConfig[functionIndex].fromTable[i -
                 paraIndexStart] +
                 " sample(1) ";
             if (initXMLReader.funConfig[functionIndex].whereCondition[i -paraIndexStart].length() >= 3)
             {
               sqlString = sqlString + " where " +
                   initXMLReader.funConfig[functionIndex].whereCondition[i -
                   paraIndexStart];
             }
             sqlString = sqlString + " ) where rownum <= 1";
*/
             sqlString = "select " +
                 initXMLReader.funConfig[functionIndex].selectValue[i -
                 paraIndexStart] +
                 " from ( select " +
                 initXMLReader.funConfig[functionIndex].selectValue[i -
                 paraIndexStart] +
                 " from " +
                 initXMLReader.funConfig[functionIndex].fromTable[i -
                 paraIndexStart] ;
             if (initXMLReader.funConfig[functionIndex].whereCondition[i -paraIndexStart].length() >= 3)
             {
               sqlString = sqlString + " where " +
                   initXMLReader.funConfig[functionIndex].whereCondition[i -
                   paraIndexStart];
             }
             sqlString = sqlString + " order by dbms_random.value) where rownum <= 1";

             sqlString = parseValue(sqlString);
//               log(sqlString);
             getValueSQL = conn.prepareStatement(sqlString);
             rset = getValueSQL.executeQuery();
             if (rset.next())
             {
               paraValue[paraIndex] = rset.getString(1);
             }
             else
             {
               paraValue[paraIndex] = initXMLReader.funConfig[functionIndex].defaultValue[i -
                 paraIndexStart];
             }
             if (getValueSQL != null)
             {
               getValueSQL.close();
             }
             if (rset != null)
             {
               rset.close();
             }
           }
           else
           {
             log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+initXMLReader.funConfig[functionIndex].paraName[i - paraIndexStart]+"'s value scope type invalid!");
             System.exit(1);
           }

          //���ò���ֵ
          if (isSQLStatement)
          {
            if (initXMLReader.funConfig[functionIndex].paraType[i -
                paraIndexStart].equalsIgnoreCase("Float")) {
              psql.setDouble(paraIndexStart + paraIndex,
                             Float.parseFloat(paraValue[paraIndex]));
            }
            else if (initXMLReader.funConfig[functionIndex].paraType[i -
                     paraIndexStart].equalsIgnoreCase("int")) {
              psql.setInt(paraIndexStart + paraIndex,
                             Integer.parseInt(paraValue[paraIndex]));
            }
            else if (initXMLReader.funConfig[functionIndex].paraType[i -
                     paraIndexStart].equalsIgnoreCase("Date")) {
              DateFormat dateValueFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");//ʱ���ʽ
              Calendar dateValue = Calendar.getInstance(); //ʱ��ֵ
              dateValue.setTime(dateValueFormat.parse(paraValue[paraIndex]));

              psql.setDate(paraIndexStart + paraIndex, (java.sql.Date)dateValue.getTime());
            }
            else if (initXMLReader.funConfig[functionIndex].paraType[i -
                     paraIndexStart].equalsIgnoreCase("String")) {
              psql.setString(paraIndexStart + paraIndex, paraValue[paraIndex]);
            }
            else
            {
              log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+initXMLReader.funConfig[functionIndex].paraName[i - paraIndexStart]+"'s dataValue type invalid!");
              System.exit(1);
            }

          }
          else
          {
            cfunc.setString(paraIndexStart + paraIndex, paraValue[paraIndex]);
          }
//            log( initXMLReader.funConfig[functionIndex].paraName[i - paraIndexStart]+"'s value is " + paraValue[paraIndex]);
        }
        //�����������������������������
        if (initXMLReader.funConfig[functionIndex].inorputPut[i -
            paraIndexStart].equalsIgnoreCase("out") || initXMLReader.funConfig[functionIndex].inorputPut[i -
            paraIndexStart].equalsIgnoreCase("inout")) {
          cfunc.registerOutParameter(paraIndexStart+paraIndex, getType(initXMLReader.funConfig[functionIndex].paraType[i - paraIndexStart]));
        }
      }

      if (isSQLStatement)
      {
        rset = psql.executeQuery();
      }
      else
      {
        cfunc.execute(); //ִ�к���
/*
        //��ӡ�������
        for (int i = paraIndexStart;
             i <
             paraIndexStart + initXMLReader.funConfig[functionIndex].paraNum;
             i++) {
          if (initXMLReader.funConfig[functionIndex].inorputPut[i -
              paraIndexStart].equalsIgnoreCase("out") ||
              initXMLReader.funConfig[functionIndex].inorputPut[i -
              paraIndexStart].equalsIgnoreCase("inout")) {
            if (initXMLReader.funConfig[functionIndex].paraType[i -
                paraIndexStart].equalsIgnoreCase("Float")) {
              log(initXMLReader.funConfig[functionIndex].
                                 paraName[i - paraIndexStart] + " is:" +
                                 cfunc.getFloat(i));
            }
            else if (initXMLReader.funConfig[functionIndex].paraType[i -
                     paraIndexStart].equalsIgnoreCase("int")) {
              log(initXMLReader.funConfig[functionIndex].
                                 paraName[i - paraIndexStart] + " is:" +
                                 cfunc.getInt(i));
            }
            else if (initXMLReader.funConfig[functionIndex].paraType[i -
                     paraIndexStart].equalsIgnoreCase("String")) {
              log(initXMLReader.funConfig[functionIndex].
                                 paraName[i - paraIndexStart] + " is:" +
                                 cfunc.getString(i));
            }
            else if (initXMLReader.funConfig[functionIndex].paraType[i -
                     paraIndexStart].equalsIgnoreCase("Date")) {
              DateFormat dateValueFormat = new SimpleDateFormat(
                  "yyyy-MM-dd kk:mm:ss"); //ʱ���ʽ
              try {
                log(initXMLReader.funConfig[functionIndex].
                                   paraName[i - paraIndexStart] + " is:" +
                                   dateValueFormat.format(cfunc.getDate(i)));
              }
              catch (Exception e) {
                log(initXMLReader.funConfig[functionIndex].
                                   functionName + " set date value of " +
                                   initXMLReader.funConfig[functionIndex].
                                   paraName[i - paraIndexStart] + " failed!");
                log(e.getMessage());
              }
            }
          }
        }
*/
      }
      
///*        //��ӡ��������ֵ
      if (initXMLReader.funConfig[functionIndex].functionType.equalsIgnoreCase("function")) 
      {
        if (initXMLReader.funConfig[functionIndex].resultType.equalsIgnoreCase("Float")) {
          log(initXMLReader.funConfig[functionIndex].functionName+" Result is:" +
                             cfunc.getFloat(1));
        }
        else if (initXMLReader.funConfig[functionIndex].resultType.equalsIgnoreCase("int")) {
          log(initXMLReader.funConfig[functionIndex].functionName+" Result is:" +
                             cfunc.getInt(1));
        }
        else if (initXMLReader.funConfig[functionIndex].resultType.equalsIgnoreCase("String")) {
          log(initXMLReader.funConfig[functionIndex].functionName+" Result is:" +
                             cfunc.getString(1));
        }
        else if (initXMLReader.funConfig[functionIndex].resultType.equalsIgnoreCase("Cursor")) {
          rset = cfunc.getResultSet();
          if (rset.getType() == ResultSet.CONCUR_UPDATABLE)
          {
            rset.last();
            log("There are "+rset.getRow()+" records selected!");
          }
          else
          {
            int rowNumber = 0;
            while (rset.next())
              rowNumber++;
            log("There are "+rowNumber+" records selected");
          }
        }
      }

      if (initXMLReader.funConfig[functionIndex].functionType.equalsIgnoreCase("SQLStatement")) 
      {
        if (rset.getType() == ResultSet.CONCUR_UPDATABLE)
        {
          rset.last();
          log("There are "+rset.getRow()+" records selected!");
        }
        else
        {
          int rowNumber = 0;
          while (rset.next())
            rowNumber++;
          log("There are "+rowNumber+" records selected");
        }
      }
//*/
      log(initXMLReader.funConfig[functionIndex].functionName+" execute successfully!");
      successful++;
    }
    catch (SQLException e)
    {
      fail++;
      log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" execute failed!");
      log(e.getMessage());
    }
    catch (ParseException e) {
      fail++;
      log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" execute failed!");
      log(e.getMessage());
    }
    catch (Exception e) {
      fail++;
      log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" execute failed!");
      log(e.getMessage());
    }
    finally {
    }

    try {
      long execEstimate = 1000/initXMLReader.funConfig[functionIndex].execNumPerSec;
      long endTime = System.currentTimeMillis();
      long sleepTime = execEstimate - (endTime - beginTime);
      if ( sleepTime > 0)
      {
        Thread.currentThread().sleep(sleepTime);
      }
    }
    catch (InterruptedException e) {
      log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" sleep exception");
    }

  }
  
  public void pauseStress()
  {
    isPause = true;
  }

  public void resumeStress()
  {
    isPause = false;
  }

  //����Oracle
  private void runStress() throws SQLException {
    int total = 0; // total executed times

    Random iran = new Random(ranseed); // ����������ڲ���ֵ

    log("-----------------" + ThreadName + ":" + initXMLReader.funConfig[functionIndex].execNumPerThread + "-----------------");
    
    while ((total < initXMLReader.funConfig[functionIndex].execNumPerThread || 
           initXMLReader.funConfig[functionIndex].execNumPerThread == -1) &&
           !isStop){
      if (total != -1)
        total++;

      // check if thread been paused
      while (isPause)
      {
        try 
        {
          Thread.currentThread().sleep(1);
        }
        catch (InterruptedException e)
        {
          log("ERROR: "+initXMLReader.funConfig[functionIndex].functionName+" sleep exception");
        }
      }
      
      executeFunction(iran);    
    }

    if (rset != null)
      rset.close();

    if (psql != null)
      psql.close();

    if (cfunc != null)
      cfunc.close();

    if (conn != null)
      conn.close();
  }

  public void destroySQL() throws SQLException {
  }

  private void log(String logMessage)
  {
    try
    {
//      System.out.println(logMessage);
      if (initXMLReader.shouldLogThread)
      {
        fwLog.write(logMessage + "\n");
        fwLog.flush();
      }
    }
    catch (IOException ex){
//      System.out.println("ERROR: Write log file failed!");
//      System.out.println(ex.getMessage());
    }
  }

  // format the time in milli-senconds
  private String formatTimeMillis(long timeMillis)
  {
    String formattedTime = new String();
    formattedTime = (int) timeMillis / (3600 * 1000) + " hours, " +
                                   (int) ( (timeMillis -
                                            ( (long) timeMillis / (3600 * 1000)) *
                                            3600 * 1000) / 60000) + " mins, " +
                                   (int) ( (timeMillis -
                                            ( (long) timeMillis / 60000) * 60000) /
                                          1000) + "secs, " +
                                   (int) (timeMillis -
                                          ( (long) timeMillis / 1000) * 1000) +
                                   " ms.";
    return formattedTime;
  }
}
