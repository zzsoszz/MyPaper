package SQLStress;

import org.w3c.dom.*;
import org.xml.sax.*;
import org.xml.sax.AttributeList;
import org.xml.sax.helpers.*; 
import javax.xml.parsers.*;
import java.io.*;

class XMLReader extends DefaultHandler
{  
  public boolean shouldLogThread = true; // should the thread's log be recorded in log file

  private String fileName;             // init file
  
  public int funcNum;                   // number of funtions 
  public functionConfig funConfig[];   // functions/SPs/SQLs configuration
  public String connURL;               // DB connect URL
  public String userName;              // DB user name
  public String userPWD;               // DB user password
  
  //Constructor
  public XMLReader(){
   super(); //it must be done !
  }
  
  //init XML
  public void init(String initFile){
    funConfig = new functionConfig[100];
    funcNum = 0;
  
    if (initFile == null || initFile.equalsIgnoreCase("") )
    {
      fileName = "init.xml";
    }
    else
      fileName = initFile;
  
  } 
  
  // read connection config from xml file
  public void readConnConfig()
  {
    try
    {
      // create builder, document
      File f=new File(fileName); 
      DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance(); 
      DocumentBuilder builder = factory.newDocumentBuilder(); 
      Document doc = builder.parse(f); 
  
      // read connection config
      connURL = doc.getElementsByTagName("connURL").item(0).getFirstChild().getNodeValue().trim();
      if (connURL == null || connURL.equalsIgnoreCase(""))
      {
        log("ERROR: connect URL does set correctlly, stress process abort!"); 
        System.exit(1);
      }
      log("connURL:" + connURL); 
      userName = doc.getElementsByTagName("userName").item(0).getFirstChild().getNodeValue().trim();
      if (userName == null || userName.equalsIgnoreCase(""))
      {
        log("ERROR: user name does set correctlly, stress process abort!"); 
        System.exit(1);
      }
      log("userName:" + userName);
      userPWD = doc.getElementsByTagName("userPWD").item(0).getFirstChild().getNodeValue().trim();
      if (userPWD == null || userPWD.equalsIgnoreCase(""))
      {
        log("ERROR: user password does set correctlly, stress process abort!"); 
        System.exit(1);
      }
      log("userPWD:" + userPWD); 
    }
    catch( ParserConfigurationException e)
    {
      log("ERROR: "+"ParserConfigurationException");
      e.printStackTrace();
      System.exit(1);
    }catch(IOException e)      
    {
      log("ERROR: "+"IOException ");
      e.printStackTrace();
      System.exit(1);
    }
    catch(SAXException e)     
    {
      log("ERROR: "+"SAXException ");
      e.printStackTrace();
      System.exit(1);
    }
    catch(Exception e)
    { 
      log("ERROR: "+e.getMessage()); 
      System.exit(1);
    }       
  }

  // read functions' config from xml file
  public void readFunctionConfig(){
    try
    {
      // create builder, document
      File f=new File(fileName); 
      DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance(); 
      DocumentBuilder builder = factory.newDocumentBuilder(); 
      Document doc = builder.parse(f); 
  
      String logThreadDetail = doc.getElementsByTagName("logThreadDetail").item(0).getFirstChild().getNodeValue().trim();
      if (userPWD == null || userPWD.equalsIgnoreCase(""))
      {
        log("WARNING: logThreadDetail does set correctlly, it will be set as \"false\"."); 
        logThreadDetail = "false";
        shouldLogThread = false;
      }
      
      if (logThreadDetail.equalsIgnoreCase("true"))
        shouldLogThread = true;
      else if (logThreadDetail.equalsIgnoreCase("false"))
        shouldLogThread = false;
      else
      {
        log("WARNING: logThreadDetail does set correctlly, it will be set as \"false\"."); 
        logThreadDetail = "false";
        shouldLogThread = false;
      }
      log("logThreadDetail:" + logThreadDetail); 
      
      // read funtions config
      NodeList nl_allfuncs = doc.getElementsByTagName("function");                  // function number
      
      log("there are "+nl_allfuncs.getLength()+" functions."); 
      for (int i=0; i<nl_allfuncs.getLength(); i++)
      {
        // function limit for trial version
        if (commUtil.isTrialVersion &&
            funcNum >= commUtil.trialLimit)
          break;
                  
        Node n_func = nl_allfuncs.item(i);                                          // each function node
        int findex = i;                                                             // function index
        
        // read function properties
        NamedNodeMap nnm_attrs = n_func.getAttributes();
        for (int j=0; j<nnm_attrs.getLength(); j++)
        {
          if (nnm_attrs.item(j).getNodeName().trim().equalsIgnoreCase("fid") &&
              nnm_attrs.item(j).getNodeType() == Node.ATTRIBUTE_NODE)        // get function index
          {
            findex = Integer.valueOf(nnm_attrs.item(j).getNodeValue().trim()).intValue();
            if (findex < 0 || findex > 99)
            {
              log("WARNING: The function index number \""+findex+"\" is less then 1 or larger the 99. It has been reset to "+j+"."); 
              findex = j;
            }
            if (funConfig[findex] != null && funConfig[findex].hasConfiged)
            {
              log("WARNING: There is a existing function with index number "+findex+". And the old one would be losed!"); 
            }
            funConfig[findex] = new functionConfig();
            funConfig[findex].hasConfiged = true;
            funcNum++;
            log("This is the "+findex+" function."); 
          }
        }
        
        boolean hasStressConfig = false;    // a flag for check if configed stress configure
        boolean hasFuncionName = false;     // a flag for check if configed function name
        
        //read the function configures
        NodeList nl_funcconf =  n_func.getChildNodes();
        for (int j=0; j<nl_funcconf.getLength(); j++)
        {
          // read stress configures
          if (nl_funcconf.item(j).getNodeName().trim().equalsIgnoreCase("stressConfig") &&
              nl_funcconf.item(j).getNodeType() == Node.ELEMENT_NODE)
          {
            hasStressConfig = true;       // set flag to true
            NodeList nl_strsconf = nl_funcconf.item(j).getChildNodes();
            for (int k=0; k<nl_strsconf.getLength(); k++)
            {
              // get stress thread number of each function
              if (nl_strsconf.item(k).getNodeName().trim().equalsIgnoreCase("threadNum") &&
                  nl_strsconf.item(k).getNodeType() == Node.ELEMENT_NODE)
              {
                int i_threadNum = Integer.valueOf(nl_strsconf.item(k).getFirstChild().getNodeValue().trim()).intValue();
                
                // check the stress thread number of each function
                if (i_threadNum < 0)
                {
                  log("WARNING: the thread number \"" +i_threadNum+"\" of function "+findex+" is less then 0. Is has been reset to 1"); 
                  i_threadNum = 1;
                }
                
                // thread limit for trial version
                if (commUtil.isTrialVersion &&
                    i_threadNum > commUtil.trialLimit)
                  i_threadNum = commUtil.trialLimit;
                  
                funConfig[findex].threadNum = i_threadNum;
                log("function "+findex+": Stress thread number is "+i_threadNum+"."); 
              }
              // get execution number of each thread
              if (nl_strsconf.item(k).getNodeName().trim().equalsIgnoreCase("execNumPerThread") &&
                  nl_strsconf.item(k).getNodeType() == Node.ELEMENT_NODE)
              {
                int i_execNumPerThread = Integer.valueOf(nl_strsconf.item(k).getFirstChild().getNodeValue().trim()).intValue();
                
                // check the execution number of each thread
                if (i_execNumPerThread < -1)
                {
                  log("WARNING: the execution number \""+i_execNumPerThread+"\" of each thread of function "+findex+" is less then 0. Is has been reset to -1"); 
                  i_execNumPerThread = -1;
                }
                funConfig[findex].execNumPerThread = i_execNumPerThread;
                log("function "+findex+": execution number of each thread is "+i_execNumPerThread+"."); 
              }
              
              // get execution number of each second
              if (nl_strsconf.item(k).getNodeName().trim().equalsIgnoreCase("execNumPerSec") &&
                  nl_strsconf.item(k).getNodeType() == Node.ELEMENT_NODE)
              {
                int i_execNumPerSec = Integer.valueOf(nl_strsconf.item(k).getFirstChild().getNodeValue().trim()).intValue();
                
                // check the execution number of each second
                if (i_execNumPerSec < -1)
                {
                  log("WARNING: the execution number \""+i_execNumPerSec+"\" of each second of function "+findex+" is less then 0. Is has been reset to -1"); 
                  i_execNumPerSec = -1;
                }
                funConfig[findex].execNumPerSec = i_execNumPerSec;
                log("function "+findex+": execution number of each second is "+i_execNumPerSec+"."); 
              }
            }
          }
          
          // get the function name
          if (nl_funcconf.item(j).getNodeName().trim().equalsIgnoreCase("functionName") &&
              nl_funcconf.item(j).getNodeType() == Node.ELEMENT_NODE)
          {
            String str_functionName = nl_funcconf.item(j).getFirstChild().getNodeValue().trim();
            hasFuncionName = true;
            
            // check the function name
            if (str_functionName == null || str_functionName.equalsIgnoreCase(""))
            {
              hasFuncionName = false;
              break;
            }
            funConfig[findex].functionName = str_functionName;
            log("function "+findex+": function name is "+str_functionName+"."); 
          }
  
          // get the function type
          if (nl_funcconf.item(j).getNodeName().trim().equalsIgnoreCase("functionType") &&
              nl_funcconf.item(j).getNodeType() == Node.ELEMENT_NODE)
          {
            String str_functionType = nl_funcconf.item(j).getFirstChild().getNodeValue().trim();
            funConfig[findex].functionType = checkFunctionType(str_functionType);

            log("function "+findex+": function type is "+str_functionType+"."); 
          }
  
          // get the result type
          if (nl_funcconf.item(j).getNodeName().trim().equalsIgnoreCase("resultType") &&
              nl_funcconf.item(j).getNodeType() == Node.ELEMENT_NODE)
          {
            String str_resultType = nl_funcconf.item(j).getFirstChild().getNodeValue().trim();
            
            funConfig[findex].resultType = checkResultType(funConfig[findex].functionType, str_resultType);
            log("function "+findex+": result type is "+str_resultType+"."); 
          }
          
          // read parameters' configure of the function
          if (nl_funcconf.item(j).getNodeName().trim().equalsIgnoreCase("parameters") &&
              nl_funcconf.item(j).getNodeType() == Node.ELEMENT_NODE)
          {
            if (nl_funcconf.item(j).hasChildNodes())
            {
              int i_paramIndex = 0;
              int pIndex = 0;
              int i_paramNum = 0;
              
              Node n_param = nl_funcconf.item(j).getFirstChild(); // get first parameter
              
              // get next parameters           
              while (n_param != null)
              {
                if (n_param.getNodeName().trim().equalsIgnoreCase("parameter") &&
                    n_param.getNodeType() == Node.ELEMENT_NODE)
                {
                  // read parameter properties
                  NamedNodeMap nnm_paramAttrs = n_param.getAttributes();
                  for (int k=0; k<nnm_paramAttrs.getLength(); k++)
                  {
                    if (nnm_paramAttrs.item(k).getNodeName().trim().equalsIgnoreCase("pid") &&
                        nnm_paramAttrs.item(k).getNodeType() == Node.ATTRIBUTE_NODE)           // get parameter index
                    {
                      pIndex = Integer.valueOf(nnm_paramAttrs.item(k).getNodeValue().trim()).intValue();
                      if (findex < 0 || findex > 99)
                      {
                        log("WARNING: The parameter index number \""+pIndex+"\" is less then 1 or larger the 99. It has been reset to "+i_paramIndex+"."); 
                        pIndex = i_paramIndex;
                      }
                      if (funConfig[findex].paraName[pIndex] != null && 
                          funConfig[findex].paraName[pIndex].equalsIgnoreCase(""))
                      {
                        log("WARNING: There is a existing function with index number "+pIndex+". And the old one would be losed!"); 
                      }
                      log("This is the "+pIndex+" parameter of function "+findex+"."); 
                    }
                  }
                  
                  // get the parameter configures
                  NodeList nl_paramConf = n_param.getChildNodes();
                  for ( int k=0; k<nl_paramConf.getLength(); k++)
                  {
                    // get the parameter name
                    if (nl_paramConf.item(k).getNodeName().trim().equalsIgnoreCase("paraName") &&
                        nl_paramConf.item(k).getNodeType() == Node.ELEMENT_NODE)
                    {
                      String str_paraName = nl_paramConf.item(k).getFirstChild().getNodeValue().trim();
                      
                      // check the function name
                      if (str_paraName == null || str_paraName.equalsIgnoreCase(""))
                      {
                        log("WARNING: The "+pIndex+" parameter of funtion "+findex+" is NULL."); 
                      }
                      funConfig[findex].paraName[pIndex] = str_paraName;
                      log("the "+pIndex+" parameter of function "+findex+" is: "+str_paraName+"."); 
                    }
  
                    // get the parameter type
                    if (nl_paramConf.item(k).getNodeName().trim().equalsIgnoreCase("paraType") &&
                        nl_paramConf.item(k).getNodeType() == Node.ELEMENT_NODE)
                    {
                      String str_paraType = nl_paramConf.item(k).getFirstChild().getNodeValue().trim();
                      
                      funConfig[findex].paraType[pIndex] = checkParamType(str_paraType);
                      log("the type of "+pIndex+" parameter of function "+findex+" is: "+str_paraType+"."); 
                    }
  
                    // get the parameter kind
                    if (nl_paramConf.item(k).getNodeName().trim().equalsIgnoreCase("inoroutPut") &&
                        nl_paramConf.item(k).getNodeType() == Node.ELEMENT_NODE)
                    {
                      String str_inoroutPut = nl_paramConf.item(k).getFirstChild().getNodeValue().trim();
                      
                      // check the function kind
                      if (str_inoroutPut == null || str_inoroutPut.equalsIgnoreCase(""))
                      {
                        log("WARNING: The "+pIndex+" parameter of funtion "+findex+" kind is NULL. it will reset to \"in\""); 
                        str_inoroutPut = "int";
                      }
                      funConfig[findex].inorputPut[pIndex] = str_inoroutPut;
                      log("the kind of "+pIndex+" parameter of function "+findex+" is: "+str_inoroutPut+"."); 
                    }
  
                    // get the value scope, which is used to set the value of the parameter.
                    if (nl_paramConf.item(k).getNodeName().trim().equalsIgnoreCase("valueScope") &&
                        nl_paramConf.item(k).getNodeType() == Node.ELEMENT_NODE)
                    {
                      // read value scope properties
                      NamedNodeMap nnm_valueScopeAttrs = nl_paramConf.item(k).getAttributes();
                      for (int l=0; l<nnm_valueScopeAttrs.getLength(); l++)
                      {
                        // get the range type the value
                        if (nnm_valueScopeAttrs.item(l).getNodeName().trim().equalsIgnoreCase("rangeType") &&
                            nnm_valueScopeAttrs.item(l).getNodeType() == Node.ATTRIBUTE_NODE)           // get parameter index
                        {
                          String str_rangeType = nnm_valueScopeAttrs.item(l).getNodeValue().trim();
                          
                          funConfig[findex].rangeType[pIndex] = checkRangeType(str_rangeType);
                          log("the range type of "+pIndex+" parameter of function "+findex+" is: "+str_rangeType+"."); 
                        }
  
                        // get the range data type the value
                        if (nnm_valueScopeAttrs.item(l).getNodeName().trim().equalsIgnoreCase("dataType") &&
                            nnm_valueScopeAttrs.item(l).getNodeType() == Node.ATTRIBUTE_NODE)           // get parameter index
                        {
                          String str_dataType = nnm_valueScopeAttrs.item(l).getNodeValue().trim();
                          
                          funConfig[findex].dataType[pIndex] = checkDataType(str_dataType);
                          log("the range data type of "+pIndex+" parameter of function "+findex+" is: "+str_dataType+"."); 
                        }
                      }
                      
                      // get the value scope configures
                      NodeList nl_valueScopeConfs = nl_paramConf.item(k).getChildNodes();
                      int valueNum =0; // how many values if the range type is LIST.
                      
                      for (int l=0; l<nl_valueScopeConfs.getLength(); l++)
                      {
                        // get the each value of a value list
                        if (nl_valueScopeConfs.item(l).getNodeName().trim().equalsIgnoreCase("value") &&
                            nl_valueScopeConfs.item(l).getNodeType() == Node.ELEMENT_NODE)
                        {
                          if (!funConfig[findex].rangeType[pIndex].equalsIgnoreCase("LIST"))
                          {
                            log("WARNING: The <value></value> segment should be in a value scope with range type is LIST, this value of "+pIndex+" parameter of funtion "+findex+" would be ignored!"); 
                            continue;
                          }
                        
                          String str_value = nl_valueScopeConfs.item(l).getFirstChild().getNodeValue().trim();
                          
                          // check the value
                          if (str_value == null || str_value.equalsIgnoreCase(""))
                          {
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("int") || funConfig[findex].dataType[pIndex].equalsIgnoreCase("Float"))
                            {
                              log("WARNING: The "+valueNum+" value of the value list of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"1\""); 
                              str_value = "1";
                            }
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("String"))
                            {
                              log("WARNING: The "+valueNum+" value of the value list of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"I love fuyuncat\""); 
                              str_value = "I love fuyuncat";
                            }
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("Date"))
                            {
                              log("WARNING: The "+valueNum+" value of the value list of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"2004:03:21 00:00:00\""); 
                              str_value = "2004:03:21 00:00:00";
                            }
                          }
                          funConfig[findex].value[pIndex][valueNum] = str_value;
                          log("The "+valueNum+" value of the value list of "+pIndex+" parameter of function "+findex+" is: "+str_value+"."); 
                          valueNum++;
                        }
  
                        // get the mininum value of a value range
                        if (nl_valueScopeConfs.item(l).getNodeName().trim().equalsIgnoreCase("minValue") &&
                            nl_valueScopeConfs.item(l).getNodeType() == Node.ELEMENT_NODE)
                        {
                          if (!funConfig[findex].rangeType[pIndex].equalsIgnoreCase("RANGE"))
                          {
                            log("WARNING: The <minValue></minValue> segment should be in a value scope with range type is RANGE, this mininum value of "+pIndex+" parameter of funtion "+findex+" would be ignored!"); 
                            continue;
                          }
                        
                          String str_minValue = nl_valueScopeConfs.item(l).getFirstChild().getNodeValue().trim();
                          
                          // check the mininum value
                          if (str_minValue == null || str_minValue.equalsIgnoreCase(""))
                          {
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("int") || funConfig[findex].dataType[pIndex].equalsIgnoreCase("Float"))
                            {
                              log("WARNING: The mininum value of the value range of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"1\""); 
                              str_minValue = "1";
                            }
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("String"))
                            {
                              log("WARNING: The mininum value of the value range of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"I love fuyuncat\""); 
                              str_minValue = "I love fuyuncat";
                            }
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("Date"))
                            {
                              log("WARNING: The mininum value of the value range of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"2004:03:21 00:00:00\""); 
                              str_minValue = "2004:03:21 00:00:00";
                            }
                          }
                          funConfig[findex].minValue[pIndex] = str_minValue;
                          log("The mininum value of the value range of "+pIndex+" parameter of function "+findex+" is: "+str_minValue+"."); 
                        }
  
                        // get the maxinum value of a value range
                        if (nl_valueScopeConfs.item(l).getNodeName().trim().equalsIgnoreCase("maxValue") &&
                            nl_valueScopeConfs.item(l).getNodeType() == Node.ELEMENT_NODE)
                        {
                          if (!funConfig[findex].rangeType[pIndex].equalsIgnoreCase("RANGE"))
                          {
                            log("WARNING: The <maxValue></maxValue> segment should be in a value scope with range type is RANGE, this maxinum value of "+pIndex+" parameter of funtion "+findex+" would be ignored!"); 
                            continue;
                          }
                        
                          String str_maxValue = nl_valueScopeConfs.item(l).getFirstChild().getNodeValue().trim();
                          
                          // check the maxinum value
                          if (str_maxValue == null || str_maxValue.equalsIgnoreCase(""))
                          {
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("int") || funConfig[findex].dataType[pIndex].equalsIgnoreCase("Float"))
                            {
                              log("WARNING: The maxinum value of the value range of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"1\""); 
                              str_maxValue = "1";
                            }
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("String"))
                            {
                              log("WARNING: The maxinum value of the value range of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"I love fuyuncat\""); 
                              str_maxValue = "I love fuyuncat";
                            }
                            if (funConfig[findex].dataType[pIndex].equalsIgnoreCase("Date"))
                            {
                              log("WARNING: The maxinum value of the value range of "+pIndex+" parameter of funtion "+findex+" is NULL. it will reset to \"2004:03:21 00:00:00\""); 
                              str_maxValue = "2005:12:13 00:00:00";
                            }
                          }
                          funConfig[findex].maxValue[pIndex] = str_maxValue;
                          log("The maxinum value of the value range of "+pIndex+" parameter of function "+findex+" is: "+str_maxValue+"."); 
                        }
  
                        // get the select value of a SQL range
                        if (nl_valueScopeConfs.item(l).getNodeName().trim().equalsIgnoreCase("selectValue") &&
                            nl_valueScopeConfs.item(l).getNodeType() == Node.ELEMENT_NODE)
                        {
                          if (!funConfig[findex].rangeType[pIndex].equalsIgnoreCase("SQL"))
                          {
                            log("WARNING: The <selectValue></selectValue> segment should be in a value scope with range type is SQL, this select value of "+pIndex+" parameter of funtion "+findex+" would be ignored!"); 
                            continue;
                          }
                        
                          String str_selectValue = nl_valueScopeConfs.item(l).getFirstChild().getNodeValue().trim();
                          
                          // check the select value
                          if (str_selectValue == null || str_selectValue.equalsIgnoreCase(""))
                          {
                            log("WARNING: The select value of the SQL value of "+pIndex+" parameter of funtion "+findex+" is NULL. this configure will be ignored."); 
                            continue;
                          }
                          funConfig[findex].selectValue[pIndex] = str_selectValue;
                          log("The select value of the SQL value of "+pIndex+" parameter of function "+findex+" is: "+str_selectValue+"."); 
                        }
  
                        // get the from table value of a SQL range
                        if (nl_valueScopeConfs.item(l).getNodeName().trim().equalsIgnoreCase("fromTable") &&
                            nl_valueScopeConfs.item(l).getNodeType() == Node.ELEMENT_NODE)
                        {
                          if (!funConfig[findex].rangeType[pIndex].equalsIgnoreCase("SQL"))
                          {
                            log("WARNING: The <fromTable></fromTable> segment should be in a value scope with range type is SQL, this select value of "+pIndex+" parameter of funtion "+findex+" would be ignored!"); 
                            continue;
                          }
                        
                          String str_fromTable = nl_valueScopeConfs.item(l).getFirstChild().getNodeValue().trim();
                          
                          // check the from table
                          if (str_fromTable == null || str_fromTable.equalsIgnoreCase(""))
                          {
                            log("WARNING: The from table of the SQL value of "+pIndex+" parameter of funtion "+findex+" is NULL. this configure will be ignored."); 
                            continue;
                          }
                          funConfig[findex].fromTable[pIndex] = str_fromTable;
                          log("The from table of the SQL value of "+pIndex+" parameter of function "+findex+" is: "+str_fromTable+"."); 
                        }
  
                        // get the where condition of a SQL range
                        if (nl_valueScopeConfs.item(l).getNodeName().trim().equalsIgnoreCase("whereCondition") &&
                            nl_valueScopeConfs.item(l).getNodeType() == Node.ELEMENT_NODE)
                        {
                          if (!funConfig[findex].rangeType[pIndex].equalsIgnoreCase("SQL"))
                          {
                            log("WARNING: The <whereCondition></whereCondition> segment should be in a value scope with range type is SQL, this select value of "+pIndex+" parameter of funtion "+findex+" would be ignored!"); 
                            continue;
                          }
                        
                          String str_whereCondition = nl_valueScopeConfs.item(l).getFirstChild().getNodeValue().trim();
                          
                          // check the where condition
                          if (str_whereCondition == null || str_whereCondition.equalsIgnoreCase(""))
                          {
                            log("WARNING: The where condition of the SQL value of "+pIndex+" parameter of funtion "+findex+" is NULL. this configure will be ignored."); 
                            continue;
                          }
                          funConfig[findex].whereCondition[pIndex] = str_whereCondition;
                          log("The where condition of the SQL value of "+pIndex+" parameter of function "+findex+" is: "+str_whereCondition+"."); 
                        }
  
                        // get the default value of a SQL range
                        if (nl_valueScopeConfs.item(l).getNodeName().trim().equalsIgnoreCase("defaultValue") &&
                            nl_valueScopeConfs.item(l).getNodeType() == Node.ELEMENT_NODE)
                        {
                          if (!funConfig[findex].rangeType[pIndex].equalsIgnoreCase("SQL"))
                          {
                            log("WARNING: The <defaultValue></defaultValue> segment should be in a value scope with range type is SQL, this select value of "+pIndex+" parameter of funtion "+findex+" would be ignored!"); 
                            continue;
                          }
                        
                          String str_defaultValue = nl_valueScopeConfs.item(l).getFirstChild().getNodeValue().trim();
                          
                          // check the where condition
                          if (str_defaultValue == null || str_defaultValue.equalsIgnoreCase(""))
                          {
                            log("WARNING: The default value of the SQL value of "+pIndex+" parameter of funtion "+findex+" is NULL. this configure will be ignored."); 
                            continue;
                          }
                          funConfig[findex].defaultValue[pIndex] = str_defaultValue;
                          log("The default value of the SQL value of "+pIndex+" parameter of function "+findex+" is: "+str_defaultValue+"."); 
                        }
                      }
                      
                      // set the value number of value list
                      funConfig[findex].valueNum[pIndex] = valueNum+1;
                    }
                  }
  
                  i_paramIndex++;
                  
                  if (funConfig[findex].paraName[pIndex] != null && 
                      !funConfig[findex].paraName[pIndex].equalsIgnoreCase(""))
                  {
                    i_paramNum++;
                  }
                }
                n_param = n_param.getNextSibling();
              }
              
              // set the parameter number
              funConfig[findex].paraNum = i_paramNum;
            }
          }
        }
        
        // check if the stress configed
        if (!hasStressConfig)
        {
          log("WARNING: The function "+findex+" has no stress configures. It will be set default"); 
        }
        
        // check if has function name
        if (!hasFuncionName)
        {
          log("WARNING: The function "+findex+" has no funtion name. It will be ignored"); 
          funConfig[findex].hasConfiged = false;
          funcNum--;
        }
      }
    }
    catch( ParserConfigurationException e)
    {
      log("ERROR: "+"ParserConfigurationException");
      e.printStackTrace();
      System.exit(1);
    }catch(IOException e)      
    {
      log("ERROR: "+"IOException ");
      e.printStackTrace();
      System.exit(1);
    }
    catch(SAXException e)     
    {
      log("ERROR: "+"SAXException ");
      e.printStackTrace();
      System.exit(1);
    }
    catch(Exception e)
    { 
      log("ERROR: "+e.getMessage()); 
      System.exit(1);
    } 
  }

  // check the result type
  private String checkResultType(String functionType, String resultType) {
    // check if null
    if ((functionType.equalsIgnoreCase("function") || 
         functionType.equalsIgnoreCase("sqlStatement")))
    {
      if (resultType == null || resultType.equalsIgnoreCase(""))
      {
        log("ERROR: The result type is NULL."); 
        System.exit(1);
        return "";
      }
      
      if (functionType.equalsIgnoreCase("sqlStatement") &&
          !resultType.equalsIgnoreCase("Cursor"))
      {
        log("ERROR: The result type must be \"Cursor\" when the function type is \"SQLStatement\"."); 
        System.exit(1);
        return "";
      }
    }
    else
    {
      return "";
    }
    
    if (resultType.equalsIgnoreCase("int") ||
        resultType.equalsIgnoreCase("String") ||
        resultType.equalsIgnoreCase("Float") ||
        resultType.equalsIgnoreCase("Date") ||
        resultType.equalsIgnoreCase("Cursor")) 
    {
      return resultType;
    }
    else
    {
      log("ERROR: The reulst type "+resultType+" is invalid!");
      System.exit(1);
      return "";
    }
  }

  // check the data type
  private String checkDataType(String typeName) {
    // check if null
    if (typeName == null || typeName.equalsIgnoreCase(""))
    {
      log("ERROR: The data type is NULL."); 
      System.exit(0);
      return "";
    }
    
    if (typeName.equalsIgnoreCase("int") ||
        typeName.equalsIgnoreCase("String") ||
        typeName.equalsIgnoreCase("Float") ||
        typeName.equalsIgnoreCase("Date") ||
        typeName.equalsIgnoreCase("Cursor")) 
    {
      return typeName;
    }
    else
    {
      log("ERROR: The data type "+typeName+" is invalid!");
      System.exit(0);
      return "";
    }
  }
  
  // check the parameter type
  private String checkParamType(String typeName) {
    // check if null
    if (typeName == null || typeName.equalsIgnoreCase(""))
    {
      log("ERROR: The parameter type is NULL."); 
      System.exit(0);
      return "";
    }
    
    if (typeName.equalsIgnoreCase("int") ||
        typeName.equalsIgnoreCase("String") ||
        typeName.equalsIgnoreCase("Float") ||
        typeName.equalsIgnoreCase("Date")) 
    {
      return typeName;
    }
    else
    {
      log("ERROR: The parameter type "+typeName+" is invalid!");
      System.exit(0);
      return "";
    }
  }
  
  // check the value range type
  private String checkRangeType(String rangeType)
  {
    // check if null
    if (rangeType == null || rangeType.equalsIgnoreCase(""))
    {
      log("ERROR: The range type is NULL."); 
      System.exit(0);
      return "";
    }
    
    if (rangeType.equalsIgnoreCase("LIST") ||
        rangeType.equalsIgnoreCase("RANGE") ||
        rangeType.equalsIgnoreCase("RANGE") ||
        rangeType.equalsIgnoreCase("SQL")) 
    {
      return rangeType;
    }
    else
    {
      log("ERROR: The range type "+rangeType+" is invalid!");
      System.exit(0);
      return "";
    }
  }

  // check the function type
  private String checkFunctionType(String functionType)
  {
    // check if null
    if (functionType == null || functionType.equalsIgnoreCase(""))
    {
      log("ERROR: The function type is NULL."); 
      System.exit(0);
      return "";
    }
    
    if (functionType.equalsIgnoreCase("function") ||
        functionType.equalsIgnoreCase("procedure") ||
        functionType.equalsIgnoreCase("sqlStatement")) 
    {
      return functionType;
    }
    else
    {
      log("ERROR: The funtcion type "+functionType+" is invalid!");
      System.exit(0);
      return "";
    }
  }

  private void log(String logMessage)
  {
    commUtil.log(logMessage);
  }
}//End class MyXMLReader

