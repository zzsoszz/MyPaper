#export CLASSPATH=$CLASSPATH:./ojdbc14_g.jar:.
#java teststress.TestStress
java -jar sqlstress.jar