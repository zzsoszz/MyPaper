Requirement: 
java 1.4.2.09 or up

Set up:
in windows:
set CLASSPATH=%CLASSPATH%;.;<ORACLE_HOME>\jdbc\lib;<ORACLE_HOME>\jdbc\lib\ojdbc14_g.jar
in unix:
export CLASSPATH=$CLASSPATH:.:<ORACLE_HOME>\jdbc\lib:<ORACLE_HOME>\jdbc\lib\ojdbc14_g.jar
where <ORACLE_HOME> is the Oracle home directory.

to test the demo:
1. execute the demo.sql
2. config the init.xml follow its comments.
3. run the SQLStress.bat


WARNING: Strong suggest do NOT run SQLStres in the host which running your Oralce!
WARNING: SQLStress may general high stress, be careful when you using it. 

The trial version limit 5 functions, and 5 threads of each function.

Manual:
1. Config init.xml file follow the comments;
2. If you got the licence key, put the file "licence.key" & "licence.sig" (do NOT change the name) at the same folder of the SQLStress.exe
3. run SQLStress.exe (For first running, you need input the email address you registered)

NOTE: To change to another licence, you need delete the "conf.raw" file.

