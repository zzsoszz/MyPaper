-- Create the user 
create user DEMO
  identified by DEMO
  default tablespace EDGARDEMO
  temporary tablespace TEMP
  profile DEFAULT;

grant dba to DEMO with admin option;
grant alter any sql profile to DEMO;
grant create any sql profile to DEMO;
grant create any table to DEMO;
grant create materialized view to DEMO;
grant create table to DEMO;
grant drop any sql profile to DEMO;
grant global query rewrite to DEMO;
grant select any table to DEMO;
grant unlimited tablespace to DEMO with admin option;

conn demo/demo

create table bigtab as select * from dba_objects;
create table smalltab as select * from dba_tables;

CREATE OR REPLACE PROCEDURE test_sp AS
  v_aaa VARCHAR2(10) := 'aaa';
BEGIN
  dbms_output.put_line(v_aaa);
END;
/

CREATE OR REPLACE FUNCTION test_func(p_owner VARCHAR2) RETURN INTEGER AS
  v_res PLS_INTEGER;
BEGIN
  SELECT COUNT(*)
    INTO v_res
    FROM smalltab a, bigtab b
   WHERE a.owner = b.owner
     AND a.table_name = b.object_name
     AND a.owner = p_owner;

  RETURN v_res;
END;
/
