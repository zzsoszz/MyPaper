Require: java 1.4.1.03 or up
in windows:
set CLASSPATH=%CLASSPATH%;.;<ORACLE_HOME>\jdbc\lib;<ORACLE_HOME>\jdbc\lib\ojdbc14_g.jar
in unix:
export CLASSPATH=$CLASSPATH:.:<ORACLE_HOME>\jdbc\lib:<ORACLE_HOME>\jdbc\lib\ojdbc14_g.jar
where <ORACLE_HOME> is the Oracle home directory.