OraTracer.exe --- For Vista, Win7 32 bit or upper;
OraTracer64.exe --- For Vista, Win7 64 bit or upper;
OraTracerXP.exe --- For XP 32 bit or lower;
OraTracer2003.exe --- For NT 2003 64 bit or upper;

Lastest Version: http://www.hellodba.com/reader.php?ID=122 
