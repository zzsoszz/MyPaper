/* Within a PL/SQL procedure, wrap a query or refcursor in HTML table

An answer to SO question: http://stackoverflow.com/q/7742656

One option is to use hypertext functions [HTF](http://download.oracle.com/docs/cd/E11882_01/appdev.112/e23448/w_htf.htm).

*/

    set linesize 240
    set define off

    create table so14t (id number, data varchar2(25));
    
    insert all
    into so14t values(101, 'one hundred & one')
    into so14t values(202, 'two hundred & two')
    into so14t values(303, 'three hundred & three')
    select 1 from dual;
    
    declare
      v_html varchar2(32767);
    begin
      v_html := htf.tableopen;
    
      for i in (select * from so14t) loop
        v_html := v_html || htf.tablerowopen;
        v_html := v_html || htf.tabledata(i.id);
        v_html := v_html || htf.tabledata(htf.escape_sc(i.data));
        v_html := v_html || htf.tablerowclose;
      end loop;
      
      v_html := v_html || htf.tableclose;
    
      dbms_output.put_line(v_html);
    end;
    /

drop table so14t;

quit
