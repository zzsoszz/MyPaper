create or replace type foo_t is object (
  v_id number,
  v_text varchar2(32676),
  constructor function foo_t return self as result,
  constructor function foo_t(
    p_id in number, 
    p_text in varchar2
  ) return self as result,
  member procedure print
);
/
show errors

create or replace type body foo_t is 
  constructor function foo_t return self as result is
  begin
    v_id := 0;
    v_text := 'nothing';
    return;
  end;

  constructor function foo_t(
    p_id in number, 
    p_text in varchar2
  ) return self as result is
  begin
    v_id := p_id;
    v_text := p_text;
    return;
  end;

  member procedure print is
  begin
    dbms_output.put_line('v_id = ' || v_id || ' v_text = ' || v_text);
  end;
end;
/
show errors

declare
  v_foo foo_t;
begin
  v_foo := foo_t();
  v_foo.print();

  -- default Oracle generated constructor always exists even one can create a
  -- type that has the same constructor -> runtime error only:
  -- PLS-00307: too many declarations of 'FOO_T' match this call
  v_foo := foo_t(1, 'A');
  v_foo.print();
end;
/
