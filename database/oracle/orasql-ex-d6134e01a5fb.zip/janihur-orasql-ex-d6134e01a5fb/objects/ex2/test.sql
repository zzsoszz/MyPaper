declare
  type str_list_t is table of varchar2(32767);
  v_formats str_list_t := str_list_t('BAR', 'foo', 'xxx');
  v_formatter formatter_t;
  v_str varchar2(32676);
begin
  --
  -- using object factory
  --

  for i in v_formats.first .. v_formats.last loop
    v_formatter := formatter_factory_t.make(v_formats(i));

    if v_formatter is not null then
      v_str := v_formatter.head() || chr(10);
      v_str := v_str || v_formatter.line() || chr(10);
      v_str := v_str || v_formatter.tail() || chr(10);
      dbms_output.put(v_str);
    else
      dbms_output.put_line('no such format: ' || v_formats(i));
    end if;
  end loop;

  --
  -- using package factory
  --

  for i in v_formats.first .. v_formats.last loop
    begin
      v_formatter := formatter_factory.make(v_formats(i));
      v_str := v_formatter.head() || chr(10);
      v_str := v_str || v_formatter.line() || chr(10);
      v_str := v_str || v_formatter.tail() || chr(10);
      dbms_output.put(v_str);
    exception
      when formatter_factory.no_such_format then
        dbms_output.put_line('no such format: ' || v_formats(i));
    end;
  end loop;

end;
/
