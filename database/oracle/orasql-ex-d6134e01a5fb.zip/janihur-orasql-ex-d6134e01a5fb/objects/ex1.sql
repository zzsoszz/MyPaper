create or replace type user_role_t as object (
  role varchar2(32767),
  constructor function user_role_t(role in varchar2) return self as result,
  member function is_power_user return number,
  member function str return varchar2
);
/
show errors

create or replace type body user_role_t as
  constructor function user_role_t(role in varchar2) return self as result is
  begin
    if role not in ('user',
                    'advanceduser',
                    'poweruser',
                    'superuser') then
      raise_application_error(-20101, role || ' is not a valid user role.');
    end if;

    self.role := role;

    return;
  end;
  
  member function is_power_user return number is
  begin
    if role in ('advanceduser',
                'poweruser',
                'superuser') then
      return 1;
    end if;
    return 0;
  end;

  member function str return varchar2 is
  begin
    return role;
  end;

end;
/
show errors

select user_role_t('user').is_power_user() from dual;
select user_role_t('user').str() from dual;

select user_role_t('poweruser').is_power_user() from dual;
select user_role_t('poweruser').str() from dual;

select user_role_t('foouser') from dual;

declare
  user_role user_role_t;
begin
  user_role := user_role_t('superuser');
  dbms_output.put_line('str(): ' || user_role.str());
  dbms_output.put_line('is_power_user(): ' || user_role.is_power_user());

  user_role := user_role_t('user');
  dbms_output.put_line('str(): ' || user_role.str());
  dbms_output.put_line('is_power_user(): ' || user_role.is_power_user());

  user_role := user_role_t('wrongrole');
exception
  when others then
    dbms_output.put_line('exception: ' || dbms_utility.format_error_stack ||
                         dbms_utility.format_error_backtrace);
end;
/

drop type user_role_t;

quit
