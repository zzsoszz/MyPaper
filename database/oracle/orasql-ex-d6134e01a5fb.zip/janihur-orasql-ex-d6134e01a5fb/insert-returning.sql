--
-- see: http://www.adp-gmbh.ch/ora/sql/insert_into_x_returning_y.html
-- note: doesn't work over database link
--
create table auto_increment (
  id                number not null constraint pk_ai primary key,
  something         number
); 

create sequence seq_auto_increment start with 1 increment by 1;

create or replace trigger ai 
  before insert on auto_increment
  for each row
  begin
    if :new.id is null then
      select seq_auto_increment.nextval into :new.id from dual;
    end if;
  end;
/

variable id number

insert into auto_increment(something)values(100) returning id into :id;
select :id from dual;
