ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

DROP TABLE users;

CREATE TABLE users (
    username VARCHAR2(8) UNIQUE,
    accessed_at DATE,
    superuser NUMBER(1,0)
);

INSERT INTO users VALUES ('janihur',  sysdate,      0);
INSERT INTO users VALUES ('petdance', sysdate - 12, 1);
INSERT INTO users VALUES ('albundy',  sysdate - 3,  0);
INSERT INTO users VALUES ('donduck',  sysdate - 18, 0);

/*

prompt Static SQL should be always preferred
prompt =====================================

CREATE OR REPLACE FUNCTION user_access (
    p_uname IN VARCHAR2
) RETURN date AS
    v_accessed_at date;
BEGIN
    SELECT accessed_at INTO v_accessed_at FROM users WHERE username = p_uname;
    RETURN v_accessed_at;
END;
/
show errors

SELECT user_access('janihur')
  AS "JANIHUR LAST SEEN" FROM DUAL;
SELECT user_access('whocares'' or superuser = 1 or username = ''whocares') 
  AS "SUPERUSER LAST SEEN" FROM DUAL;

prompt
prompt Dynamic SQL with string concatenation
prompt =====================================

CREATE OR REPLACE FUNCTION user_access (
    p_uname IN VARCHAR2
) RETURN date AS
    v_accessed_at date;
    v_query constant varchar2(32767) := 
      'SELECT accessed_at FROM users WHERE username = ''' || p_uname || '''';
BEGIN
    EXECUTE IMMEDIATE v_query INTO v_accessed_at;
    RETURN v_accessed_at;
END;
/
show errors;

SELECT user_access('janihur')
  AS "JANIHUR LAST SEEN" FROM DUAL;
SELECT user_access('whocares'' or superuser = 1 or username = ''whocares') 
  AS "SUPERUSER LAST SEEN" FROM DUAL;

prompt
prompt Dynamic SQL with bind variables
prompt ===============================

CREATE OR REPLACE FUNCTION user_access (
    p_uname IN VARCHAR2
) RETURN date AS
    v_accessed_at date;
    v_query constant varchar2(32767) := 
      'SELECT accessed_at FROM users WHERE username = :a';
BEGIN
    EXECUTE IMMEDIATE v_query INTO v_accessed_at USING p_uname;
    RETURN v_accessed_at;
END;
/
show errors;

SELECT user_access('janihur')
  AS "JANIHUR LAST SEEN" FROM DUAL;
SELECT user_access('whocares'' or superuser = 1 or username = ''whocares') 
  AS "SUPERUSER LAST SEEN" FROM DUAL;

prompt
prompt Data type conversion exploit
prompt ============================

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

CREATE OR REPLACE TYPE userlist_t AS TABLE OF VARCHAR2(8);
/

CREATE OR REPLACE FUNCTION users_since(
    p_since IN DATE
) RETURN userlist_t PIPELINED AS
    v_users userlist_t;
    v_query constant varchar2(32767) := 
      'SELECT username FROM users WHERE superuser = 0 and accessed_at > ''' || p_since || ''' order by accessed_at desc';
BEGIN
    DBMS_OUTPUT.PUT_LINE('v_query = ' || v_query);
    EXECUTE IMMEDIATE v_query BULK COLLECT INTO v_users;

    FOR i IN v_users.FIRST .. v_users.LAST LOOP
      PIPE ROW(v_users(i));
    END LOOP;

    RETURN;
END;
/
show errors;

prompt
prompt Note how the value of NLS_DATE_FORMAT affects to the query string 
prompt in users_since()-function !

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD"SUPRISE!"';
SELECT COLUMN_VALUE AS "REGULARS" FROM TABLE(users_since(sysdate - 30));

ALTER SESSION SET NLS_DATE_FORMAT = '"'' or superuser = 1 or username = ''whocares"';
SELECT COLUMN_VALUE AS "SUPERUSER IS" FROM TABLE(users_since(sysdate - 30));

*/

prompt
prompt Safe data type conversion
prompt =========================

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

CREATE OR REPLACE TYPE userlist_t AS TABLE OF VARCHAR2(8);
/

CREATE OR REPLACE FUNCTION users_since(
    p_since IN DATE
) RETURN userlist_t PIPELINED AS
    v_users userlist_t;
    v_query constant varchar2(32767) := 
      'SELECT username FROM users WHERE superuser = 0 and accessed_at > ''' || to_char(p_since, 'YYYY-MM-DD') || ''' order by accessed_at desc';
BEGIN
    DBMS_OUTPUT.PUT_LINE('v_query = ' || v_query);
    EXECUTE IMMEDIATE v_query BULK COLLECT INTO v_users;

    FOR i IN v_users.FIRST .. v_users.LAST LOOP
      PIPE ROW(v_users(i));
    END LOOP;

    RETURN;
END;
/
show errors;

prompt
prompt Suprise does not work anymore - no more SQL injection !

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD"SUPRISE!"';
SELECT COLUMN_VALUE AS "REGULARS" FROM TABLE(users_since(sysdate - 30));
