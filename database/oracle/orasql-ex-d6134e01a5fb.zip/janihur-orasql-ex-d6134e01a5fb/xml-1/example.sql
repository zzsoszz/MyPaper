drop table test;

drop view test_foo;

drop view test_foo_events;

-- NOTE pay close attention to the Schema URL and Schema file names !

declare
  schemaurl constant varchar2(40) := 'xml-1/example.xsd';
  schemafile constant varchar2(40) := 'xml-1-example.xsd';
begin
  declare
    already_unregistered exception;
    pragma exception_init(already_unregistered, -31000);
  begin
    dbms_xmlschema.deleteschema(schemaurl, dbms_xmlschema.delete_cascade);
  exception
    when already_unregistered then null;
  end;

  -- TODO: add annotation to get a predefined table name !

  dbms_xmlschema.registerschema(schemaurl => schemaurl,
				schemadoc => bfilename('DATA_TALOUS', schemafile),
				local => true,
				gentypes => true,
				genbean => false,
				gentables => true,
				force => false,
				owner => '',
				csid => nls_charset_id('AL32UTF8'),
				enablehierarchy => dbms_xmlschema.enable_hierarchy_contents,
				options => 0
				);
end;
/

col schema_url format a30;
select schema_url from user_xml_schemas;
select xmlserialize(content schema as varchar2(4000)) from user_xml_schemas where schema_url = 'xml-1/example.xsd';

select table_name, storage_type from user_xml_tables where xmlschema = 'xml-1/example.xsd';

create table test (
  id integer,
  xml xmltype
)
xmltype column xml xmlschema "xml-1/example.xsd" element "example";

-- insert makes only a partial validation
-- http://download.oracle.com/docs/cd/E11882_01/appdev.112/e16659/xdb03usg.htm#autoId44

-- so according to documentation this should be inserted, but suprisingly it's
-- not, but the validation fails
insert into test(id, xml) values (1, xmltype(bfilename('DATA_TALOUS', 'xml-1-example-1.xml'), nls_charset_id('AL32UTF8')));

-- this should fail as XML is not conforming the schema at all
insert into test(id, xml) values (2, xmltype(bfilename('DATA_TALOUS', 'xml-1-example-2.xml'), nls_charset_id('AL32UTF8')));

-- strictly conforming that is inserted correctly
insert into test(id, xml) values (3, xmltype(bfilename('DATA_TALOUS', 'xml-1-example-3.xml'), nls_charset_id('AL32UTF8')));

-- select xmlserialize(content xml as varchar2(4000)) from test;

col xmlschema format a25
col element_name format a25
select table_name, xmlschema, element_name from user_xml_tables;

/*
select * from user_dependencies d, user_xml_schemas x
where d.referenced_type = 'XML SCHEMA'
and d.referenced_name = x.int_objname
and x.schema_url = 'xml-1/example.xsd';
*/

-- note 'xml' below is a column name !
select xmlquery('/example/foo[1]' passing xml returning content) from test;

select test.id, xmldata.description, xmldata.time1, xmldata.time2
from test,
     xmltable('/example/foo' passing test.xml
	      columns description varchar2(22) path 'desc',
	              time1 varchar2(35) path 'time',
	              time2 timestamp with time zone path 'time'
	      ) xmldata;

-- Accessing XML Data in Oracle XML DB using Relational Views
-- http://download.oracle.com/docs/cd/E11882_01/appdev.112/e16659/xdb03usg.htm#autoId56

create or replace view test_foo as
select test.id as test_id, foo.*
from test,
     xmltable('/example/foo' passing test.xml
	      columns
	      id number path '@id',
	      "DESC" varchar2(40) path 'desc',
	      "TIME" timestamp with time zone path 'time'
	      ) foo;

create or replace view test_foo_events as
select f.id, e.*
from test,
     xmltable('/example/foo' passing test.xml
	      columns
	      id number path '@id',
	      events xmltype path 'events'
	      ) f,
     xmltable('/events/event' passing f.events
	      columns
	      "DESC" varchar2(40) path 'desc',
	      "TIME" timestamp with time zone path 'time'
	      ) e;
