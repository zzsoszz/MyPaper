/* Transaction behaviour when rolling back to a savepoint for a bulk update in
the middle of processing several sets of rows.

Rolling back to savepoint undoes only the changes taking place between
savepoint command.

How to process bulk exceptions.

*/

drop table test_data;

create table test_data as
select rownum as id,
       1 as subid,
       'This is a row #' || rownum as str,
       current_timestamp(3) as time_
from dual
connect by level <= 100;

insert into test_data
select id, 
       2,
       str,
       current_timestamp(3)
from test_data
where subid = 1
;

insert into test_data
select id, 
       3,
       str,
       current_timestamp(3)
from test_data
where subid = 1
;

insert into test_data
select id, 
       4,
       str,
       current_timestamp(3)
from test_data
where subid = 1
;

column id format 999
column subid format 999
column str format a25
column time_ format a30

select * from test_data where id <= 10 order by id, subid;

declare
  bulk_ex exception;
  pragma exception_init(bulk_ex, -24381);
  
  type data_t is record ( subid number, str varchar2(4000) );
  type data_list_t is table of data_t;

  v_data data_list_t := data_list_t();

  -- call only in exception handler
  function bulk_exceptions_to_str return varchar2
  is
    v_str varchar2(32767);
  begin
    -- need to test error code explicitly as if there has been earlier bulk
    -- exception the data structure is not cleaned
    if sqlcode = -24381 then
      v_str := 'BULK_EXCEPTIONS: ';
      for i in 1 .. sql%bulk_exceptions.count
      loop
        v_str := v_str ||
          '(' || i || ' = ((error_index = ' || sql%bulk_exceptions(i).error_index ||
          ')(error_code = ' || sqlerrm(-1 * sql%bulk_exceptions(i).error_code) ||
          ')))';
      end loop;
    end if;

    return v_str;
  end;
begin
  v_data.extend(4);

  v_data(1).subid := 1;
  v_data(1).str := 'new data for subid = 1';

  v_data(2).subid := 2;
  v_data(2).str := 'new data for subid = 2';

  v_data(3).subid := 3;
  v_data(3).str := 'new data for subid = 3';
  
  v_data(4).subid := 4;
  v_data(4).str := 'new data for subid = 4';
  
  for i in 1 .. 10 loop
    savepoint row_processing_starts;

    begin
      -- modify even ids
      if mod(i, 2) = 0 then
        if i = 4 then
          raise no_data_found;
        end if;
        if i in(2, 8) then
          v_data(3).str := 'new data for subid = 3 that is far far far far far far too olong to fit in the column';
        else
          v_data(3).str := 'new data for subid = 3';
        end if;
        forall j in 1 .. v_data.count
          save exceptions
          update test_data
             set str = v_data(j).str,
                 time_ = systimestamp
           where id = i
             and subid = v_data(j).subid
          ;
      end if;
    exception
      when bulk_ex or no_data_found then
        rollback to row_processing_starts;
        dbms_output.put_line(rpad('-', 79, '-'));
        dbms_output.put_line('EXCEPTION: id = ' || i);
        dbms_output.put_line('STACK TRACE: ' ||
                             dbms_utility.format_error_stack ||
                             dbms_utility.format_error_backtrace);
        declare
          v_bulk_error_text constant varchar2(32767) := bulk_exceptions_to_str;
        begin
          if v_bulk_error_text is not null then
            dbms_output.put_line(v_bulk_error_text);
          end if;
        end;
    end;
    
  end loop;

end;
/

select * from test_data where id <= 10 order by id, subid;

quit
