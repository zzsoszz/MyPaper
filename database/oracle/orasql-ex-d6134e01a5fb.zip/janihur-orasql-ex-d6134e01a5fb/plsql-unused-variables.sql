--
-- Oracle 11g – Generating PL/SQL Compiler Warnings (Java style) using PL/Scope 
--
-- http://technology.amis.nl/2007/11/14/oracle-11g-generating-plsql-compiler-warnings-java-style-using-plscope/
--
-- http://docs.oracle.com/cd/E11882_01/appdev.112/e41502/adfns_plscope.htm
-- 
-- alter session set plscope_settings = 'identifiers:all';
--
-- and re-compile PL/SQL code
--

with 
identifiers as (
  select name
  ,      type
  ,      usage
  ,      line
  ,      first_value(line) over (partition by name, usage order by line asc ) as first_line
  ,      first_value(line) over (partition by name, usage order by line desc) as last_line
  from   user_identifiers
  where  object_name = upper('&name')
  and    object_type = upper('&type')
  and    type        = 'VARIABLE'
),
last_assignments as (
  select *
  from   identifiers
  where  usage = 'ASSIGNMENT'
  and    line = last_line
),
last_references as (
  select *
  from   identifiers
  where  usage = 'REFERENCE'
  and    line = last_line
),
first_references as (
  select *
  from   identifiers
  where  usage = 'REFERENCE'
  and    line = first_line
),
first_assignments as (
  select *
  from   identifiers
  where  usage = 'ASSIGNMENT'
  and    line = first_line
),
declarations as (
  select *
  from   identifiers
  where  usage = 'DECLARATION'
)
select
  case
    when la.line is null then 
      name || ': reference on line ' || lr.line || ' but variable may not be initialized (assigned a value)'
    when  lr.line is null then
      name || ': a value is assigned, but there is no reference to the variable'
    when la.line > lr.line then
      name || ': assignment on line ' || la.line || ' is never used. Last reference to the variable is on line ' || lr.line
  end as compiler_warning
from last_assignments la
full outer join last_references lr using(name)
union all
select
  case
    when fa.line > fr.line then
      name || ': reference to variable on line ' || fr.line || ' comes before the earliest assignment. Variable may not have been initialized on line ' || fr.line
  end as compiler_warning
from first_assignments fa
full outer join first_references fr using(name)
union all
select 
  case
    when fr.line is null then
      name || ': variable is declared but never used (line ' || de.line || ')'
  end as compiler_warning
from declarations de
full outer join last_references fr using(name)
;
