/* XML DOM. Get element by name on first child level

An answer to SO question: http://stackoverflow.com/q/9129147/
*/

declare
  xml constant xmltype := xmltype(
'<root>
  <element1>
     <doc>2 - two</doc>
  </element1>
  <doc>1 - one</doc>
</root>'
);
  doc constant dbms_xmldom.domdocument := dbms_xmldom.newdomdocument(xml);
  
  root_elem constant dbms_xmldom.domelement :=
    dbms_xmldom.getdocumentelement(doc);
  
  doc_nodes constant dbms_xmldom.domnodelist :=
    dbms_xmldom.getchildrenbytagname(root_elem, 'doc');
begin
  declare
    last_index constant pls_integer := dbms_xmldom.getlength(doc_nodes) - 1;
    node dbms_xmldom.domnode;
    text_node dbms_xmldom.domnode;
  begin
    for i in 0 .. last_index loop
      node := dbms_xmldom.item(doc_nodes, i);
      text_node := dbms_xmldom.getfirstchild(node);
      dbms_output.put_line('i = ' || i ||
                           ' name = ' || dbms_xmldom.getnodename(node) ||
                           ' type = ' || dbms_xmldom.getnodetype(node) ||
                           ' text = ' || dbms_xmldom.getnodevalue(text_node));
    end loop;
  end;
end;
/
