-- Posted to OTN:
-- http://forums.oracle.com/forums/thread.jspa?threadID=2251240

/* How to update relational table with data from XML ? 

I'm receiving an XML messages that includes a bunch of data that should be updated into a table. For each received message an arbitrary subset of rows will be updated.

The output of the example below is correct, but the use of intermediate table bothers me. Can the temp table be eliminated in some way ? Or is the most reasonable way to just explicitly loop and parse the XML message and then update every single row separately ?

I'm running 

*/

select banner as version from v$version where banner like 'Oracle%';

/*
VERSION
------------------------------------------------------------------------------
Oracle Database 11g Release 11.2.0.1.0 - 64bit Production
*/

create table otn9test (
  id number not null primary key,
  data xmltype
);

insert into otn9test values (1, xmltype('<data>default for 1</data>'));
insert into otn9test values (2, xmltype('<data>default for 2</data>'));
insert into otn9test values (3, xmltype('<data>default for 3</data>'));

create table otn9input (
  id number,
  data xmltype
);

column data format a30

declare
  updata constant xmltype := xmltype('<root>
  <item>
    <id>1</id>
    <data>Id 1 updated.</data>
  </item>
  <item>
    <id>3</id>
    <data>Id 3 updated.</data>
  </item>
  <item>
    <id>4</id>
    <data>Id 4 updated.</data>
  </item>
</root>');

begin
  /* This works fine, but requires a temp table. */
  /*
  insert into otn9input
    select * from
    xmltable('/root/item' passing updata
	     columns
	     id number path 'id',
	     data xmltype path 'data');

  update otn9test t set data = (
    select data from otn9input i
    where t.id = i.id
  ) where t.id in (select id from otn9input);
  */

  /* ANSWER */
  merge into otn9test t
    using (
      select id, data 
        from xmltable('/root/item' passing updata
		      columns
		      id   number  path 'id',
		      data xmltype path 'data'
		      )
    ) x
    on ( t.id = x.id )
    when matched then update
    set t.data = x.data
  ;

  commit;
end;
/

select * from otn9input;

/*
	ID DATA
---------- ------------------------------
	 1 <data>Id 1 updated.</data>
	 3 <data>Id 3 updated.</data>
	 4 <data>Id 4 updated.</data>
*/

select * from otn9test;

/*
	ID DATA
---------- ------------------------------
	 1 <data>Id 1 updated.</data>
	 2 <data>default for 2</data>
	 3 <data>Id 3 updated.</data>
*/

drop table otn9input;
drop table otn9test;

quit
