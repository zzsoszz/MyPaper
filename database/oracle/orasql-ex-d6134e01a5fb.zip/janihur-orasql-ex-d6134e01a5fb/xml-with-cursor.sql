declare
  data_ constant xmltype := xmltype('<root>
  <set><item>This is first dataset.</item></set>
  <set><item>This is second dataset.</item></set>
  <set><item>This is third dataset.</item></set>
</root>');

  cursor set_cur is
    select * from xmltable('/root/set' passing data_
			   columns
			   set_elem xmltype path '.');

  set_elem xmltype;
  value_ varchar2(30);
begin  
  open set_cur;
  
  fetch set_cur into set_elem;
  while set_cur%found loop
      select * into value_ from xmltable('/set' passing set_elem
					 columns
					 item_elem varchar2(30) path 'item');
    dbms_output.put_line('looping: ' || value_);
    fetch set_cur into set_elem;
  end loop;

  close set_cur;
end;
/
