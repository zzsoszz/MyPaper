--
-- How to calculate quarters
--

drop table lots_of_dates
;

create table lots_of_dates as
select trunc(sysdate - level * 7) as d
from dual
connect by level <= 52
;

select d,
       to_char(d, 'YYYY-Q') as QUARTER,
       trunc(d, 'Q') as Q_FIRST_DAY,
       add_months(trunc(d, 'Q'), 3) - 1 as Q_LAST_DAY
  from lots_of_dates
 order by 1
;

select to_char(d, 'YYYY-Q') as quarter,
       count(*)
  from lots_of_dates d
 group by to_char(d, 'YYYY-Q')
 order by 1
;
