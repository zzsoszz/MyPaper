create or replace package DYNCUR2 as
  type strlist is table of varchar2(32767);

  subtype tab_rowtype_t is tab%rowtype;
  -- strongly typed row cursor variable
  type tab_cursor_t is ref cursor return tab_rowtype_t;

  -- function that generates a cursor
  function make(
    filter in strlist default strlist()
  ) return tab_cursor_t;

  -- procedure that generates a cursor
  procedure get(cur out tab_cursor_t);
end;
/
show errors

create or replace package body DYNCUR2 as
  function make(
    filter in strlist default strlist()
  ) return tab_cursor_t as
    curid number;
    st varchar2(200) := 'select * from tab where tabtype = ''TABLE'' and tname not like ''BIN$%''';
    trash integer;
  begin
    curid := dbms_sql.open_cursor;

    if filter.count > 0 then
      dbms_output.put_line('We have a filter !');
      for i in filter.first .. filter.last loop
        st := st || ' and tname not like ''' || filter(i) || ''' escape ''\''';
      end loop;
    end if;

    st := st || ' order by tname';

    dbms_output.put_line('st = ' || st);
    
    dbms_sql.parse(curid, st, dbms_sql.native);

    trash := dbms_sql.execute(curid);
    return dbms_sql.to_refcursor(curid);
  end;

  procedure get(cur out tab_cursor_t) as
  begin
    cur := make;
  end;
end;
/
show errors

declare
  cur DYNCUR2.tab_cursor_t := DYNCUR2.make;
  rec DYNCUR2.tab_rowtype_t;
begin
  dbms_output.put_line('== DYNCUR2.make - while loop');
  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line('table: ' || rec.tname);
    fetch cur into rec;
  end loop;
  close cur;

  dbms_output.put_line('== DYNCUR2.make(DYNCUR2.strlist(''H\_%'')) - while loop');
  cur := DYNCUR2.make(DYNCUR2.strlist('H\_%'));
  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line('table: ' || rec.tname);
    fetch cur into rec;
  end loop;
  close cur;

  dbms_output.put_line('== DYNCUR2.make(DYNCUR2.strlist(''H\_%'', ''PLSQL\_%'')) - while loop');
  cur := DYNCUR2.make(DYNCUR2.strlist('H\_%', 'PLSQL\_%'));
  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line('table: ' || rec.tname);
    fetch cur into rec;
  end loop;
  close cur;

  dbms_output.put_line('== DYNCUR2.get - plain loop');
  DYNCUR2.get(cur);
  loop
    fetch cur into rec;
    exit when cur%notfound;
    dbms_output.put_line('table: ' || rec.tname);
  end loop;
  close cur;

  dbms_output.put_line('== DYNCUR2.get - while loop');
  DYNCUR2.get(cur);
  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line('table: ' || rec.tname);
    fetch cur into rec;
  end loop;
  close cur;

/* Doesn't work
  dbms_output.put_line('== DYNCUR2.get - cursor for loop');
  DYNCUR2.get(cur);
  for row_ in cur loop
    dbms_output.put_line('table: ' || rec.tname);
  end loop;
  close cur;
*/
end;
/
