/* What data structure to use in order to sort this data in PL/SQL?

An answer to SO question: http://stackoverflow.com/q/22177780/272735

*/

create or replace package so36 is
  -- input data structures
  type rec_t is record (
    iter number,
    str varchar2(20),
    int number
  );

  type rec_list_t is table of rec_t;

  function to_str(p_list in rec_list_t, p_sort in varchar2 default 'S')
  return varchar2;
end;
/
show errors

create or replace package body so36 is
  function to_str(p_list in rec_list_t, p_sort in varchar2 default 'S')
  return varchar2 is
    v_sep constant varchar2(2) := ', ';
    v_ret varchar2(32767);
  begin
    if p_sort = 'S' then
      -- create associative array (map) v_map where key is rec_t.str
      -- this means the records are sorted by rec_t.str
      declare
        type map_t is table of rec_t index by varchar2(20);
        v_map map_t;
        v_key varchar2(20);
      begin
        -- populate the map
        for i in p_list.first .. p_list.last loop
          v_map(p_list(i).str) := p_list(i);
        end loop;

        v_key := v_map.first;

        -- generate output string
        while v_key is not null loop
          v_ret := v_ret || v_map(v_key).str || v_sep;
          v_key := v_map.next(v_key);
        end loop;
      end;
    elsif p_sort = 'I' then
      -- this branch is identical except the associative array's key is
      -- rec_t.int and thus the records are sorted by rec_t.int
      declare
        type map_t is table of rec_t index by pls_integer;
        v_map map_t;
        v_key pls_integer;
      begin
        for i in p_list.first .. p_list.last loop
          v_map(p_list(i).int) := p_list(i);
        end loop;

        v_key := v_map.first;
        
        while v_key is not null loop
          v_ret := v_ret || v_map(v_key).str || v_sep;
          v_key := v_map.next(v_key);
        end loop;
      end;
    end if;
      
    return rtrim(v_ret, v_sep);
  end;
end;
/
show errors

declare
  v_list so36.rec_list_t := so36.rec_list_t();
  v_item so36.rec_t;
begin
  v_item.iter := 1;
  v_item.str := 'Oslo';
  v_item.int := 40;

  v_list.extend(1);
  v_list(v_list.last) := v_item;

  v_item.iter := 2;
  v_item.str := 'Berlin';
  v_item.int := 74;

  v_list.extend(1);
  v_list(v_list.last) := v_item;

  v_item.iter := 3;
  v_item.str := 'Rome';
  v_item.int := 25;

  v_list.extend(1);
  v_list(v_list.last) := v_item;

  v_item.iter := 4;
  v_item.str := 'Paris';
  v_item.int := 10;
  
  v_list.extend(1);
  v_list(v_list.last) := v_item;

  dbms_output.put_line(so36.to_str(v_list));
  dbms_output.put_line(so36.to_str(v_list, 'I'));
end;
/
show errors
