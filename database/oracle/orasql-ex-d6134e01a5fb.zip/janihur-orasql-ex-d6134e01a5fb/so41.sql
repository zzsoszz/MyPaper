/* PL/SQL where current of doesn't work with SQL update returning

PL/SQL currect of and SQL returning can't be used at the same time.

Instead use rowid and returning.

Inspired by a SO question.

*/

create table so41t (
  id number,
  value number
);

insert all
into so41t values(1, 1)
into so41t values(2, 2)
into so41t values(3, 3)
into so41t values(4, 4)
select 1 from dual;

create or replace procedure so41 is
  v_new number;
  cursor values_ is
    select * from so41t order by id for update of value;
begin
  for r in values_
  loop
    -- PL/SQL: ORA-00933: SQL command not properly ended
    update so41t s
       set s.value = s.value * 2
     where current of values_
 returning s.value into v_new;
  
    dbms_output.put_line('id: ' || r.id ||
                         ' old: ' || r.value ||
                         ' new: ' || v_new);
  end loop;
end;
/
show errors

create or replace procedure so41 is
  v_new number;
  cursor values_ is
    select rowid, id, value from so41t order by id;
begin
  for r in values_
  loop
    update so41t
       set value = value * 2
     where rowid = r.rowid
 returning value into v_new;

  dbms_output.put_line('id: ' || r.id ||
                       ' old: ' || r.value ||
                       ' new: ' || v_new);
  end loop;
end;
/
show errors
