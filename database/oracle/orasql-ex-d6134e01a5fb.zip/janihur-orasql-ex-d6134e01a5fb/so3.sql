/* PLSQL, execure formula stored in a table

An answer to a question:
http://stackoverflow.com/questions/6900300/plsql-execure-formula-stored-in-a-table/6901077#6901077
*/

create table formulas (
  id number,
  name varchar2(20),
  formula varchar2(50)
);

insert into formulas values (1, 'test 1', 'prm_testval*prm_percent/18');
insert into formulas values (2, 'test 2', '(prm_testval +20)*prm_percent');

/* eval from: http://www.adp-gmbh.ch/blog/2005/may/5.html */
create or replace function eval (
 expr in varchar2
) return varchar2 as 
  ret varchar2(32767);
begin
  execute immediate 'begin :result := ' || expr || '; end;' using out ret;
  return ret;
end;
/

create or replace function eval2 (
  vars in varchar2,
  expr in varchar2
) return varchar2 as 
  ret varchar2(32767);
begin
  execute immediate vars || ' begin :result := ' || expr || '; end;' using out ret;
  return ret;
end;
/

create or replace function calc_prm (
  id_ in number,
  prm_testval in varchar2, 
  prm_percent in varchar2
) return number as
  formula_ formulas.formula%type;
  vars constant varchar2(32767) := 
    'declare prm_testval constant number := to_number(' || prm_testval ||
    '); prm_percent constant number := to_number(' || prm_percent || ');';
begin
  select formula into formula_ from formulas where id = id_;
  return eval2(vars, formula_);
end;
/

create or replace function calc_prm2 (
  id_ in number,
  prm_testval in number, 
  prm_percent in number
) return number as
  formula_ formulas.formula%type;
  decl constant varchar2(32767) := 
    'declare prm_testval constant number := :a; prm_percent constant number := :b;';
  query varchar2(32676);
  ret number;
begin
  select formula into formula_ from formulas where id = id_;
  /* Why I can't use a bind variable for formula_ ? */
  query := decl || ' begin :result := ' || formula_ || '; end;';
  --dbms_output.put_line(query);
  execute immediate query using in prm_testval, in prm_percent, out ret;
  return ret;
end;
/

/* call from SQL */
select eval('3*4') from dual;
select calc_prm(1, '97', '10') from dual;
select calc_prm(2, 97, 10) from dual;
select calc_prm2(1, 97, 10) from dual;
select calc_prm2(2, 97, 10) from dual;

/* call from PL/SQL block */
begin
  dbms_output.put_line(eval('3*4'));
  dbms_output.put_line(calc_prm(1, 97, 10));
  dbms_output.put_line(calc_prm(2, 97, 10));
  dbms_output.put_line(calc_prm2(1, 97, 10));
  dbms_output.put_line(calc_prm2(2, 97, 10));
end;
/

drop function calc_prm;
drop function eval2;
drop function eval;
drop table formulas;
