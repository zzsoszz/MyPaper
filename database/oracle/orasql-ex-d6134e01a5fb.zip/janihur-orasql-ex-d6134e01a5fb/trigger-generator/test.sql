declare
  ret boolean;
begin
  assert.isfalse(trigger_generator.table_exists('foo'),
		 'foo table shouldn''t exists');

  assert.istrue(trigger_generator.table_exists('contact'),
		'contact table should exists');
exception
  when assert.failure then
    dbms_output.put_line('FAILURES !');
end;
/
