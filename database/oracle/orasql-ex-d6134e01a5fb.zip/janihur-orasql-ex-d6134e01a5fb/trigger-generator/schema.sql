create sequence seq_contact start with 1000 increment by 1 nocache nocycle;

create table contact (
  contact_id integer,
  first_name varchar2(120 char),
  last_name varchar2(120 char),
  last_update_date date
);

alter table contact add constraint pk_contact primary key (contact_id);
