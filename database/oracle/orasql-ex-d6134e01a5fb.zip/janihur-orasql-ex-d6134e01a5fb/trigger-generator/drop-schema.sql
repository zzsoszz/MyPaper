drop table contact;
drop sequence seq_contact;
