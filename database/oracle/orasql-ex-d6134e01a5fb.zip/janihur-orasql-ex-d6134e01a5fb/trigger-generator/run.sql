-- $ sqlplus @run.sql

@drop-schema.sql
@schema.sql
@trigger-generator.sql
-- run-generator.sql creates tr_contact.sql
@run-generator.sql tr_contact.sql contact
@tr_contact.sql

quit
