/* SQL*Plus script to generate a trigger PL/SQL code

Usage: $ sqlplus @run-generator.sql <FILE_NAME> <TABLE_NAME>

*/

@trigger-generator.sql

set echo off
set embedded on
set feedback off
set heading off
set linesize 32000
set markup html off
set newpage 0
set pagesize 0
set serveroutput on
set space 0
set trimspool on
set verify off

spool &1

-- TODO: annoying arbitrary linebreaks, seems to be a sqlplus feature ?
declare
begin
  dbms_output.put_line(trigger_begin('&2'));
  dbms_output.put_line(trigger_seq('&2'));
  dbms_output.put_line(trigger_status('&2'));
  dbms_output.put_line(trigger_body('&2'));
  dbms_output.put_line(trigger_end);
end;
/

spool off

quit
