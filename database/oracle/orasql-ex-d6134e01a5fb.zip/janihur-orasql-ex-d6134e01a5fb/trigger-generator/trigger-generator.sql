create or replace package trigger_generator as
  non_existing_table exception;

  /* Generates a trigger by calling helpers listed below. Throws
     'non_existing_table' if table doesn't exists. */
  function gen(table_name in varchar2) return varchar2;

  /* Helpers that create a part of the trigger. Call in order: */
  function head(table_name in varchar2) return varchar2;
  function seq(table_name in varchar2) return varchar2;
  function status(table_name in varchar2) return varchar2;
  function body(table_name_ in varchar2) return varchar2;
  function tail return varchar2;

  /* Other helpers */
  function table_exists(table_name in varchar2) return boolean;
end;
/

create or replace package body trigger_generator as
  function nl return char as begin return chr(10); end;

  procedure check_table(
    table_name in varchar2
  ) as
  begin
    if not table_exists(table_name) then
      raise non_existing_table;
    end if;
  end;

  function gen(
    table_name in varchar2
  )
  return varchar2 as
  begin
    check_table(table_name);

    return head(table_name) || nl ||
    	   seq(table_name) || nl ||
	   nl ||
	   status(table_name) || nl ||
	   nl ||
	   body(table_name) || nl ||
	   tail
	   ;
  end;

  function head(
    table_name in varchar2
  )
  return varchar2 as
    trigger_name varchar2(60) := 'tr_' || table_name;
    h_table_name varchar2(60) := 'h_' || table_name;
  begin
    return 
'create or replace trigger ' || trigger_name || nl ||
'before insert or delete or update on ' || table_name || nl ||
'for each row' || nl ||
'declare' || nl ||
'  v_audit ' || h_table_name || '%rowtype;' || nl ||
'begin'
    ;
  end;

  function seq(
    table_name in varchar2
  )
  return varchar2 as
  begin
    return
'  select seq_' || table_name || '.nextval into v_audit.version_id from dual;'
    ;
  end;

  function status(
    table_name in varchar2
  )
  return varchar2 as
  begin
    return
'  case' || nl ||
'    when inserting then v_audit.status := ''I'';' || nl ||
'    when updating then v_audit.status := ''U'';' || nl ||
'    when deleting then v_audit.status := ''D'';' || nl ||
'    else raise value_error; -- unnecessary ?' || nl ||
'  end case;'
    ;
  end;

  function body(
    table_name_ in varchar2
  )
  return varchar2 as
    block varchar2(32000) := 
'  if not deleting then' || nl ||
'    :new.last_update_date := sysdate;' || nl ||
'  end if;' || nl
    ;

    cursor columns_ is
      select column_name from user_tab_columns 
      where table_name = upper(table_name_);
  begin
    block := block || nl || 
'  if inserting or updating then' || nl;

    for row_ in columns_
    loop
      block := block ||
'    v_audit.' || row_.column_name || ' := :new.' || row_.column_name || ';' || nl;
    end loop;

    block := block || 
'  else --deleting' || nl;

    for row_ in columns_
    loop
      block := block || 
'    v_audit.' || row_.column_name || ' := :old.' || row_.column_name || ';' || nl;
    end loop;

    block := block || 
'  end if;' || nl || nl ||
'  insert into h_' || table_name_ || ' values v_audit;';

    return block;
  end;

  function tail
  return varchar2 as
  begin
    return
'end;' || nl ||
'/'
    ;
  end;

  function table_exists(
    table_name in varchar2
  )
  return boolean as
    is_table number := 0;
  begin
    select count(1) into is_table from tab where tname = upper(table_name);
    case
      when is_table = 1 then return true;
      else return false;
    end case;
  end;

end;
/
