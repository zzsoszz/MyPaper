/* How to generate XML from relational table with DBMS_XMLGEN. */

set long 500

select banner as "Oracle version" from v$version where banner like 'Oracle%';

create table description (
  desc_id number,
  sk varchar2(500 byte),
  de varchar2(500 byte),
  en varchar2(500 byte)
);

insert into description values(100, 'sk-100', 'de-100', 'en-100');
insert into description values(101, 'sk-101', 'de-101', 'en-101');
insert into description values(102, 'sk-102', 'de-102', 'en-102');

create table otn3res(r1 clob, r2 xmltype);

declare
  qryCtx DBMS_XMLGEN.ctxHandle;
  r1 CLOB;
  r2 xmltype;
begin
  qryCtx := DBMS_XMLGEN.newContext(
              'SELECT sk, de, en FROM description WHERE desc_id = 101');
  -- Set the row header to be EMPLOYEE
  DBMS_XMLGEN.setRowTag(qryCtx, 'MyRowTag');
  DBMS_XMLGEN.setRowSetTag(qryCtx, null);
  -- Get the result
  r1 := DBMS_XMLGEN.getXML(qryCtx);
  dbms_xmlgen.restartquery(qryCtx);
  r2 := dbms_xmlgen.getxmltype(qryCtx);
  INSERT INTO otn3res VALUES(r1, r2);
  --Close context
  DBMS_XMLGEN.closeContext(qryCtx);
end;
/

select r1 from otn3res;
select r2 from otn3res;

drop table description;
drop table otn3res;

quit
