/* Fast but inaccurate count of rows. Gives you and idea of a scale of
data amount and makes it fast. */

set linesize 80

col table_name for a40

select owner || '.' || table_name as table_name, 
       num_rows,
       last_analyzed
  from all_tables 
 where table_name like '&1' escape '\'
 order by table_name
;
