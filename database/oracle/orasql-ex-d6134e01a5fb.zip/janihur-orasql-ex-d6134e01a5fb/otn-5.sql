-- Posted to OTN:
-- http://forums.oracle.com/forums/thread.jspa?threadID=2245926&messageID=9696633#9696633

select banner as "Oracle version" from v$version where banner like 'Oracle%';

create table otn5test(
  id number,
  data xmltype
);

insert into otn5test values (1, xmltype('<catalog>
<cd>
<title>Hide your heart</title>
<artist>Bonnie Tyler</artist>
<country>UK</country>
<company>CBS Records</company>
<price>9.90</price>
<year>1988</year>
</cd>
<cd>
<title>Empire Burlesque</title>
<artist>Bob Dylan</artist>
<country>USA</country>
<company>Columbia</company>
<price>10.90</price>
<year>1985</year>
</cd>
</catalog>
'));

select otn5test.id, x.*
from otn5test,
     xmltable('/catalog/cd[artist/text()="Bob Dylan"]' passing otn5test.data
     columns title varchar2(20) path 'title') x;

select otn5test.id,
       xmlcast(xmlquery('/catalog/cd[artist/text()="Bob Dylan"]/title' 
               passing otn5test.data returning content)
       as varchar2(20)) from otn5test;

drop table otn5test;
