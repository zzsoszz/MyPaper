--
-- Can circular mutating table avoided with after inser triggers ?
--

-- -- source
-- create table orders(
--   id number,
--   item varchar2(10),
--   amount number,
--   status number
-- );

-- -- internal order notification api
-- create table order_noti_in(
--   id number,
--   order_id number
-- );

-- -- order notification api exposed to external parties
-- create table order_noti_ex(
--   id number,
--   order_id number,
--   noti varchar2(40)
-- );

create or replace package triggers_02 is
  procedure create_noti_in(p_id in number);
  procedure create_noti_ex(p_id in number);
end;
/
show errors

create or replace package body triggers_02 is
  procedure create_noti_in(p_id in number) is
  begin
    insert into order_noti_in(order_id) values(p_id);
  end;

  procedure create_noti_ex(p_id in number) is
    v_noti varchar2(40);
  begin
    select item || amount
      into v_noti
      from orders
      where id = p_id;

    insert into order_noti_ex values(-1, p_id, v_noti);
  end;
end;
/
show errors

-- triggers
create or replace trigger orders_1
after insert or update on orders
for each row
declare
begin
  triggers_02.create_noti_in(p_id => :new.id);
end;
/
show errors

create or replace trigger order_noti_in_1
after insert or update on orders
for each row
declare
begin
  triggers_02.create_noti_ex(p_id => :new.id);
end;
/
show errors

/*
insert into orders values(1, 'foo', 5, 0);

ORA-04091: table JANI.ORDERS is mutating, trigger/function may not see it
ORA-06512: at "JANI.TRIGGERS_02", line 10
ORA-06512: at "JANI.ORDER_NOTI_IN_1", line 3
ORA-04088: error during execution of trigger 'JANI.ORDER_NOTI_IN_1'

select * from orders;
select * from order_noti_in;
*/
