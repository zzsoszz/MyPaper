declare
  -- 91 chars = 90 + lf
  v_str constant varchar2(32767) :=
    to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS') ||
    ' Dummy замещающий текст переведен Google.' ||
    ' Some special chars: Öäŋəšðŋĸæ' ||
    chr(10);
  v_text clob;
begin
  dbms_output.put_line('length(v_str) = ' || length(v_str));
  dbms_lob.createtemporary(lob_loc => v_text,
                           cache => true,
                           dur => dbms_lob.session);

  --dbms_lob.writeappend(v_text, length(v_str), v_str);

  --dbms_output.put_line('len = ' || dbms_lob.getlength(v_text));
  
  -- jh_file.save(p_lob_loc => v_text,
  --              p_path => 'JTEST',
  --              p_filename => 'test-01.txt');

  -- jh_file.save(p_lob_loc => v_text,
  --              p_path => 'JTEST',
  --              p_filename => '');

  --for i in 1 .. 65536 loop --  84 * 65536 = 5505024
  for i in 1 .. 1024 loop -- 84 * 1024 = 86016
    dbms_lob.writeappend(v_text, length(v_str), v_str);
  end loop;
  
  jh_file.save(p_text => v_text,
               p_path => 'JTEST',
               p_filename => 'test-01.txt');
  
  dbms_lob.freetemporary(v_text);
end;
/
