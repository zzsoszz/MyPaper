/* An example how to calculate a date of

   1) a next weekday
   2) a next monthly calendar date

   based on an arbitrary date.
*/

create or replace package NEXTDATE as
  MONDAY constant pls_integer := 1;
  TUESDAY constant pls_integer := 2;
  WEDNESDAY constant pls_integer := 3;
  THURSDAY constant pls_integer := 4;
  FRIDAY constant pls_integer := 5;
  SATURDAY constant pls_integer := 6;
  SUNDAY constant pls_integer := 7;

  subtype weekday_t is pls_integer range 1..7;
  subtype monthdays_t is pls_integer range 1..31;

  function next_weekday(
    weekday in weekday_t,
    today in date default trunc(current_date)
  ) return date;

  function next_monthly_day(
    target_day in monthdays_t,
    base_date in date default trunc(current_date)
  ) return date;

  -- helpers

  -- Returns the next month that is having day_ days after month of
  -- base_date. E.g. next_month_with_days(to_date('2011-05-04',
  -- 'YYYY-MM-DD'), 31) returns a date of '2011-07-01' as July is the next
  -- month after May having 31 days.
  function next_month_with_days(
    base_date in date,
    day_ in monthdays_t
  ) return date;

  --- to_date wrapper
  function make_date(
    year in pls_integer,
    month in pls_integer,
    day in pls_integer
  ) return date;

  -- data type conversions

  function weekday2string(
    weekday in weekday_t
  ) return varchar2;

  function date2string(
    date_ in date,
    fmt in varchar2 default 'YYYY-MM-DD HH24:MI:SS'
  ) return varchar2;
end;
/

create or replace package body NEXTDATE as
  type weekday_strings_t is varray(7) of varchar(3);
  weekday_strings weekday_strings_t :=
    weekday_strings_t('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun');

  function next_weekday(
    weekday in weekday_t,
    today in date default trunc(current_date)
  ) return date as
  begin
    return trunc(next_day(today, weekday2string(weekday)));
  end;

  function next_monthly_day(
    target_day in monthdays_t,
    base_date in date default trunc(current_date)
  ) return date as
    base_date_day constant monthdays_t := to_number(to_char(base_date, 'DD'));
    base_date_month constant pls_integer := to_number(to_char(base_date, 'MM'));
    base_date_year constant pls_integer := to_number(to_char(base_date, 'YYYY'));

    last_day_of_month monthdays_t;
    next_month date;
  begin
    -- an event occurs potentially in base_date_month
    if base_date_day < target_day then
      -- if base_date_month has target_day days then the event can occur in
      -- base_date_month
      last_day_of_month := to_number(to_char(last_day(base_date), 'DD'));
      if target_day <= last_day_of_month then
        return make_date(base_date_year, base_date_month, target_day);
      end if;
    end if;

    -- an event occurs in next month
    next_month := next_month_with_days(base_date, target_day);
    return next_month + target_day - 1;
  end;

  function next_month_with_days(
    base_date in date,
    day_ in monthdays_t
  ) return date as
    month_ date;
    lday monthdays_t;
  begin
    month_ := add_months(base_date, 1);
    lday := to_char(last_day(month_), 'DD');
    if day_ <= lday then
      return trunc(month_, 'MM');
    else
      return next_month_with_days(month_, day_);
    end if;
  end;

  function make_date(
    year in pls_integer,
    month in pls_integer,
    day in pls_integer
  ) return date as
  begin
    return to_date(to_char(year) || '-' || to_char(month) || '-' || to_char(day), 'YYYY-MM-DD');
  end;

  function weekday2string(
    weekday in weekday_t
  ) return varchar2 as
  begin
    return weekday_strings(weekday);
  end;

  function date2string(
    date_ in date,
    fmt in varchar2 default 'YYYY-MM-DD HH24:MI:SS'
  ) return varchar2 as
  begin
    return to_char(date_, fmt);
  end;
end;
/
