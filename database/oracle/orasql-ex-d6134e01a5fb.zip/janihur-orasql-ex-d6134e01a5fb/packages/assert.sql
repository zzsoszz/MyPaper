/* Original idea from: http://examples.oreilly.com/9780596001216/

   TODO: add more assert procedures
   TODO: add an example how to use asserts
*/

/* Throws assert.failure when assertion fails unless raise_exception is set to
   false. */

create or replace package assert as
  failure exception;

  -- checks that condition 'cond' is true
  procedure istrue(
    cond in boolean,
    message in varchar2,
    raise_exception in boolean default true
  );

  -- checks that condition 'cond' is false
  procedure isfalse(
    cond in boolean,
    message in varchar2,
    raise_exception in boolean default true
  );

  -- always throws
  procedure fail(
    message in varchar2
  );
end;
/

create or replace package body assert as

  procedure put_line(
    message in varchar2
  ) as
  begin
    dbms_output.put_line('ASSERT: ' || message);
  end;

  procedure istrue(
    cond in boolean,
    message in varchar2,
    raise_exception in boolean default true
  ) as
  begin
    if not cond or cond is null then
      put_line(message);
      if raise_exception then
	raise failure;
      end if;
    end if;
  end;

  procedure isfalse(
    cond in boolean,
    message in varchar2,
    raise_exception in boolean default true
  ) as
  begin
    istrue(not cond, message, raise_exception);
  end;

  procedure fail(
    message in varchar2
  ) as
  begin
    put_line(message);
    raise failure;
  end;

end;
/
