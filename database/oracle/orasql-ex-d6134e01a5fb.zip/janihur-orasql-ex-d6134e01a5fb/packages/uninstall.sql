spool uninstall.log

/* Disabled on purpose
prompt Removing synonyms
prompt =================

@@remove_synonyms.sql
*/

prompt Uninstalling package JH_FILE
prompt ============================

drop package jh_file;

prompt Uninstalling package JH_UTIL
prompt ============================

drop package jh_util;

spool off

quit
