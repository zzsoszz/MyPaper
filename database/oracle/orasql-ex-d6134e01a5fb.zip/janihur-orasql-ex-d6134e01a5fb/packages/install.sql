spool install.log

prompt Installing package JH_UTIL
prompt ==========================

@@jh_util.pks
show errors
@@jh_util.pkb
show errors

alter package jh_util compile;
alter package jh_util compile body;

prompt Installing java class jh_fileutils
prompt ==================================

/* Requires privileges:

SQL> grant javauserpriv to USER;
SQL> exec dbms_java.grant_permission('USER', 'java.io.FilePermission', '<<ALL FILES>>', 'read, write, execute');
*/

@@jh_fileutils.java
show errors java source "jh_fileutils"

prompt Installing package JH_FILE
prompt ==========================

@@jh_file.pks
show errors
@@jh_file.pkb
show errors

alter package jh_file compile;
alter package jh_file compile body;

/* Disabled on purpose
prompt Creating synonyms
prompt =================

@@create_synonyms.sql
*/

spool off

quit
