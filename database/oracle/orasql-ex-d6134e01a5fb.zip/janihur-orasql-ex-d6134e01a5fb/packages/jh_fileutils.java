create or replace and compile java source named "jh_fileutils" as

import java.lang.*;
import java.util.*;
import java.io.*;

/* TODO implementation cleanup */
public class jh_fileutils {
    private static int OK = 1;
    private static int NOTOK = 0;
      
    public static String lista (String path) {
        String lista = "";
        File tiedosto = new File (path);
        String[] taulukko = tiedosto.list();
        
        Arrays.sort(taulukko, String.CASE_INSENSITIVE_ORDER);
        
        for (int i=0; i < taulukko.length; i++) {
          /* Hakemisto listaus ep<E4>onnistuu, jos ylitet<E4><E4>n VARCHAR2 kokoraja. */
          if ((lista.length() + taulukko[i].length() + 1) > 32767)
            break;
            
          if (!lista.equals(""))
            lista += "," + taulukko[i];
          else
            lista += taulukko[i];
        }
        return lista;
      }

      public static int uusiNimi (String lahtoPolku, String kohdePolku) {
        File lahtoTiedosto = new File (lahtoPolku);
        File kohdeTiedosto   = new File (kohdePolku);
        if (lahtoTiedosto.renameTo(kohdeTiedosto)) return OK; else return NOTOK;
      } 

};
/
/*show errors java source "Cl_hakemistokasittely"*/
