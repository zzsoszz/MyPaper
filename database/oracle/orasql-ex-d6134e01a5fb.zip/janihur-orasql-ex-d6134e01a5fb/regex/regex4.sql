-- find strings with non-printable characters
with strings as (
  select 'foo' as str from dual
  union all
  select 'bar' as str from dual
  union all
  select null as str from dual
  union all
  select 'перевод Google' as str from dual
  union all
  select 'Some "special" chars: qw€®þyuıo¶œəšðfŋhjĸæž×©vßñµ@£$€¥{[]}\iÑ' as str from dual
  union all
  select 'chr(10): ' || chr(10) as str from dual
  union all
  select 'chr(20): ' || chr(20) as str from dual
  union all
  select 'chr(21): ' || chr(21) as str from dual
  union all
  select 'chr(22): ' || chr(21) as str from dual
  union all
  select 'chr(30): ' || chr(30) as str from dual
)
select str from strings where regexp_like(str, '[^[:print:]]')
;
-- replace non-printable characters with Unicode #263A ☺
with strings as (
  select 'foo' as str from dual
  union all
  select 'bar' as str from dual
  union all
  select null as str from dual
  union all
  select 'перевод Google' as str from dual
  union all
  select 'Some "special" chars: qw€®þyuıo¶œəšðfŋhjĸæž×©vßñµ@£$€¥{[]}\iÑ' as str from dual
  union all
  select 'chr(10): ' || chr(10) as str from dual
  union all
  select 'chr(20): ' || chr(20) as str from dual
  union all
  select 'chr(21): ' || chr(21) as str from dual
  union all
  select 'chr(22): ' || chr(21) as str from dual
  union all
  select 'chr(30): ' || chr(30) || chr(30) || ' and again: ' || chr(30) as str from dual
)
select regexp_replace(str, '[^[:print:]]', '☺') from strings
;
