/* */

with strings as (
  select 'fred 19' as str from dual
  union all
  select '19 fred' as str from dual
  union all
  select '19' as str from dual
  union all
  select 'fr 19 ed' as str from dual
  union all
  select 'fred19' as str from dual
  union all
  select '19fred' as str from dual
  union all
  select 'fr19ed' as str from dual
)
select str from strings where regexp_like(str ,'(\A|\W)19');

with strings as (
  select 'Test 20019-2000 test' as str from dual
  union all
  select 'Test 119 test' as str from dual
  union all
  select 'Test 19-EM' as str from dual
  union all
  select 'Test EM - 19' as str from dual
)
select str from strings where regexp_like(str ,'(\A|\W)19');