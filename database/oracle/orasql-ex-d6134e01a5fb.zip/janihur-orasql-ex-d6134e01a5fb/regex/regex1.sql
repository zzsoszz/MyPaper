/* Oracle regular expression examples

   See: Using Regular Expressions in Database Applications
   http://download.oracle.com/docs/cd/E11882_01/appdev.112/e17125/adfns_regexp.htm
*/

drop table regextest;

create table regextest (
  key varchar2(15) not null primary key,
  value varchar2(30) not null
);

insert into regextest values ('event_date', 'weekly: monday friday sunday');
insert into regextest values ('cleanup_date', 'monthly: 1 15 31');
insert into regextest values ('start_date', 'monthly: 15 last');
insert into regextest values ('other_date', 'undefined');

select * from regextest where regexp_like(value, '^weekly');
/*
KEY		VALUE
--------------- ------------------------------
event_date	weekly: monday friday sunday
*/

select count(*) from regextest where regexp_count(value, '^monthly:') = 1;
/*
  COUNT(*)
----------
	 2
*/

select key, 'occurs on mondays' as when from regextest where regexp_substr(value, 'monday') = 'monday';
/*
KEY		WHEN
--------------- -----------------
event_date	occurs on mondays
*/

select key, trim(regexp_substr(value, '^WEEKLY:(.*)$', 1, 1, 'i', 1)) as days from regextest where key = 'event_date';
/*
KEY		DAYS
--------------- ------------------------------
event_date	monday friday sunday
*/

select key, trim(regexp_replace(value, 'last', '32')) as days from regextest where key = 'start_date';
/*
KEY		DAYS
--------------- ------------------------------
start_date	monthly: 15 32
*/
