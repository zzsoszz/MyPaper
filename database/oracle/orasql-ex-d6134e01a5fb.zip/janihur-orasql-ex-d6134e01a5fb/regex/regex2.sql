declare
  rule1 constant varchar2(100) := 'weekly: monday thursday';
  answer varchar2(100);
  
begin
  answer := regexp_substr(rule1, '^WEEKLY:(.*)$', 1, 1, 'i', 1);
  dbms_output.put_line('rule1: ' || answer);
end;
/
