-- create table reps (
--   type varchar2(1),
--   title varchar2(10),
--   id number
-- );

with xmldata as (select xmltype('<rep type="P" title="P List">
<as>
<a id="3">foo</a>
<a id="4">bar</a>
</as>
</rep>') object_value from dual)
select x1.*
from xmldata,
xmltable('$doc/rep' passing xmldata.object_value as "doc"
         columns
         type varchar2(1) path '@type',
         title varchar2(10) path '@title',
         a_list xmltype path 'as') x1,
xmltable('$doc/rep/as' passing xmldata.object_value as "doc"
         columns
         ax varchar2(5) path 'a') x2
;

-- ORA-00600 ?