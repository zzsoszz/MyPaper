declare
  cursor databases_c is
    select 'gvi.tyre.ad' as dbname from dual union
    select 'mad.tyre.ad' from dual;
  v_global_name varchar2(4000);
begin
  for v_dbname in databases_c loop
    execute immediate
      'select global_name from global_name@' || v_dbname.dbname
      into v_global_name;
    dbms_output.put_line(v_global_name);
  end loop;
end;
/

/*
SQL> @so27.sql
XXX
YYY

PL/SQL procedure successfully completed.

SQL>
*/