set serveroutput on
set linesize 80
set pagesize 60

column username format a10
column machine format a15
column command format 999
column program format a20

select username, command as C, machine, program from v$session;
select osuser, username, count(*) from v$session group by osuser, username order by 1, 2;

/* http://jehiah.cz/a/oracle-debugging */

column osuser format a10

SELECT se.osuser,
       se.username,
       se.status,
       se.sid "O-sid",
       se.serial#,
       p.pid "O-pid",
       se.process "user pid",
       p.spid "wkg-pid",    
       to_char(se.logon_time,'MM-DD HH24:MI') "logon",
       se.machine    
FROM v$session se, v$process p    
WHERE addr=paddr and se.osuser is NOT NULL and se.username is NOT NULL    
ORDER BY se.osuser;

/* http://www.oracle-base.com/articles/misc/KillingOracleSessions.php */

SET LINESIZE 90
SET PAGESIZE 60
COLUMN iid FORMAT 9999
COLUMN sid FORMAT 9999
COLUMN os_pid FORMAT A10
COLUMN username FORMAT A10
COLUMN program FORMAT A30

SELECT s.inst_id as iid,
       s.sid,
       s.serial#,
       p.spid as OS_PID, -- operating system pid
       s.username,
       s.program
FROM   gv$session s
JOIN   gv$process p ON p.addr = s.paddr AND p.inst_id = s.inst_id
WHERE  s.type != 'BACKGROUND'
order by s.username, s.sid;

/*
alter system kill session 'sid,serial#' immediate;

alter system disconnect session 'sid,serial#' immediate;

*/

/* Kill all sessions of a osuser

begin
  for v_rec in (select sid, serial# from v$session where osuser = 'anttipa') 
  loop
    dbms_output.put_line('killing session: ' || v_rec.sid || ',' || v_rec.serial#);
    execute immediate 'alter system disconnect session ''' || v_rec.sid || ',' || v_rec.serial# || ''' immediate';
  end loop;
end;
/

*/
