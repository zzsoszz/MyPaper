/* How to pass more information with user defined exceptions ?

If exceptions can't carry extra information, then what other alternatives exists to pass information about the exception reasons to caller ?

This question was answered already in this StackOverflow comment: http://stackoverflow.com/questions/3133901/error-handling-in-pl-sql/3139430#3139430
*/

create or replace package pfoo as
  ex exception;
end;
/

create or replace procedure foo as
begin
  dbms_output.put_line('foo: line 1/2');
  -- how do I pass more details with exception other than the exception name ?
  raise pfoo.ex;
  dbms_output.put_line('foo: line 2/2');
end;
/

declare
begin
  foo;
exception
  when pfoo.ex then
    -- here I'd like to have more details
    dbms_output.put_line('caught pfoo.ex');
  when others then
    -- with named system exceptions there is sqlcode and sqlerrm
    dbms_output.put_line('caught unspecified exception: error code = ' || sqlcode || ' error message = ' || sqlerrm);
end;
/
