select current_date + interval '1' day from dual;
select current_date + interval '1' month from dual;
select current_date + interval '1' year from dual;

select extract(year  from date '2003-08-22') from dual;
select extract(month from date '2003-08-22') from dual;
select extract(day   from date '2003-08-22') from dual;

select to_char(sysdate,'YYYY') as day from dual;
select to_char(sysdate,'MM') as day from dual;
select to_char(sysdate,'DD') as day from dual;
select to_char(sysdate,'DAY') as day from dual;
select to_char(sysdate,'DY') as day from dual;

create table datex(
  d date
);

insert into datex values(current_date);
insert into datex values(current_date + 1);
insert into datex values(current_date + 2);
insert into datex values(current_date + 3);
insert into datex values(current_date + 4);
insert into datex values(current_date + 5);
insert into datex values(current_date + 6);

select to_char(d, 'DY') as DAY, d as "DATE" from datex where to_char(d, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') in ('SAT', 'SUN');

select * from datex where mod(to_char(d, 'J'), 7) + 1 in (6, 7);

SELECT to_char(NEXT_DAY(sysdate,'thu'), 'YYYY-MM-DD HH24:MI:SS') from dual;
SELECT to_char(trunc(NEXT_DAY(sysdate,'thu')), 'YYYY-MM-DD HH24:MI:SS') from dual;

create or replace function fn_getdate(
  period in pls_integer default 0,
  period_type in char default 'D',
  date_ in date default current_date
) return date as
begin
  case period_type
    when 'D' then return date_ + period;
    when 'W' then return date_ + 7 * period;
    when 'M' then return add_months(date_, period);
    when 'Y' then return add_months(date_, 12 * period);
    else return null;
  end case;
end;
/

declare
  ret date;
begin
  ret := fn_getdate(2);
  dbms_output.put_line(to_char(ret, 'YYYY-MM-DD HH24:MI:SS'));
end;
/

select fn_getdate from dual;
select fn_getdate(1) from dual;
select fn_getdate(1, 'W') from dual;
