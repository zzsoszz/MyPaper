/* Insert select where XML message indicates what value from in_t table should
be inserted into out_t. */

create table in_t (
  id varchar2(20),
  val varchar2(20)
);

insert into in_t values (1, '1st one from in_t');
insert into in_t values (2, '2nd one from in_t');

create table out_t (
  val1 varchar2(20),
  val2 varchar2(20)
);

insert into out_t (val1, val2)
       select
	'value 1',
	(select val from in_t where id = x.id)
	from xmltable (
	     '/foo' passing xmltype('<foo><id>2</id></foo>')
	     columns
	     id varchar2(40) path 'id'
	) x;

select * from out_t;

drop table out_t;
drop table in_t;
