/* Transaction behaviour when rolling back to a savepoint for one row in the
middle of processing several rows.

Rolling back to savepoint undoes only the changes taking place between
savepoint command.

*/

drop table test_data;

@test-data-table.sql

select * from test_data where id <= 10;

begin
  for i in 1 .. 10 loop
    savepoint row_processing_starts;

    begin
      -- modify even ids
      if mod(i, 2) = 0 then
        update test_data
           set str = 'even',
               time_ = systimestamp
         where id = i;
        -- raise when id = 4 or 8 (demonstrates issue)
        if i in (4, 8) then
          raise no_data_found;
        end if;
      end if;
    exception
      when no_data_found then
        dbms_output.put_line('EXCEPTION: id = ' || i);
        rollback to row_processing_starts;
    end;
    
  end loop;
end;
/

select * from test_data where id <= 10;

quit
