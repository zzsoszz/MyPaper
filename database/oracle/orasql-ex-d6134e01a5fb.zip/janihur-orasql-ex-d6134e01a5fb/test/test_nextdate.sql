create or replace package TEST_NEXTDATE as
  procedure run;

  procedure test_make_date;
  procedure test_next_month_with_days;
  procedure test_next_weekday;
  procedure test_next_monthly_day;
end;
/

create or replace package body TEST_NEXTDATE as
  procedure run as
  begin
    test_make_date;
    test_next_month_with_days;
    test_next_weekday;
    test_next_monthly_day;
  end;

  procedure test_make_date as
    got date;
    expected date;
  begin
    got := NEXTDATE.make_date(2011, 06, 13);
    expected := to_date('2011-06-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_make_date: Expected 2011-06-13 00:00:00');

    got := NEXTDATE.make_date(2012, 2, 29);
    expected := to_date('2012-02-29 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_make_date: Expected 2012-02-29 00:00:00');
  end;

  procedure test_next_month_with_days as
    someday date;
    got date;
    expected date;
  begin
    someday := to_date('2011-05-12 16:08:45', 'YYYY-MM-DD HH24:MI:SS');

    got := NEXTDATE.next_month_with_days(someday, 30);
    expected := to_date('2011-06-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_next_month_with_days: Expected 2011-06-01 00:00:00');

    got := NEXTDATE.next_month_with_days(someday, 31);
    expected := to_date('2011-07-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_next_month_with_days: Expected 2011-07-01 00:00:00');

    someday := to_date('2012-01-12 16:08:45', 'YYYY-MM-DD HH24:MI:SS');

    got := NEXTDATE.next_month_with_days(someday, 28);
    expected := to_date('2012-02-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_next_month_with_days: Expected 2012-02-01 00:00:00');

    got := NEXTDATE.next_month_with_days(someday, 29);
    expected := to_date('2012-02-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_next_month_with_days: Expected 2012-02-01 00:00:00');

    got := NEXTDATE.next_month_with_days(someday, 30);
    expected := to_date('2012-03-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_next_month_with_days: Expected 2012-03-01 00:00:00');

    got := NEXTDATE.next_month_with_days(someday, 31);
    expected := to_date('2012-03-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(got = expected, 'test_next_month_with_days: Expected 2012-03-01 00:00:00');
  end;

  procedure test_next_weekday as
    today date;
    nextday date;
    expected date;
  begin
    -- 2011-05-12 is Thursday
    today := to_date('2011-05-12 14:36:12', 'YYYY-MM-DD HH24:MI:SS');

    nextday := NEXTDATE.next_weekday(NEXTDATE.MONDAY, today);
    expected := to_date('2011-05-16 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Monday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.TUESDAY, today);
    expected := to_date('2011-05-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Tuesday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.WEDNESDAY, today);
    expected := to_date('2011-05-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Wednesday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.THURSDAY, today);
    expected := to_date('2011-05-19 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Thursday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.FRIDAY, today);
    expected := to_date('2011-05-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Friday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.SATURDAY, today);
    expected := to_date('2011-05-14 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Saturday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.SUNDAY, today);
    expected := to_date('2011-05-15 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Sunday not in expected date');

    -- 2011-05-28 is Saturday
    today := to_date('2011-05-28 14:36:12', 'YYYY-MM-DD HH24:MI:SS');

    nextday := NEXTDATE.next_weekday(NEXTDATE.MONDAY, today);
    expected := to_date('2011-05-30 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Monday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.TUESDAY, today);
    expected := to_date('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Tuesday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.WEDNESDAY, today);
    expected := to_date('2011-06-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Wednesday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.THURSDAY, today);
    expected := to_date('2011-06-02 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Thursday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.FRIDAY, today);
    expected := to_date('2011-06-03 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Friday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.SATURDAY, today);
    expected := to_date('2011-06-04 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Saturday not in expected date');

    nextday := NEXTDATE.next_weekday(NEXTDATE.SUNDAY, today);
    expected := to_date('2011-05-29 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    assert.istrue(nextday = expected, 'test_next_weekday: Next Sunday not in expected date');

  end;

  procedure test_next_monthly_day as
    today date;
    nextday date;
    expected date;
  begin
    -- 2011-05-12
    today := to_date('2011-05-12 14:36:12', 'YYYY-MM-DD HH24:MI:SS');

    nextday := NEXTDATE.next_monthly_day(1, today);
    expected := to_date('2011-06-01', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 1. day not in expected date');

    nextday := NEXTDATE.next_monthly_day(11, today);
    expected := to_date('2011-06-11', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 11. day not in expected date');

    nextday := NEXTDATE.next_monthly_day(12, today);
    expected := to_date('2011-06-12', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 12. day not in expected date');

    nextday := NEXTDATE.next_monthly_day(13, today);
    expected := to_date('2011-05-13', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 13. day not in expected date');

    nextday := NEXTDATE.next_monthly_day(31, today);
    expected := to_date('2011-05-31', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 31. day not in expected date');

    -- 2011-06-29
    today := to_date('2011-06-29 14:36:12', 'YYYY-MM-DD HH24:MI:SS');

    nextday := NEXTDATE.next_monthly_day(28, today);
    expected := to_date('2011-07-28', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 28. day not in expected date');

    nextday := NEXTDATE.next_monthly_day(29, today);
    expected := to_date('2011-07-29', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 29. day not in expected date');

    nextday := NEXTDATE.next_monthly_day(30, today);
    expected := to_date('2011-06-30', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 30. day not in expected date');

    nextday := NEXTDATE.next_monthly_day(31, today);
    expected := to_date('2011-07-31', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Next 31. day not in expected date');

    -- 2011-12-24
    today := to_date('2011-12-24 14:36:12', 'YYYY-MM-DD HH24:MI:SS');

    nextday := NEXTDATE.next_monthly_day(6, today);
    expected := to_date('2012-01-06', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Expected 2012-01-06');

    nextday := NEXTDATE.next_monthly_day(28, today);
    expected := to_date('2011-12-28', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Expected 2011-12-28');

    -- 2012-02-15
    today := to_date('2012-02-15 14:36:12', 'YYYY-MM-DD HH24:MI:SS');

    nextday := NEXTDATE.next_monthly_day(1, today);
    expected := to_date('2012-03-01', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Expected 2012-03-01');

    nextday := NEXTDATE.next_monthly_day(28, today);
    expected := to_date('2012-02-28', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Expected 2012-02-28');

    nextday := NEXTDATE.next_monthly_day(29, today);
    expected := to_date('2012-02-29', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Expected 2012-02-29');

    nextday := NEXTDATE.next_monthly_day(30, today);
    expected := to_date('2012-03-30', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Expected 2012-03-30');

    nextday := NEXTDATE.next_monthly_day(31, today);
    expected := to_date('2012-03-31', 'YYYY-MM-DD');
    assert.istrue(nextday = expected, 'test_next_monthly_day: Expected 2012-03-31');

  end;

end;
/
