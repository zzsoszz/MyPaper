/* -*- mode: plsql; -*- */

/* from: http://stackoverflow.com/q/51470 */

create or replace procedure sequence_reset(
  p_sequence_owner in varchar2,
  p_sequence_name in varchar2,
  p_new_value in number default 0
) is
  v_sequence_owner constant dba_sequences.sequence_owner%type :=
    upper(p_sequence_owner);
  v_sequence_name constant dba_sequences.sequence_name%type :=
    upper(p_sequence_name);

  v_min_value dba_sequences.min_value%type;
  v_increment_by dba_sequences.increment_by%type;

  v_current number := 0;
  v_difference number := 0;
begin
  select min_value, increment_by
    into v_min_value, v_increment_by
    from dba_sequences
   where sequence_owner = v_sequence_owner
     and sequence_name = v_sequence_name;

  execute immediate
    'select ' || v_sequence_owner || '.' || v_sequence_name || '.nextval from dual' INTO v_current;

  if p_new_value < v_min_value then
    v_difference := v_min_value - v_current;
  else
    v_difference := p_new_value - v_current;
  end if;

  dbms_output.put_line('v_min_value = ' || v_min_value);
  dbms_output.put_line('v_increment_by = ' || v_increment_by);
  dbms_output.put_line('v_current = ' || v_current);
  dbms_output.put_line('v_difference = ' || v_difference);
  
  if v_difference = 0 then
    return;
  end if;

  execute immediate
    'alter sequence ' || v_sequence_owner || '.' || v_sequence_name || ' increment by ' || v_difference || 
       ' minvalue ' || v_min_value;

  execute immediate
    'select ' || v_sequence_owner || '.' || v_sequence_name || '.nextval from dual' INTO v_difference;

  execute immediate
    'alter sequence ' || v_sequence_owner || '.' || v_sequence_name || ' increment by ' || v_increment_by || ' minvalue ' || v_min_value;
end;
/
show errors
