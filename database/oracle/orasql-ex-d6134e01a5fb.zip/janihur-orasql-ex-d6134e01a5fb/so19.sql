/* How to return an array from Java to PL/SQL ?

A SO question: http://stackoverflow.com/q/7872688

I have no problems to pass numbers and strings back and forth from PL/SQL to Java, but how do I pass _arrays_ ? I'm calling Java from PL/SQL - not other way round.

Below is an example where `get_widgets_as_string` works as expected. How do I write PL/SQL _call specification_ for `so19j.get_widgets_as_array()` so that I can call it from PL/SQL ?

I have read [Publishing Java Classes With Call Specifications](http://download.oracle.com/docs/cd/E11882_01/java.112/e10588/chsix.htm) where I can see that nested table corresponds to `oracle.sql.ARRAY`, but I can't get it working. I'm probably missing some trivial details because I'm not a Java programmer.
*/

    create or replace and compile java source named "so19j" as

    import java.lang.*;

    public class so19j {
        public static String get_widgets_as_string() {
            String widgets = "foo;bar;zoo";
            return widgets;
        }

        public static String[] get_widgets_as_array() {
            String[] widgets = new String[]{"foo", "bar", "zoo"};
            return widgets;
        }
    };
    /
    show errors java source "so19j"

    create or replace function get_widgets_as_string return varchar2 as
    language java name 'so19j.get_widgets_as_string() return java.lang.String';
    /
    show errors

    declare
      widgets constant varchar2(32767) := get_widgets_as_string;
    begin
      dbms_output.put_line('widgets = ' || widgets);
    end;
    /

    /* How to write a call specification for so19j.get_widgets_as_array so
    that it can be excercised by the PL/SQL block below ? */

    declare
      type widgets_t is table of varchar2(32767);
      widgets constant widgets_t := get_widgets_as_array;
    begin
      for i in widgets.first .. widgets.last loop
        dbms_output.put_line('widgets(' || i || ') = ' || widgets(i));
      end loop;
    end;
    /

/* ANSWER */

    /* The type has to be SQL type so that it is also visible fro Java. */
    create or replace type widgets_t is table of varchar2(32767);
    /
    
    create or replace and compile java source named "so19ja" as
    import java.lang.*;
    public class so19ja {
        public static String[] get_widgets_as_array() {
            String[] widgets = new String[]{"foo", "bar", "zoo"};
            return widgets;
        }
    
        public static java.sql.Array array_wrapper(
            String typeName,
            Object elements
        ) throws java.sql.SQLException {
            oracle.jdbc.OracleDriver ora = new oracle.jdbc.OracleDriver();
            java.sql.Connection conn = ora.defaultConnection();
            oracle.jdbc.OracleConnection oraConn =
                (oracle.jdbc.OracleConnection)conn;
            /* Yeah - typeName have to be UPPERCASE, really. */
            java.sql.Array arr = 
                oraConn.createARRAY(typeName.toUpperCase(), elements);
            return arr;
        }
    
        public static java.sql.Array get_widgets_as_array_wrapped()
        throws java.sql.SQLException {
            return array_wrapper("widgets_t", get_widgets_as_array());
        }
    };
    /
    show errors java source "so19ja"
    
    create or replace function get_widgets_as_array return widgets_t as
    language java name 'so19ja.get_widgets_as_array_wrapped() return java.sql.Array';
    /
    show errors
    
    declare
      widgets constant widgets_t := get_widgets_as_array;
    begin
      for i in widgets.first .. widgets.last loop
        dbms_output.put_line('widgets(' || i || ') = ' || widgets(i));
      end loop;
    end;
    /

drop function get_widgets_as_string;
drop function get_widgets_as_array;
drop java source "so19j";
drop java source "so19ja";
drop type widgets_t;
