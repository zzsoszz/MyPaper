create table merge01 (
  context varchar2(10),
  code varchar2(10),
  last_date date,
  prev_date date
);

create procedure insert_merge(
  p_context in varchar2,
  p_code in varchar2,
  p_date in date default sysdate)
as
  v_context constant merge01.context%type := upper(p_context);
  v_code constant merge01.code%type := upper(p_code);
begin
  merge into merge01 m
    using (select v_context as context, v_code as code from dual) n
    on (m.context = n.context and m.code = n.code)
  when matched then
    update set last_date = p_date,
               prev_date = last_date
  when not matched then
    insert (context, code, last_date, prev_date)
    values (v_context, v_code, p_date, null)
  ;
end;
/
show errors

exec insert_merge('foo', 'Abc')
exec insert_merge('foo', '123')
exec insert_merge('foo', '123')

exec insert_merge('bar', '123')

set autotrace on
     
select * from merge01 order by context, code;

set autotrace off

drop procedure insert_merge;
drop table merge01;
