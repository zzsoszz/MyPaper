@@packages/assert.sql
show errors

/* http://download.oracle.com/docs/cd/E11882_01/appdev.112/e17126/datatypes.htm#CHDHDHHA

CREATE OR REPLACE PROCEDURE print_boolean (b BOOLEAN)
AS
BEGIN
  CASE
    WHEN b IS NULL THEN DBMS_OUTPUT.PUT_LINE('Unknown');
    WHEN b THEN DBMS_OUTPUT.PUT_LINE('Yes');
    WHEN NOT b THEN DBMS_OUTPUT.PUT_LINE('No');
  END CASE;
END;
/
BEGIN
  print_boolean(TRUE);
  print_boolean(FALSE);
  print_boolean(NULL);
END;
/
*/

create or replace function boolean2string(b boolean) return varchar2
as
begin
  case
    when b is null then return 'NULL';
    when b then return 'TRUE';
    when not b then return 'FALSE';
  end case;
end;
/

create or replace function string2boolean(str in varchar2) return boolean
as
begin
  case upper(str)
    when 'NULL' then return null;
    when 'TRUE' then return true;
    when 'FALSE' then return false;
  end case;
end;
/

declare
  b boolean;
begin
  dbms_output.put_line('boolean type default value is ' || boolean2string(b));
  dbms_output.put_line('true is ' || boolean2string(true));
  dbms_output.put_line('false is ' || boolean2string(false));

  assert.istrue(boolean2string(true) = 'TRUE', 'boolean2string(true)');
  assert.istrue(boolean2string(false) = 'FALSE', 'boolean2string(false)');
  assert.istrue(boolean2string(null) = 'NULL', 'boolean2string(null)');

  assert.istrue(string2boolean('TrUe'), 'string2boolean(''TrUe'')');
  assert.isfalse(string2boolean('FALSE'), 'string2boolean(''FALSE'')');
  assert.istrue(string2boolean('null') is null, 'string2boolean(''null'')');
end;
/

declare
  b boolean;
  case_not_found exception;
  pragma exception_init(case_not_found, -6592);
begin
  b := string2boolean('whatever');
  assert.fail('This line shoud have not been executed !');
exception
  when case_not_found then null;
end;
/
