/* How to create an oracle.sql.ARRAY object ?

A SO question: http://stackoverflow.com/q/7878735

This question is related to my original issue [How to return an array from Java to PL/SQL ?](http://stackoverflow.com/q/7872688), but is a more specific.

I have been reading [Oracle Database JDBC Developer's Guide](http://download.oracle.com/docs/cd/E11882_01/java.112/e16548/toc.htm) and

  * [Creating ARRAY objects](http://download.oracle.com/docs/cd/E11882_01/java.112/e16548/oraarr.htm#i1056647)
  * [Server-Side Internal Driver](http://download.oracle.com/docs/cd/E11882_01/java.112/e16548/ssid.htm)
  * [oracle.jdbc.OracleConnection](http://download.oracle.com/docs/cd/E11882_01/appdev.112/e13995/oracle/jdbc/OracleConnection.html)
  * [oracle.jdbc.OracleDriver](http://download.oracle.com/docs/cd/E11882_01/appdev.112/e13995/oracle/jdbc/OracleDriver.html)

but I still fail to write a minimum code where I can create ARRAY using 

    ARRAY array = oracle.jdbc.OracleConnection.createARRAY(sql_type_name, elements);

as instructed in [Creating ARRAY objects](http://download.oracle.com/docs/cd/E11882_01/java.112/e16548/oraarr.htm#i1056647).

I'm using Oracle Database JVM.

I have tried following:

*/

    create or replace type widgets_t is table of varchar2(32767);
    /
    
    create or replace and compile java source named "so20j1" as
    
    public class so20j1 {
        public void f1() {
            String[] elements = new String[]{"foo", "bar", "zoo"};
            oracle.sql.ARRAY widgets = oracle.jdbc.OracleConnection.createARRAY("widgets_t", elements);
        }
    };
    /
    show errors java source "so20j1"

/*
    Errors for JAVA SOURCE "so20j1":
    
    LINE/COL ERROR
    -------- -----------------------------------------------------------------
    0/0	 so20j1:4: non-static method
    	 createARRAY(java.lang.String,java.lang.Object) cannot be
    	 referenced from a static context
    
    0/0	 1 error
    0/0	 ^
    0/0	 oracle.sql.ARRAY widgets =
    	 oracle.jdbc.OracleConnection.createARRAY("widgets_t", elements);
*/

    create or replace and compile java source named "so20j2" as
    
    public class so20j2 {
        public void f1() {
            String[] elements = new String[]{"foo", "bar", "zoo"};
            oracle.jdbc.OracleDriver ora = new oracle.jdbc.OracleDriver();
            java.sql.Connection conn = ora.defaultConnection();
            oracle.sql.ARRAY widgets = conn.createARRAY("widgets_t", elements);
        }
    };
    /
    show errors java source "so20j2"

/*
    Errors for JAVA SOURCE "so20j2":
    
    LINE/COL ERROR
    -------- -----------------------------------------------------------------
    0/0	 so20j2:6: cannot find symbol
    0/0	 symbol  : method createARRAY(java.lang.String,java.lang.String[])
    0/0	 1 error
    0/0	 oracle.sql.ARRAY widgets = conn.createARRAY("widgets_t",
    	 elements);
    
    0/0	 ^
    0/0	 location: interface java.sql.Connection
*/

/*
Disclaimer: I'm not a Java programmer (yet).
*/

/* ANSWERS */

    create or replace and compile java source named "so20ja1" as
    public class so20ja1 {
        public void f1() throws java.sql.SQLException {
            String[] elements = new String[]{"foo", "bar", "zoo"};
            oracle.jdbc.OracleDriver ora = new oracle.jdbc.OracleDriver();
            java.sql.Connection conn = ora.defaultConnection();
            oracle.jdbc.OracleConnection oraConn = (oracle.jdbc.OracleConnection)conn;
            java.sql.Array widgets = oraConn.createARRAY("widgets_t", elements);
        }
    };
    /
    show errors java source "so20ja1"
    
    create or replace and compile java source named "so20ja2" as
    public class so20ja2 {
        public void f1() throws java.sql.SQLException {
            String[] elements = new String[]{"foo", "bar", "zoo"};
            oracle.jdbc.OracleDriver ora = new oracle.jdbc.OracleDriver();
            java.sql.Connection conn = ora.defaultConnection();
            oracle.sql.ArrayDescriptor desc = 
                oracle.sql.ArrayDescriptor.createDescriptor("widgets_t", conn);
            java.sql.Array widgets = new oracle.sql.ARRAY(desc, conn, elements);
        }
    };
    /
    show errors java source "so20ja2"

drop java source "so20j1";
drop java source "so20j2";
drop java source "so20ja1";
drop java source "so20ja2";
drop type widgets_t;

quit
