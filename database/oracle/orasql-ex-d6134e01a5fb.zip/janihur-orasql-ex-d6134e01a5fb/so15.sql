/* Reinitializing a variable/record in PL/SQL during a loop

An answer to SO question: http://stackoverflow.com/q/7792798

*/

  declare
      type message_t is table of char(120);
      v_message message_t := message_t('12 record', /* start */
                                       '40 record',
                                       '70 record', /* end */
                                       '12 record', /* start */
                                       '50 record',
                                       '51 record',
                                       '70 record'  /* end */
                                       );
    
      v_almessage message_t := message_t();
      v_i number := v_message.first;
    begin
      while v_i <= v_message.last loop
        if v_message(v_i) = '12 record' then /* start of a block */
          dbms_output.put_line('start of a block');
    
          loop
            v_i := v_i + 1;
    
            if v_message(v_i) = '70 record' then /* end of a block */
              dbms_output.put_line('end of a block');
    
              /* Do whatever processing you need to do. I just print collected
              messages. */
              for j in v_almessage.first .. v_almessage.last loop
              dbms_output.put_line('aligment message: ' || v_almessage(j)); end
              loop;
    
              /* Reset collected messages. */
              v_almessage := message_t();
    
              exit;
            end if;
    
            /* Collect block's aligment messages. */
            v_almessage.extend(1);
            v_almessage(v_almessage.last) := v_message(v_i);
          end loop;
    
        end if;
    
        v_i := v_i + 1;
      end loop;
    
    end;
    /
