declare
  v_rowid rowid;
begin
  select rowid 
    into v_rowid
    from dual
  ;
  dbms_output.put_line(v_rowid);
end;
/
show errors
