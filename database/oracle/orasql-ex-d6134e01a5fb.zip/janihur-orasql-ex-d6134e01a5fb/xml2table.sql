/* How to load data from XML to database table. */

select banner as "Oracle version" from v$version where banner like 'Oracle%';

create table otn5test(
  id number,
  data xmltype
);

insert into otn5test values (1, xmltype('<catalog>
<cd>
<title>Highway 61 Revisited</title>
<artist>Bob Dylan</artist>
<country>USA</country>
<company>Columbia</company>
<price>8.90</price>
<year>1965</year>
</cd>
<cd>
<title>Hide your heart</title>
<artist>Bonnie Tyler</artist>
<country>UK</country>
<company>CBS Records</company>
<price>9.90</price>
<year>1988</year>
</cd>
<cd>
<title>Empire Burlesque</title>
<artist>Bob Dylan</artist>
<country>USA</country>
<company>Columbia</company>
<price>10.90</price>
<year>1985</year>
</cd>
</catalog>
'));

select otn5test.id, x.*
from otn5test,
     xmltable('/catalog/cd[artist/text()="Bob Dylan"]' passing otn5test.data
     columns title varchar2(20) path 'title') x;

select otn5test.id,
       xmlcast(xmlquery('/catalog/cd[artist/text()="Bob Dylan"]/title' 
               passing otn5test.data returning content)
       as varchar2(40)) from otn5test;

create table cd(
  artist varchar2(20),
  title varchar2(20),
  company varchar2(20)
);

insert into cd (artist, title, company)
select x.*
from otn5test,
     xmltable('/catalog/cd' passing otn5test.data
     columns 
     artist varchar2(20) path 'artist',
     title varchar2(20) path 'title',
     company varchar2(20) path 'company') x;

create or replace procedure load_cds_of(
  artist_ in varchar2
) as
begin
insert into cd (artist, title, company)
select x.*
from otn5test,
     xmltable('/catalog/cd[artist/text()=$artist]'
     passing otn5test.data, artist_ as "artist"
     columns 
     artist varchar2(20) path 'fn:concat(fn:substring-after(artist, " "), " ", fn:substring-before(artist, " "))',
     title varchar2(20) path 'fn:upper-case(title)',
     company varchar2(20) path 'company') x;
end;
/
show errors

declare
begin
  load_cds_of('Bob Dylan');
end;
/

select * from cd;

drop procedure load_cds_of;

drop table cd;
drop table otn5test;
