create table data_table (
  id number not null,
  d1 varchar2(15) not null,
  d2 varchar2(15) not null
);

insert all
into data_table values (1, 'one', 'yksi')
into data_table values (2, 'two', 'kaksi')
select 1 from dual;

select * from data_table;

create table conv_table (
  from_val varchar2(15),
  to_val varchar2(15)
);

insert all
into conv_table values ('yksi', 'ett')
into conv_table values ('kaksi', 'två')
select 1 from dual;

/* d2 is not null, so the whole update will fail if any single data_table row
is missing conversion value */

update data_table dt
set d2 = (select to_val
            from conv_table
           where from_val = dt.d2);

select * from data_table;

drop table conv_table;
drop table data_table;
