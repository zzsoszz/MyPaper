select 'Given value: &1' from dual;

select 100 + &1 from dual;
