/* DESC: How to put user definable variables into a single location and re-use them later. */

@@config-1.sql

--select '&p_tablespace_path' as "TSPATH" from dual;
define p_tablespace_path

column p_tmp new_val p_tablespace_file

select '&p_tablespace_path' || 'file-1.ora' p_tmp from dual;

select '&p_tablespace_file' as "TSFILE 1" from dual;

select '&p_tablespace_path' || 'file-2.ora' p_tmp from dual;

select '&p_tablespace_file' as "TSFILE 2" from dual;
