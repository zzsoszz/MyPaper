/* Creates tables into user defined schema (and tablespace).

   usage: sqlplus <schema>/<passwd>@<db> <SCHEMA> <TABLESPACE>

*/

/* These are only */
define p_schema=&&1
define p_tablespace=&&2

set verify off

prompt Creating tables to
prompt schema: &&p_schema
prompt tablespace: &&p_tablespace

create table &&p_schema..foo1_t (
  id number,
  data varchar2(10)
)
tablespace &&p_tablespace
;

create table &&p_schema..foo2_t (
  id number,
  data varchar2(10)
)
tablespace &&p_tablespace
;

quit
