create or replace procedure compile_function (f in varchar2) as
begin
  execute immediate 'alter function :f compile' using f;
exception
  when others then
    raise_application_error(-20000, 'Failed to compile function ' || f);
end;
/
show errors

prompt continues after error
prompt =====================
prompt

create or replace function foo return number as
begin
  compilation will fail
end;
/
show errors

exec compile_function('foo')

prompt quits after error with error code 
prompt =================================
prompt

whenever sqlerror exit sql.sqlcode

create or replace function foo return number as
begin
  compilation will fail
end;
/
show errors

exec compile_function('foo')

prompt never gets here
prompt ===============
prompt

quit
