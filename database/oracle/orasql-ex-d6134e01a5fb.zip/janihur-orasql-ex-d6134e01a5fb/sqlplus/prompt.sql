/* DESC: SQLPLUS prompt doesn't like dashes '-' */

rem prompt is confused if the last character is a dash '-'

rem empty line is required
rem note also one extra dash
prompt executing file prompt-2.sql 1st time
prompt -------------------------------------

@prompt-2.sql
show errors

drop table foo;

rem no problems here

prompt executing file prompt-2.sql 2nd time
prompt ====================================
@prompt-2.sql
show errors

drop table foo;

rem extra character required after dash and everything is again ok

prompt executing file prompt-2.sql 3rd time
prompt x -------------------------------- x
@prompt-2.sql
show errors

drop table foo;
