prompt &_O_VERSION

define

/* SQL*PLUS bind variables */

/* http://www.adp-gmbh.ch/ora/sqlplus/use_vars.html */

variable in_data varchar2(20)
exec :in_data := 'foobar';

column "BIND VARIABLE" format a30
select :in_data as "BIND VARIABLE" from dual;

/* SQL*PLUS user variables */

/* http://www.adp-gmbh.ch/ora/sqlplus/define.html */

define my_var='C:\data'

set verify off

column "SUBSTITUTION VARIABLE" format a30
select '&my_var' as "SUBSTITUTION VARIABLE" from dual;
