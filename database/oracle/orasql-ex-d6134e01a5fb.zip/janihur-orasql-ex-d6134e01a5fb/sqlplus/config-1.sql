-- this file contains some "global" variables

-- suppress the listing when substituting replacement variables with values
set verify off

define p_tablespace_path='C:\Oracle\Administrator\oradata\TEST\'
