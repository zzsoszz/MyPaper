prompt continues after error
prompt =====================
prompt

create table foo;

prompt quits after error with error code 
prompt =================================
prompt

whenever sqlerror exit sql.sqlcode

create table foo;

prompt never gets here
prompt ===============
prompt

quit
