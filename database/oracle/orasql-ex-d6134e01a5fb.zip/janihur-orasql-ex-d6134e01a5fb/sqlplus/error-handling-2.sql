create or replace function foo return number as
  foo_error exception;
begin
  raise foo_error;
end;
/
show errors

prompt continues after error
prompt =====================
prompt

select foo from dual;

prompt quits after error with error code 
prompt =================================
prompt

whenever sqlerror exit sql.sqlcode

select foo from dual;

prompt never gets here
prompt ===============
prompt

quit
