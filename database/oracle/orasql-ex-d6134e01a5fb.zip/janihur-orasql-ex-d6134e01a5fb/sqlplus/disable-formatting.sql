/* How to disable SQL*Plus formatting when spooling
   From:

   http://www.orafaq.com/wiki/SQL*Plus_FAQ#How_does_one_disable_SQL.2APlus_formatting.3F
*/

set termout off
set linesize 32676
SET ECHO OFF
SET NEWPAGE 0
/* SET SPACE 0 */
SET PAGESIZE 0
SET FEEDBACK OFF
/* SET HEADING OFF */
SET TRIMSPOOL ON
SET TAB OFF

spool /tmp/tmp.sql
select * from all_tables order by owner;
spool off

quit
