create table foo (
  id number,
  data varchar2(20)
);
