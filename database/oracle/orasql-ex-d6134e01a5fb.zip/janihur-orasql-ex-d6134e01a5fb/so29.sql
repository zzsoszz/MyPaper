-- I'm lazy and provide only a few intervals

create table intervals as
select 1 as id, 8 + 0/60 as start_, 8 + 19/60 as end_, '8:00 - 8:19' as desc_ from dual union all
select 2 as id, 8 + 20/60 as start_, 8 + 39/60 as end_, '8:20 - 8:39' as desc_ from dual union all
select 3 as id, 8 + 40/60 as start_, 8 + 59/60 as end_, '8:40 - 8:59' as desc_ from dual union all
select 4 as id, 9 + 0/60 as start_, 9 + 19/60 as end_, '9:00 - 9:19' as desc_ from dual union all
select 5 as id, 9 + 20/60 as start_, 9 + 39/60 as end_, '9:20 - 9:39' as desc_ from dual union all
select 6 as id, 9 + 40/60 as start_, 9 + 59/60 as end_, '9:40 - 9:59' as desc_ from dual
;

select localtimestamp from dual;

-- example queries

select * from intervals 
where extract(hour from localtimestamp) + 
      (extract(minute from localtimestamp) / 60)
between start_ and end_;

select * from intervals
where extract(hour from to_timestamp('2013-08-29 08:39:59', 'YYYY-MM-DD HH24:MI:SS')) + 
      (extract(minute from to_timestamp('2013-08-29 08:39:59', 'YYYY-MM-DD HH24:MI:SS')) / 60)
between start_ and end_;

select * from intervals
where extract(hour from to_timestamp('2013-08-29 08:40:00', 'YYYY-MM-DD HH24:MI:SS')) + 
      (extract(minute from to_timestamp('2013-08-29 08:40:00', 'YYYY-MM-DD HH24:MI:SS')) / 60)
between start_ and end_;

-- a convenience function

create or replace function get_interval_id(
  p_time in timestamp default localtimestamp
) return number as
  v_id number;
begin
  select id into v_id
    from intervals
   where extract(hour from p_time) + 
         (extract(minute from p_time) / 60)
  between start_ and end_;

  return v_id;
exception
  when others then
    return null;
end;
/
show errors

-- how to use the function

select * from intervals where id = get_interval_id;
select * from intervals where id = get_interval_id(to_timestamp('2013-08-29 08:59:00', 'YYYY-MM-DD HH24:MI:SS'));
