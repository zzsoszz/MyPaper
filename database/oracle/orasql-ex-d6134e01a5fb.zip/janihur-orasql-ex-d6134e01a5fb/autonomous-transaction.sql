/* See: http://www.oracle-base.com/articles/misc/AutonomousTransactions.php */

CREATE TABLE at_test (
  id           NUMBER       NOT NULL,
  description  VARCHAR2(20) NOT NULL
);

create or replace procedure at_test_proc as
  PRAGMA AUTONOMOUS_TRANSACTION; -- new transaction starts
BEGIN
  rollback;
  /* no data found as autonomous_transaction shares nothing with the main
     transaction */

  declare
    desc_ varchar2(20);
  begin
    select description into desc_ from at_test where id = 2;
    dbms_output.put_line('desc for item 2: ' || desc_);
  exception
    when no_data_found then
      dbms_output.put_line('no data found as autonomous_transaction shares nothing with the main transaction');
  end;

  FOR i IN 3 .. 4 LOOP
    INSERT INTO at_test (id, description)
    VALUES (i, 'Description for ' || i);
  END LOOP;
  COMMIT; -- committed ids 3-4
END;
/

-- autocommit point

rollback;

INSERT INTO at_test (id, description) VALUES (1, 'Description for 1');
INSERT INTO at_test (id, description) VALUES (2, 'Description for 2');

-- ids 1-2 are not yet commited

SELECT * FROM at_test;
 -- 2 rows

exec at_test_proc

SELECT * FROM at_test;
 -- 4 rows

rollback; -- rollbacks ids 1-2

SELECT * FROM at_test;
 -- 2 rows expected but still sees 4, why ?

drop table at_test;
drop procedure at_test_proc;
