/* PL/SQL:, How to pass variable into SELECT statent and return all rows of results

An answer to SO question: http://stackoverflow.com/q/18004723

Code part only.
*/

create table so26 (
  day date,
  event varchar(10)
);

insert all
into so26 values(trunc(sysdate - 1), 'foo1')
into so26 values(trunc(sysdate - 1), 'foo2')
into so26 values(trunc(sysdate - 1), 'foo3')
into so26 values(trunc(sysdate    ), 'bar')
into so26 values(trunc(sysdate + 1), 'zoo')
select 1 from dual;

select * from so26;

declare
  type event_list_t is table of so26%rowtype;
  v_events event_list_t := event_list_t();

  function get_events(p_day in date default sysdate) return event_list_t as
    v_events event_list_t := event_list_t();
  begin
    select *
      bulk collect into v_events
      from so26
     where day = trunc(p_day);
 
    return v_events;  
  end;
begin
  v_events := get_events(sysdate + 1);

  if v_events.first is null then
    dbms_output.put_line('no events on that day');
    return;
  end if;

  for i in v_events.first .. v_events.last loop
    dbms_output.put_line(i || ': event = ' || v_events(i).event);
  end loop;
end;
/

drop table so26;
