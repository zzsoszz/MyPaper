create table lob_table(
  b blob,
  c clob,
  n nclob
);

-- http://stackoverflow.com/questions/122909/using-pl-sql-how-do-you-i-get-a-files-contents-in-to-a-blob/123051#123051
create or replace procedure blob_load_1
as
  blob_ blob;
  fh bfile := bfilename('DATA_TALOUS', 'camt.053.001.02.xml');
begin
  insert into lob_table (b) values (empty_blob()) returning b into blob_;
  
  dbms_lob.open(blob_, dbms_lob.lob_readwrite);
  dbms_lob.open(fh, dbms_lob.lob_readonly);

  dbms_lob.loadfromfile(dest_lob => blob_,
			src_lob  => fh,
			amount   => dbms_lob.getlength(fh));

  dbms_lob.close(fh);
  dbms_lob.close(blob_);

  commit;
end;
/
show errors

create or replace procedure blob_load_2
as
  blob_ blob;
  fh bfile := bfilename('DATA_TALOUS', 'camt.053.001.02.xml');
begin
  dbms_lob.createtemporary(blob_, true);

  dbms_lob.open(blob_, dbms_lob.lob_readwrite);

  dbms_lob.open(fh, dbms_lob.lob_readonly);

  dbms_lob.loadfromfile(dest_lob => blob_,
			src_lob  => fh,
			amount   => dbms_lob.getlength(fh));

  dbms_lob.close(fh);
  dbms_lob.close(blob_);

  insert into lob_table (b) values (blob_);
  commit;
  
  --dbms_output.put_line(utl_raw.cast_to_varchar2(blob_));
end;
/
show errors

create or replace procedure nclob_load
as
  lob_ nclob;
  fh bfile := bfilename('DATA_TALOUS', 'camt.053.001.02.xml');

  -- loadclobfromfile parameters
  amount constant integer := dbms_lob.lobmaxsize;
  dest_offset integer := 1;
  src_offset integer := 1;
  bfile_csid constant number := nls_charset_id('AL32UTF8');
  lang_context integer := 0;
  warning integer := 0;
begin
  dbms_lob.createtemporary(lob_, true);
  dbms_lob.open(fh, dbms_lob.lob_readonly);

  dbms_lob.loadclobfromfile(lob_, fh, amount, dest_offset, src_offset, bfile_csid, lang_context, warning);

  -- dbms_output has issues because it's suitable only for varchar2
  --dbms_output.put_line(lob_);

  insert into lob_table (n) values (lob_);
  commit;

  dbms_lob.close(fh);
  dbms_lob.freetemporary(lob_);
end;
/
show errors
    
begin
  blob_load_1;
  blob_load_2;
  nclob_load;
end;
/

select dbms_lob.getlength(b), dbms_lob.getlength(c), dbms_lob.getlength(n) from lob_table;

select utl_raw.cast_to_varchar2(dbms_lob.substr(b, 70)) from lob_table where b is not null;
