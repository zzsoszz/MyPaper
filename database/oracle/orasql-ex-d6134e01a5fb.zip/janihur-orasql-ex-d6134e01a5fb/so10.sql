/* PL/SQL: how to loop through sql extract() results

An answer to SO question:

http://stackoverflow.com/q/7248726

You're looking for (XMLTABLE)[http://download.oracle.com/docs/cd/E11882_01/server.112/e17118/functions253.htm#CIHGGHFB].
*/

create table so10t(
  id number,
  data xmltype
);

insert into so10t values (1, xmltype(
'<row>
  <date name="date1" id="101"></date>
  <element1 name="ele1" id="111">
    <stuff></stuff>
    <stuff></stuff>
    <stuff></stuff>
  </element1>
  <element2 name="ele2" id="121">
  </element2>
  <element15 name="ele15" id="1151"></element15>
</row>'));
insert into so10t values (2, xmltype(
'<row>
  <date name="date2" id ="102"/>
  <elem23 name="ele23" id="201">
    <whatever/>
  </elem23>
  <elem56 name="ele56" id="402"/>
  <elem112 name="ele112" id="804"/>
</row>'));

declare
  type rec_t is record(
    date_name varchar2(10),
    date_id number,
    first_elem_name varchar2(10),
    first_elem_id number,
    second_elem_name varchar2(10),
    second_elem_id number
  );
  rec rec_t;
  cur sys_refcursor;
begin
  open cur for
    select x.*
      from so10t,
      xmltable('row' passing so10t.data
               columns
               -- 1. the name attribute of the date field 
               date_name varchar2(10) path 'date/@name',
               -- 2. the id attribute of the date field
               date_id number path 'date/@id',
               -- 3. the name attribute of the first node after the date
               first_elem_name varchar2(10) path 'date/(following::*)[1]/@name',
               -- 4. the id attribute of the first node after the date
               first_elem_id number path 'date/(following::*)[1]/@id',
               -- 5. the name attribute of the second node after the date
               second_elem_name varchar2(10) path 'date/(following::*)[1]/(following::*)[1]/@name',
               -- 6. the id attribute of the second node after the date
               second_elem_id number path 'date/(following::*)[1]/(following::*)[1]/@id'
               ) x
	where rownum < 2;

  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line(rec.date_name || ';' || rec.date_id || ';' ||
                         rec.first_elem_name || ';' || rec.first_elem_id || ';' ||
                         rec.second_elem_name || ';' || rec.second_elem_id);
    fetch cur into rec;
  end loop;

  close cur;
end;
/

drop table so10t;

quit
