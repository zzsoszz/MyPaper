/* Oracle XML : Skip Not exist Node

An answer to SO question: http://stackoverflow.com/q/18583872/

*/

col number_ for 9999
col code for 9999

with xmldata(d) as (select xmltype('<begin>
    <entry>
        <lastname>gordon</lastname>
        <NumberList>
            <number>100</number>
            <codelist>
                 <code>213</code>
            </codelist>
        </NumberList>
        <address>
            <addresslist>Jl. jalan pelan-pelan ke Bekasi, Indonesia</addresslist>
        </address>
    </entry>
    <entry>
        <lastname>mark</lastname>
        <address>
            <addresslist>Jl. jalan cepet-cepet ke Jakarta, Indonesia</addresslist>
        </address>
    </entry>
</begin>') from dual
)
select x.* from xmldata,
xmltable('begin/entry' passing xmldata.d
         columns
         last_name varchar2(10) path 'lastname',
         number_ number path 'NumberList/number',
         code number path 'NumberList/codelist/code',
         address varchar2(50) path 'address/addresslist'
) x
;