create table xml_test(
  id number,
  data1 clob,
  data2 xmltype
);


insert into xml_test values(
1,
to_clob(xmltype('<top><foo>I''m foo !</foo><bar>I''m bar !</bar></top>')),
xmltype('<top><foo>I''m foo !</foo><bar>I''m bar !</bar></top>')
);

insert into xml_test values (
2, 
to_clob(xmlelement(top,xmlelement(foo,'I''m foo!'), xmlelement(bar, 'I''m bar!'))),
xmlelement(top,xmlelement(foo,'I''m foo!'), xmlelement(bar, 'I''m bar!'))
);

/* http://stackoverflow.com/questions/3975027/quick-introduction-on-how-to-use-oracle-xml-data-type/3975032#3975032 */
insert into xml_test values (
10,
to_clob(xmltype.createxml('<top><foo>I''m first foo !</foo><bar>I''m first bar !</bar></top>')),
xmltype('<top><foo>I''m first foo !</foo><bar>I''m first bar !</bar></top>')
);
insert into xml_test values (
11,
to_clob(xmltype.createxml('<top><foo>I''m second foo !</foo><bar>I''m second bar !</bar></top>')),
xmltype('<top><foo>I''m second foo !</foo><bar>I''m second bar !</bar></top>')
);
insert into xml_test values (
12,
to_clob(xmltype.createxml('<top><foo>I''m third foo !</foo><bar>I''m third bar !</bar></top>')),
xmltype('<top><foo>I''m third foo !</foo><bar>I''m third bar !</bar></top>')
);

column id format 99
column data1 format a35
column data2 like data1

select * from xml_test order by id;

column "bar" format a17
column "BAR" format a17
column "foo" format a17
column "FOO" format a17

-- data1 is clob
select id,
       xmltype(x.data1).extract('//bar/text()') as "bar",
       xmltype(x.data1).extract('//BAR/text()') as "BAR",
       xmltype(x.data1).extract('//foo/text()') as "foo",
       xmltype(x.data1).extract('//FOO/text()') as "FOO"
from xml_test x;

-- getClobVal() requires table alias !
select t.id, t.data2.getClobVal() as data2 from xml_test t;

select xt.id, texts.*
from xml_test xt,
     xmltable('//TOP|top' passing xt.data2
              columns "foo" varchar2(15) path 'foo',
                      "FOO" varchar2(15) path 'FOO',
                      "bar" varchar2(15) path 'bar',
                      "BAR" varchar2(15) path 'BAR') as texts;

select xt.id, t.*
from xml_test xt,
     xmltable('//top' passing xt.data2
              columns "FOO" varchar2(15) path 'foo',
                      "BAR" varchar2(15) path 'bar') t;

column "FOO" clear
column "BAR" clear
select xt.id,
       xmlcast(xmlquery('//foo' passing xt.data2 returning content)
               as varchar2(30)) "FOO",
       xmlcast(xmlquery('//bar' passing xt.data2 returning content)
               as varchar2(30)) "BAR"
from xml_test xt;

select xmlcast(xt.data2 as clob) from xml_test xt;

select xmlcast(xt.data2 as varchar(40)) from xml_test xt;

column "bar" clear
select xmlcast(xmlquery('//bar/text()'
                        passing xml_test.data2 returning content)
               as varchar2(50)) "bar"
from xml_test;

select to_clob(xmlelement(top,
			  xmlelement(foo,'I''m foo!'),
			  xmlelement(bar, 'I''m bar!'))) from dual;

drop table xml_test;

quit
