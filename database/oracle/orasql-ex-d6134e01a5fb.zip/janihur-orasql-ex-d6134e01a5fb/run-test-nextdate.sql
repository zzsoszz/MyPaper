-- runs the tests of package NEXTDATE

@@packages/assert.sql
show errors
@@packages/nextdate.sql
show errors
@@test/test_nextdate.sql
show errors

exec TEST_NEXTDATE.run;

drop package TEST_NEXTDATE;
drop package NEXTDATE;
drop package assert;
