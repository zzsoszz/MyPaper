/* How to convert a string to number in PL/SQL

An answer to SO question: http://stackoverflow.com/q/8395866

*/

create or replace function is_int(p_str in varchar2) return number as
begin
  if regexp_instr(p_str, '^[[:space:]]*[[:digit:]]{1,5}[[:space:]]*$') > 0 then
    return 1;
  end if;

  return 0;
end;
/
show errors

with strings as (
  select 1 as testcase, '12345' as string from dual
  union all
  select 2, '1234' as string from dual
  union all
  select 3, '123' as string from dual
  union all
  select 4, '12' as string from dual
  union all
  select 5, '1' as string from dual
  union all
  select 6, '01' as string from dual
  union all
  select 7, '' as string from dual
  union all
  select 8, '  345' as string from dual
  union all
  select 9, '123  ' as string from dual
  union all
  select 10, '12.45' as string from dual
  union all
  select 11, '12 45' as string from dual
  union all
  select 12, '12,45' as string from dual
  union all
  select 13, '-1234' as string from dual
  union all
  select 14, '+1234' as string from dual
  union all
  select 15, 'A2345' as string from dual
)
select testcase, to_number(string)
from strings
where is_int(string) = 1
;

create or replace function to_int(p_str in varchar2) return number as
begin
  if regexp_instr(p_str, '^[[:space:]]*[[:digit:]]{1,5}[[:space:]]*$') > 0 then
    return to_number(p_str);
  end if;

  return null;
end;
/
show errors

with strings as (
  select 1 as testcase, '12345' as string from dual
  union all
  select 2, '1234' as string from dual
  union all
  select 3, '123' as string from dual
  union all
  select 4, '12' as string from dual
  union all
  select 5, '1' as string from dual
  union all
  select 6, '01' as string from dual
  union all
  select 7, '' as string from dual
  union all
  select 8, '  345' as string from dual
  union all
  select 9, '123  ' as string from dual
  union all
  select 10, '12.45' as string from dual
  union all
  select 11, '12 45' as string from dual
  union all
  select 12, '12,45' as string from dual
  union all
  select 13, '-1234' as string from dual
  union all
  select 14, '+1234' as string from dual
  union all
  select 15, 'A2345' as string from dual
)
select testcase, '''' || string || '''' as string
from strings
where to_int(string) is not null
;

drop function is_int;
drop function to_int;

quit