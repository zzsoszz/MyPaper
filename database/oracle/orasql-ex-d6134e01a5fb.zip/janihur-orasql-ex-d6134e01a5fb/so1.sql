/* How to eliminate subtype dependency ?

http://stackoverflow.com/questions/6705179/how-to-eliminate-subtype-dependency

In the example below I have written one to_str()-function and one set()-procedure for every pls_integer subtype. The functions and procedures are almost identical except the type.

How I can eliminate the need to write yet another to_str() and set() for a new subtype without giving up the constraints provided by the subtype ?

Falling back to varchar2 like

    procedure set(list in varchar2, prefix in varchar2)

and then calling it as

    set(to_str(list), 'foos:')

doesn't sound too great idea and I still need to provide to_str() for each subtype.

I'm open for all kind of different proposals as I'm Oracle newbie and new Oracle features suprise me almost daily.

I'm running 11.2.0.1.0.
*/

create table so1table (
  id number,
  data varchar(20)
);

create or replace package so1 as
  subtype foo_t is pls_integer range 0 .. 4 not null;
  type foolist is table of foo_t;
  procedure set(id_ in number, list in foolist default foolist(1));

  subtype bar_t is pls_integer range 5 .. 10 not null;
  type barlist is table of bar_t;
  procedure set(id_ in number, list in barlist default barlist(5));
end;
/
show errors

create or replace package body so1 as
  /* Do I have always to implement these very similar functions/procedures for
  every single type ? */
  function to_str(list in foolist) return varchar2 as
    str varchar2(32767);
  begin
    for i in list.first .. list.last loop
      str := str || ' ' || list(i);
    end loop;
    return str;
  end;

  function to_str(list in barlist) return varchar2 as
    str varchar2(32767);
  begin
    for i in list.first .. list.last loop
      str := str || ' ' || list(i);
    end loop;
    return str;
  end;

  procedure set(id_ in number, list in foolist default foolist(1)) as
    values_ constant varchar2(32767) := 'foos:' || to_str(list);
  begin
    insert into so1table (id, data) values (id_, values_);
  end;

  procedure set(id_ in number, list in barlist default barlist(5)) as
    values_ constant varchar2(32767) := 'bars:' || to_str(list);
  begin
    insert into so1table (id, data) values (id_, values_);
  end;
end;
/
show errors

begin
  so1.set(1, so1.foolist(0, 3));
  so1.set(2, so1.barlist(5, 7, 10));
end;
/

select * from so1table;

drop package so1;
drop table so1table;

quit
