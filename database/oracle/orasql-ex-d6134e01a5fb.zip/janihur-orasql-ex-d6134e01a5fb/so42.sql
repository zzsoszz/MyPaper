/* SUM and COUNT xPath expression doesn't work in Oracle 11.2

An answer to SO question: http://stackoverflow.com/q/23267130/272735
*/

with 
xmldata as (
  select xmltype('<a><b><c>1</c><d>TEXT1</d></b><b><c>2</c><d>TEXT2</d></b></a>') as data_ from dual
)
select 'COUNT', xmlquery('
count($doc/a/b/c)
' passing data_ as "doc" returning content) as result_
from xmldata
union all
select 'SUM', xmlquery('
sum($doc/a/b/c)
' passing data_ as "doc" returning content) as result_
from xmldata
;
