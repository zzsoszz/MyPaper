/* Answer to an OTN question about namespaces.
   See: http://forums.oracle.com/forums/thread.jspa?threadID=2247867 */

DECLARE
   lc_test_xsd   CLOB;
BEGIN
   lc_test_xsd   := '<?xml version="1.0" encoding="UTF-8"?>
 
<schema 
    xmlns="http://www.w3.org/2001/XMLSchema"
    xmlns:tns="http://www.xyz.com/cicat/types/basictypes/2/0" 
    targetNamespace="http://www.xyz.com/cicat/types/basictypes/2/0" 
    version="2.0">
    
    <simpleType name="LastNamePrefix">
        <annotation>
            <documentation>
                Additional word to last name (name prefix) corresponding to SAP HR Core 
                Table T535N; V.
            </documentation>
        </annotation>
        <restriction base="tns:String255" />
    </simpleType>
    <simpleType name="CountryID">
        <annotation>
            <documentation>
                Codes for the representation of country names according to ISO 3166.
            </documentation>
        </annotation>
        <restriction base="string">
            <maxLength value="2" />
        </restriction>
    </simpleType>
    <simpleType name="LocationCode">
        <annotation>
            <documentation>
                Code of a location, e.g. Fe, Wa2 or Kor.
            </documentation>
        </annotation>
        <restriction base="string">
            <maxLength value="4" />
        </restriction>
    </simpleType>
    <simpleType name="GenderCode">
        <annotation>
            <documentation>
                Code of the gender: male, female, unknown. Unknown is used if the value is 
                unknown or must not be stored due to legal restrictions.
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="male" />
            <enumeration value="female" />
            <enumeration value="unknown" />
        </restriction>
    </simpleType>
    <simpleType name="String255">
        <annotation>
            <documentation>
                String with 255 characters max
            </documentation>
        </annotation>
        <restriction base="string">
            <maxLength value="255" />
            <minLength value="1" />
        </restriction>
    </simpleType>
    <simpleType name="RB-CostCenter">
        <annotation>
            <documentation>
                Cost Center
            </documentation>
        </annotation>
        <restriction base="string">
            <minLength value="3" />
            <maxLength value="6" />
        </restriction>
    </simpleType>
    <simpleType name="OrgUnitName">
        <annotation>
            <documentation>
                Name of the Organizational Unit
            </documentation>
        </annotation>
        <restriction base="string">
            <minLength value="1" />
            <maxLength value="18" />
        </restriction>
    </simpleType>
    <complexType name="StringMCA">
        <annotation>
            <documentation>
                Multi Country String. Strings, which must be stored in ASCII code and 
                country specific. The subelement ASCIIString contains the string encoded
                with ASCII. The subelement countrySpecificString allows country specific
                encoding.
            </documentation>
        </annotation>
        <sequence>
            <element name="asciiString" type="tns:String255" minOccurs="0" />
            <element name="countrySpecificString" type="tns:String255" />
        </sequence>
    </complexType>
    <simpleType name="OrgUnitID">
        <annotation>
            <documentation>
                ID of the Organizational Unit
            </documentation>
        </annotation>
        <restriction base="unsignedInt">
            <totalDigits value="8" />
        </restriction>
    </simpleType>
    <simpleType name="GlobalID">
        <annotation>
            <documentation>
                Global unique identifier of persons at xyz
            </documentation>
        </annotation>
        <restriction base="unsignedInt">
            <totalDigits value="8" />
        </restriction>
    </simpleType>
    <simpleType name="CiCatPersonID">
        <annotation>
            <documentation>
                CI-CAT Identifier of Persons (CiCat-PID). Unique identifier of a person
                in CI-CAT
            </documentation>
        </annotation>
        <restriction base="unsignedInt">
            <totalDigits value="20" />
        </restriction>
    </simpleType>
    <simpleType name="CiCatAccountID">
        <annotation>
            <documentation>
                CI-CAT Identifier of AD Accounts (CiCat-Ben-Sid). Unique identifier of 
                AD Accounts in CI-CAT.
            </documentation>
        </annotation>
        <restriction base="unsignedInt">
            <totalDigits value="20" />
        </restriction>
    </simpleType>
    <simpleType name="PersonnelActionTypeCode">
        <annotation>
            <documentation>
                The operation that was performed on the person: entry, data change,
                re-entry (into company), exit (out of company)
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="entry" />
            <enumeration value="data change" />
            <enumeration value="re-entry" />
            <enumeration value="exit" />
        </restriction>
    </simpleType>
    <simpleType name="ContractStatus">
        <annotation>
            <documentation>
                Contract Status: active, inaktive, resigned, retired
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="retired">
                <annotation>
                    <documentation>
                        End of contract relationship because of retirement
                    </documentation>
                </annotation>
            </enumeration>
            <enumeration value="resigned">
                <annotation>
                    <documentation>
                        End of contract because of quitting
                    </documentation>
                </annotation>
            </enumeration>
            <enumeration value="inactive">
                <annotation>
                    <documentation>
                        Incactive contract relationship, e.g. motherhood, suspension
                    </documentation>
                </annotation>
            </enumeration>
            <enumeration value="active">
                <annotation>
                    <documentation>
                        Normal contract status
                    </documentation>
                </annotation>
            </enumeration>
            <enumeration value="deleted">
                <annotation>
                    <documentation>
                        Contract physically deleted in the source system
                    </documentation>
                </annotation>
            </enumeration>
        </restriction>
    </simpleType>
    <simpleType name="KnownAssociateCode">
        <annotation>
            <documentation>
                Describes status of person to xyz: internal/external/fixed-term
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="External" />
            <enumeration value="Internal" />
            <enumeration value="Fixed Term" />
            <enumeration value="unknown" />
        </restriction>
    </simpleType>
    <simpleType name="AssociateCode">
        <annotation>
            <documentation>
                Describes status of person to xyz: union of known values plus free string 
                for not yet known types
            </documentation>
        </annotation>
        <union memberTypes="tns:KnownAssociateCode string" />
    </simpleType>
    <simpleType name="KnownExternalRelationType">
        <annotation>
            <documentation>
                Describes relation (contract relation) of external person to xyz:
                contractor/customer/supplier/subsidiary/selfregistered
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="Contractor" />
            <enumeration value="Customer" />
            <enumeration value="Supplier" />
            <enumeration value="Subsidiary" />
            <enumeration value="Selfregistered" />
            <enumeration value="unknown" />
        </restriction>
    </simpleType>
    <simpleType name="ExternalRelationType">
        <union memberTypes="tns:KnownExternalRelationType string" />
    </simpleType>
    <simpleType name="ValidityState">
        <annotation>
            <documentation>
                If an attribute was taken over by an authoritative source such as HR-MDS or 
                WOM. Set to "Valid" to indicate that the value was taken over from the 
                source and is therefore valid. Set to "Invalid" if the source indicates the
                value is no longer value, e.g. because it got deleted. Otherwise set to 
                "Unknown", e.g. when the value was entered manually.
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="Valid" />
            <enumeration value="Invalid" />
            <enumeration value="Unknown" />
        </restriction>
    </simpleType>
    <complexType name="HrPersonnelId">
        <sequence>
            <element name="hrSourceSystem">
                <annotation>
                    <documentation>
                        Name of HR source system
                    </documentation>
                </annotation>
                <simpleType>
                    <restriction base="string">
                        <minLength value="1" />
                        <maxLength value="20" />
                    </restriction>
                </simpleType>
            </element>
            <element name="hrPersonnelId">
                <annotation>
                    <documentation>
                        ID of person in HR source system
                    </documentation>
                </annotation>
                <simpleType>
                    <restriction base="string">
                        <minLength value="1" />
                        <maxLength value="20" />
                    </restriction>
                </simpleType>
            </element>
        </sequence>
    </complexType>
    <complexType name="AccountType">
        <annotation>
            <documentation>
                Types of Accounts: Three main categories are known: Person, resource or 
                service account. A person account represents a single natural person. A 
                resource account represents a resource such as a printer, a computer or a 
                meeting room. Service Accounts represent everything else. The can be used 
                for example for technical users or group accounts. Both resource and service 
                accounts have an owner that is responsible for them. Each account type has 
                subtypes for further categorization.
            </documentation>
        </annotation>
        <choice>
            <element name="personAccount" type="tns:PersonAccountType" />
            <element name="resourceAccount" type="tns:ResourceAccountType" />
            <element name="serviceAccount" type="tns:ServiceAccountType" />
        </choice>
    </complexType>
    <simpleType name="KnownPersonAccountType">
        <annotation>
            <documentation>
                Pre-defined types of Person Accounts
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="Office" />
            <enumeration value="Admin" />
            <enumeration value="Test" />
            <enumeration value="unknown" />
        </restriction>
    </simpleType>
    <simpleType name="PersonAccountType">
        <union memberTypes="tns:KnownPersonAccountType string" />
    </simpleType>
    <simpleType name="KnownResourceAccountType">
        <annotation>
            <documentation>
                Pre-defined types of Resource Accounts
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="Room" />
            <enumeration value="PC" />
            <enumeration value="Printer" />
            <enumeration value="unknown" />
        </restriction>
    </simpleType>
    <simpleType name="ResourceAccountType">
        <union memberTypes="tns:KnownResourceAccountType string" />
    </simpleType>
    <simpleType name="KnownServiceAccountType">
        <annotation>
            <documentation>
                Pre-defined Types of Service Accounts
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="Group" />
            <enumeration value="Machine" />
            <enumeration value="Support" />
            <enumeration value="System" />
            <enumeration value="unknown" />
        </restriction>
    </simpleType>
    <simpleType name="ServiceAccountType">
        <union memberTypes="tns:KnownServiceAccountType string" />
    </simpleType>
    <simpleType name="ActionType">
        <annotation>
            <documentation>
                Defines the action that was performed on the object.
            </documentation>
        </annotation>
        <restriction base="string">
            <enumeration value="Create" />
            <enumeration value="Update" />
            <enumeration value="Delete" />
        </restriction>
    </simpleType>
    <simpleType name="LegalEntityId">
        <annotation>
            <documentation>
                ID of a legal entity
            </documentation>
        </annotation>
        <restriction base="unsignedInt">
            <totalDigits value="8" />
        </restriction>
    </simpleType>
</schema>
';
 
   DBMS_XMLSCHEMA.REGISTERSCHEMA (schemaurl   => 'BasicTypes.xsd',
                                  schemadoc   => lc_test_xsd);
                                  
  DBMS_OUTPUT.PUT_LINE('BasicTypes.xsd registration successfully completed');
EXCEPTION WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('BasicTypes.xsd registration failed '||SQLERRM);
END;
/ 

-- register PersonTypes.xsd schema
 
 
DECLARE
 lc_person_xsd   CLOB;
BEGIN
   lc_person_xsd 
      := '<?xml version="1.0" encoding="UTF-8"?>
<!--
    Change History:     
-->
<!--
    This schema contains all types that represent objects (i.e. Person and ADAccount). 
-->
 
<schema
    xmlns="http://www.w3.org/2001/XMLSchema"
    xmlns:tns="http://www.xyz.com/cicat/types/persontypes/2/0" 
    xmlns:basic="http://www.xyz.com/cicat/types/basictypes/2/0"
    targetNamespace="http://www.xyz.com/cicat/types/persontypes/2/0" 
    version="2.0">
    
    <import namespace="http://www.xyz.com/cicat/types/basictypes/2/0" schemaLocation="BasicTypes.xsd"/>
    
    <complexType name="ADAccount">
        <annotation>
            <documentation>
                Active directory account of a person (also known as NT or Windows account)
            </documentation>
        </annotation>
        <sequence>
            <element name="cicatAccountId" type="basic:CiCatAccountID">
                <annotation>
                    <documentation>
                        CICAT internal ID of account (CI-CAT Ben SID)
                    </documentation>
                </annotation>
            </element>
            <element name="domain" type="basic:String255">
                <annotation>
                    <documentation>
                        NT domain of the userID, e.g. "de", "emea"
                    </documentation>
                </annotation>
            </element>
            <element name="userID" type="basic:String255">
                <annotation>
                    <documentation>
                        NT userID e.g. "xyz5mum" without domain (NT-SID)
                    </documentation>
                </annotation>
            </element>
            <element name="guid" type="basic:String255">
                <annotation>
                    <documentation>
                        Active Directory GUID of account.
                    </documentation>
                </annotation>
            </element>
            <element name="isMasterAccount" type="boolean"
                default="false" minOccurs="0">
                <annotation>
                    <documentation>
                        A person can have several accounts. One of them is marked as the 
                        master account. The master account is the account which is mainly 
                        used by the user.
                    </documentation>
                </annotation>
            </element>
            <element name="accountType" type="basic:AccountType">
                <annotation>
                    <documentation>
                        Types of Accounts: Three main categories are known: Person, resource 
                        or service account. A person account represents a single natural 
                        person. A resource account represents a resource such as a printer, 
                        a computer or a meeting room. Service Accounts represent everything 
                        else. The can be used for example for technical users or group 
                        accounts. Both resource and service accounts have an owner that is 
                        responsible for them. Each account type has subtypes for further 
                        categorization.
                    </documentation>
                </annotation>
            </element>
        </sequence>
    </complexType>
    <complexType name="Person">
        <annotation>
            <documentation>
                All attributes a CI-CAT person record can contain
            </documentation>
        </annotation>
        <sequence>
            <element name="globalID" type="basic:GlobalID" minOccurs="0">
                <annotation>
                    <documentation>
                        Globally unique identifier of a person at xyz. This ID is defined 
                        by HR MDS.
                    </documentation>
                </annotation>
            </element>
            <element name="cicatPID" type="basic:CiCatPersonID">
                <annotation>
                    <documentation>
                        Unique identifier of person in CI-CAT.
                    </documentation>
                </annotation>
            </element>
            <element name="hrPersonnelId" type="basic:HrPersonnelId" minOccurs="0">
                <annotation>
                    <documentation>
                        Personnel ID of person in an HR system. The personnel ID is unique
                        throughout one system. But different systems can use the same ID. 
                    </documentation>
                </annotation>
            </element>
            <element name="title" type="basic:String255"
                minOccurs="0">
                <annotation>
                    <documentation>
                        Title of the person. In some countries and HR-MDS this field is used
                        for the academic title. In other countries it is used for the job
                        title.
                    </documentation>
                </annotation>
            </element>
            <element name="firstName" type="basic:StringMCA">
                <annotation>
                    <documentation>
                        First name of the person
                    </documentation>
                </annotation>
            </element>
            <element name="middleName" type="basic:StringMCA" minOccurs="0">
                <annotation>
                    <documentation>
                        Middle name(s) of the person
                    </documentation>
                </annotation>
            </element>
            <element name="lastNameAddOn" type="basic:String255"
                minOccurs="0">
                <annotation>
                    <documentation>
                        Additional word to surname (name prefix)
                        corresponding to SAP HR Core Table T535N; V.
                    </documentation>
                </annotation>
            </element>
            <element name="lastName" type="basic:StringMCA">
                <annotation>
                    <documentation>
                        Last names of the person.
                    </documentation>
                </annotation>
            </element>
            <element name="displayName" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>
                        Display name of the person. This attribute is calculated from the
                        name, the department. In case of external users it also contains
                        an external flag and the name of the company. This field is 
                        calculated by CI-CAT.
                    </documentation>
                </annotation>
            </element>
            <element name="gender" type="basic:GenderCode" minOccurs="0">
                <annotation>
                    <documentation>
                        Gender of the person
                    </documentation>
                </annotation>
            </element>
            <element name="orgUnitID" type="basic:OrgUnitID" minOccurs="0">
                <annotation>
                    <documentation>
                        ID of Organization unit (determined by C/AOO). This ID is taken over
                        from WOM.
                    </documentation>
                </annotation>
            </element>
            <element name="orgUnitIDValidity" type="basic:ValidityState" minOccurs="0">
                <annotation>
                    <documentation>
                        Defines if the attribute orgUnitID was validated by an authoritative 
                        source. The default value is "Unknown".
                        
                        VALID: 
                        - orgUnitID is linked with WOM reference and orgUnitID is active in WOM
                        - orgUnitID is linked with Exception Organization list maintained in 
                          CI-CAT by C/AOO. orgUnitID is active in with Exception Organization list 
 
                        INVALID:
                        - orgUnitID is linked with WOM reference and orgUnitID is inactive in WOM
                        - orgUnitID is linked with Exception Organization list maintained in CI-CAT 
                          by C/AOO. orgUnitID is inactive in with Exception Organization list 
 
                        UNKNOWN:
                        - orgUnitID is not linked with WOM reference or Exception Organization 
                          list. Active state of the department is not known.
                    </documentation>
                </annotation>
            </element>
            <element name="orgUnitName" type="basic:OrgUnitName">
                <annotation>
                    <documentation>
                        Unit Code (determined by C/AOO) of the organizational office, e.g. 
                        Department, group, Project.
                    </documentation>
                </annotation>
            </element>
            <element name="costCenter" type="basic:RB-CostCenter">
                <annotation>
                    <documentation>
                        Cost center the person is assigned to.
                    </documentation>
                </annotation>
            </element>
            <element name="costCenterValidity" type="basic:ValidityState" minOccurs="0">
                <annotation>
                    <documentation>
                        Defines if the attribute costCenter was validated by an authoritative 
                        source. The default value is "Unknown".
                    </documentation>
                </annotation>
            </element>
            <element name="email" type="basic:String255"
                minOccurs="0">
                <annotation>
                    <documentation>
                        Primary email of person
                    </documentation>
                </annotation>
            </element>
            <element name="legalEntity" type="basic:LegalEntityId" minOccurs="0">
                <annotation>
                    <documentation>
                        ID of a legalEntity. Legal Entity List will be
                        retrieved from CI-CAT.
                    </documentation>
                </annotation>
            </element>
            <element name="officeLocation" type="basic:LocationCode" minOccurs="0">
                <annotation>
                    <documentation>
                        The office location where the person is currently working, 
                        e.g. Fe, Kor, Wa2. Maintained in CI-CAT.
                    </documentation>
                </annotation>
            </element>
            <element name="maintenanceLocation" type="basic:LocationCode" minOccurs="0">
                <annotation>
                    <documentation>
                        The location of the HR department which maintains the person, taken from HR-MDS.
                    </documentation>
                </annotation>
            </element>
            <element name="building" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>
                        Building free-from data
                    </documentation>
                </annotation>
            </element>
            <element name="room" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>
                        Room (Section, floor and room number)
                    </documentation>
                </annotation>
            </element>
            <element name="externalCompany" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>
                        For Externals: Name of the external company.
                    </documentation>
                </annotation>
            </element>
            <element name="externalCompanyLocation" type="basic:LocationCode" minOccurs="0">
                <annotation>
                    <documentation>
                        For Externals: The location of the external company.
                    </documentation>
                </annotation>
            </element>
            <element name="personnelActionType" type="basic:PersonnelActionTypeCode" minOccurs="0">
                <annotation>
                    <documentation>
                        Defines the action type used in SAP HR systems,e.g. Hiring (entry); 
                        Organizational reasignment; Transfer; Change in pay; 
                        early retirement / retirement; leaving; Re-entry into company
                    </documentation>
                </annotation>
            </element>
            <element name="statusOfContract" type="basic:ContractStatus">
                <annotation>
                    <documentation>
                        Status of current occupation, e.g. active; inactive; resigned; retired
                    </documentation>
                </annotation>
            </element>
            <element name="xyzGroupAssociate" type="basic:AssociateCode">
                <annotation>
                    <documentation>
                        Indicates whether person is xyz Group associate or external 
                        according to respective regulations : external; internal
                    </documentation>
                </annotation>
            </element>
            <element name="externalRelationToxyz" type="basic:ExternalRelationType" 
                minOccurs="0" maxOccurs="unbounded">
                <annotation>
                    <documentation>
                        Describes for persons of type xyzGroupAssociate = external the 
                        relationship to xyz, e.g. customer, subsidiary, ...
                        Persons can be in more than one relation to xyz.
                    </documentation>
                </annotation>
            </element>
            <element name="phone" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>
                        Phone Number
                    </documentation>
                </annotation>
            </element>
            <element name="otherPhone" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>
                        "Business 2/Other Telephone" ist ein multivalue field which can be
                        filled with additional phone numbers (canonical format).  
                    </documentation>
                </annotation>
            </element>
            <element name="mobile" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>
                        Mobile Phone Number
                    </documentation>
                </annotation>
            </element>
            <element name="paperFax" type="basic:String255" minOccurs="0" />
            <element name="electronicFax" type="basic:String255" minOccurs="0" />
            <element name="ipPhone" type="basic:String255" minOccurs="0">
                <annotation>
                    <documentation>IP Phone Number</documentation>
                </annotation>
            </element>
            <element name="lastModified" type="dateTime">
                <annotation>
                    <documentation>
                        last Time person was modified in CI-CAT
                    </documentation>
                </annotation>
            </element>
            <element name="lastModifyingUser" type="basic:String255">
                <annotation>
                    <documentation>
                        Last person, who modified person in CI-CAT. Can be a CI-CAT system
                        user, e.g. user to connect CI-CAT to WOM.
                    </documentation>
                </annotation>
            </element>
            <element name="assistant" type="basic:GlobalID" minOccurs="0">
                <annotation>
                    <documentation>
                        Assistant of person. Reference to assistant vie
                        globalId
                    </documentation>
                </annotation>
            </element>
            <element name="activeDirectoryAccount" type="tns:ADAccount"
                maxOccurs="unbounded" minOccurs="0">
                <annotation>
                    <documentation>
                        List of Active Directory accounts of the user.
                        To indicate that a user is deleted, the list of
                        AD accounts is empty.
                    </documentation>
                </annotation>
            </element>
        </sequence>
        <attribute name="action" type="basic:ActionType" use="required"/>
    </complexType>
    
    <element name="person" type="tns:Person"/>
</schema>
';
 
   DBMS_XMLSCHEMA.REGISTERSCHEMA (schemaurl   => 'PersonTypes.xsd',
                                  schemadoc   => lc_person_xsd);
                                  
  DBMS_OUTPUT.PUT_LINE('PersonTypes.xsd registration successfully completed');
EXCEPTION WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('PersonTypes.xsd registration failed '||SQLERRM);
END;
/

DECLARE
   lx_xml_doc   XMLType := 
      XMLTYPE (
         '<?xml version="1.0"?>
<tns:person xmlns:tns="http://www.xyz.com/cicat/types/persontypes/2/0" action="Update">
  <cicatPID>877111</cicatPID>
  <firstName>
    <asciiString>rname</asciiString>
  </firstName>
  <lastName>
    <asciiString>Anu</asciiString>
  </lastName>
  <displayName>name (POL3)</displayName>
  <gender>unknown</gender>
  <orgUnitID>1301</orgUnitID>
  <orgUnitIDValidity>Valid</orgUnitIDValidity>
  <orgUnitName>POL3</orgUnitName>
  <costCenter>652001</costCenter>
  <costCenterValidity>Valid</costCenterValidity>
  <email>radha.Anu13@xyz.com</email>
  <officeLocation>Cob</officeLocation>
  <building>Cob</building>
  <xyzGroupAssociate>Internal</xyzGroupAssociate>
  <phone>+91(422)</phone>
  <otherPhone>4000</otherPhone>
  <paperFax>+91(422)</paperFax>
  <lastModified>2011-07-04</lastModified>
  <lastModifyingUser>QICAT_Z</lastModifyingUser>
  <activeDirectoryAccount>
    <cicatAccountId>1244632</cicatAccountId>
    <domain>XYZ01</domain>
    <userID>RAU6COB</userID>
    <guid>8f796889-5997-44b8-83bf-da1d4e336f66</guid>
    <isMasterAccount>true</isMasterAccount>
  </activeDirectoryAccount>
</tns:person>').createSchemaBasedXML (
         'PersonTypes.xsd');
BEGIN
   lx_xml_doc.schemaValidate ();
END;
/ 

declare
begin
  dbms_xmlschema.deleteschema('PersonTypes.xsd', dbms_xmlschema.delete_cascade);
  dbms_xmlschema.deleteschema('BasicTypes.xsd', dbms_xmlschema.delete_cascade);
end;
/
