-- Posted to OTN:
-- http://forums.oracle.com/forums/message.jspa?messageID=9717093#9717093

WITH x AS (SELECT XMLTYPE('<department xmlns="http://demo.department.com">
  <library>
    <book>
      <title>title one</title>
      <author>author one</author>
      <description>description one</description>
    </book>
    <book>
      <title>title two</title>
      <author>author two</author>
      <description>description two</description>
    </book>
  </library>
</department>') object_value FROM dual)
SELECT distinct b.column_value.getrootelement() nodesentry
FROM x, TABLE (XMLSEQUENCE (EXTRACT (x.object_value,
                                     '*/library/book/node()',
                                     'xmlns="http://demo.department.com"'))) b;
