/* Receive a db link name as a variable in Oracle PLSQL

An answer to SO question: http://stackoverflow.com/q/21094182/272735

*/

declare
  function remote_time(p_dblink in varchar2) return number is
    v_time number; 
  begin  
    execute immediate
      'begin :time := dbms_utility.get_time@' || p_dblink || '; end;'
    using out v_time;
    return v_time;
  end;
begin
  dbms_output.put_line('time = ' || remote_time('foo'));
end;
/
