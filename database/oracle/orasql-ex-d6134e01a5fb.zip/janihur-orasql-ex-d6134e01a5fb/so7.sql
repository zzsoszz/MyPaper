/* PL/SQL procedures same row

An answer to SO question:

http://stackoverflow.com/questions/7035372/pl-sql-procedures-same-row/7035915#7035915

You really should pay attention how to write questions. It would help us to help you. This is my guess what you are looking for. Unfortunately I don't have 9i available, but hope this helps !
*/

    create table so7t (
      id number,
      name varchar2(10),
      data number -- date is a reserved word and can't be used as identifier
    );
    
    -- 1001
    insert into so7t values (1, 'zhang', 9);
    -- 1100
    insert into so7t values (1, 'zhang', 12);
    -- 0001
    insert into so7t values (2, 'wang', 1);
    -- 0010
    insert into so7t values (2, 'wang', 2);
    
    select * from so7t;
    
    /* from http://www.dbsnaps.com/oracle/bitwise-operators-in-oracle/ */
    create or replace function bitor (x number, y number)
    return number
    is
    begin
      return (x + y) - bitand(x, y);
    end;
    /
    show errors
    
    create or replace procedure solve (
      p_id in number
    ) as
      type ids_t is table of number;
      v_ids ids_t;
      v_result number := 0;
    begin
      select data bulk collect into v_ids from so7t where id = p_id;
    
      for i in v_ids.first .. v_ids.last loop
        v_result := bitor(v_result, v_ids(i));
      end loop;
    
      delete from so7t where id = p_id;
    
      insert into so7t values (p_id, 'DIY', v_result);
    end;
    /
    show errors
    
    begin
      solve(1);
      commit;
    
      solve(2);
      commit;
    end;
    /
    
    select * from so7t;
    
    drop function bitor;
    drop procedure solve;
    drop table so7t;
    
    quit
