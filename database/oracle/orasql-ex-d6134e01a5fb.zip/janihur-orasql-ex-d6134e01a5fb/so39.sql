/* Type table null value check

An answer to SO question: http://stackoverflow.com/q/22608297/272735

*/

declare
  type list_t is table of varchar2(10);
  v_list list_t;
begin
  --
  -- 1) v_list is a null variable
  --

  v_list := null;

  if false then
    v_list := list_t('foo', 'bar');
  end if;

  if v_list is not null then
    dbms_output.put_line('v_list = ' || v_list(1) || ';' || v_list(2));
  else
    dbms_output.put_line('v_list is a null variable');
  end if;

  --
  -- 2) v_list is an empty but initialized collection
  --

  v_list := list_t();
  
  if false then
    v_list := list_t('foo', 'bar');
  end if;

  if v_list.exists(v_list.first) then
    dbms_output.put_line('v_list = ' || v_list(1) || ';' || v_list(2));
  else
    dbms_output.put_line('v_list is an empty but initialized collection');
  end if;

end;
/
