create sequence seq_contact start with 1000 increment by 1 nocache nocycle;

create table contact (
  contact_id integer,
  first_name varchar2(120 char),
  last_name varchar2(120 char),
  last_update_date date
);

alter table contact add constraint pk_contact primary key (contact_id);

-- create table with right type of columns
-- constraints not copied
create table h_contact as select * from contact where 1 = 2;

-- add extra columns
alter table h_contact add(version_id integer);
alter table h_contact add(status char);

alter table h_contact add constraint pk_h_contact primary key (contact_id, version_id);
/*
create table a$contact (
  version_id integer, -- this is the only new column
  contact_id integer,
  first_name varchar2(120 char),
  last_name varchar2(120 char),
  last_update_date date
);

alter table a$contact add constraint pk_a$contact primary key (contact_id, version_id);
*/
