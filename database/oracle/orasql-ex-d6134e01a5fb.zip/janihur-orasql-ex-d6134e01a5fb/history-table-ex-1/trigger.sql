create or replace trigger tr_contact
before insert or delete or update on contact
for each row
declare
  v_audit h_contact%rowtype;
begin
  select seq_contact.nextval into v_audit.version_id from dual;

  case
    when inserting then v_audit.status := 'I';
    when updating then v_audit.status := 'U';
    when deleting then v_audit.status := 'D';
    else raise value_error; -- unnecessary ?
  end case;

  if not deleting then
    :new.last_update_date := sysdate;
  end if;

  if inserting or updating then
    v_audit.contact_id := :new.contact_id;
    v_audit.first_name := :new.first_name;
    v_audit.last_name := :new.last_name;
    v_audit.last_update_date := :new.last_update_date;
  else -- deleting
    v_audit.contact_id := :old.contact_id;
    v_audit.first_name := :old.first_name;
    v_audit.last_name := :old.last_name;
    v_audit.last_update_date := sysdate;
  end if;

  insert into h_contact values v_audit;
end;
/
