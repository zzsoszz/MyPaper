-- sqlplus > @@run.sql
@drop-schema.sql
@schema.sql
@trigger.sql
@insert.sql
@select.sql

