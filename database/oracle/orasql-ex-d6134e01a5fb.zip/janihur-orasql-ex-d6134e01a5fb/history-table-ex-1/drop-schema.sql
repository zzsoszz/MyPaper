drop table h_contact;
drop table contact;
drop sequence seq_contact;
