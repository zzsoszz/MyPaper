column first_name format a20
column last_name like first_name

ttitle 'CONTACT TABLE'
select * from contact order by contact_id;

ttitle 'CONTACT HISTORY TABLE'
select * from h_contact order by contact_id, version_id;
