insert into contact (contact_id, first_name, last_name) values
  (1, 'Nick', 'Pierpoint');

insert into contact (contact_id, first_name, last_name) values
  (2, 'John', 'Coltrane');

insert into contact (contact_id, first_name, last_name) values
  (3, 'Sonny', 'Rollins');

insert into contact (contact_id, first_name, last_name) values
  (4, 'Kenny', 'Wheeler');

update contact set last_name = 'Cage' where contact_id = 1;
update contact set first_name = 'JOhnny' where contact_id = 2;
delete from contact where contact_id = 1;
update contact set first_name = 'Johnny' where contact_id = 2;
