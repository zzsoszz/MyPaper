/* Absolute minimum set of privileges required to execute a package
   (procedures). */

/* Package is created by user JANI */

create or replace package test_pkg as
  procedure get_num(p_num in number, p_ret out number);
end;
/
show errors

create or replace package body test_pkg as
  procedure get_num(p_num in number, p_ret out number) as
  begin
    p_ret := p_num + 42;
  end;
end;
/
show errors

/* Package should be executable by user TESTUSER */

variable p_ret number
exec test_pkg.get_num(41, :p_ret)
select :p_ret from dual;

/* How to create TESTUSER:

SQL> create user testuser identified by testuser;
SQL> grant create session to testuser;
SQL> grant execute on jani.test_pkg to testuser;
SQL> create synonym testuser.test_pkg for jani.test_pkg;

The synonym is just for convenience.
*/