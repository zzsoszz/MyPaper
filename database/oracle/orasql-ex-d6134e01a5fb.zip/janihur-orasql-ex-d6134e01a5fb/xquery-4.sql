-- quantified expressions

set long 2000

with xmldata as (
select xmltype('<errors><error><company>Acme Ltd</company><country>DE</country><program>Global</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error></errors>')
data_ from dual)
select xmlquery('
some $country in $doc/errors/error/country
satisfies ($country = ''DE'')
' passing data_ as "doc" returning content) as result_
from xmldata
;
