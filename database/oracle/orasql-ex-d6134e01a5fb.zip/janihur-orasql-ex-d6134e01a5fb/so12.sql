/* using record types - declaration and body in package

An answer to SO question: http://stackoverflow.com/q/7667763

*/

    create or replace package pac as
    
      type a is record (
        aa varchar2(255)
      );
    
     type b is array(1) of a;
    
     procedure proc1(som out B);
    
    end;
    /
    
    create or replace package body pac as
    
      procedure proc1(som out b) as
        v_a a;
      begin
        v_a.aa := 'foo';
        som := b(v_a);
      end;
    
    end;
    /
    show errors
    
    declare
      v_som pac.b;
    begin
      pac.proc1(v_som);
      dbms_output.put_line(v_som(1).aa); /* prints foo */
    end;
    /
    
drop package pac

quit
