create or replace package DYNCUR as
  subtype tab_rowtype_t is tab%rowtype;
  -- strongly typed row cursor variable
  type tab_cursor_t is ref cursor return tab_rowtype_t;

  -- function that generates a cursor
  function make(
    filter in varchar2 := ''
  ) return tab_cursor_t;

  -- procedure that generates a cursor
  procedure get(cur out tab_cursor_t);
end;
/
show errors

create or replace package body DYNCUR as
  function make(
    filter in varchar2 := ''
  ) return tab_cursor_t as
    cur tab_cursor_t;
  begin
    case
      when filter is null then
        open cur for
          select * from tab where tabtype = 'TABLE'
            and tname not like 'BIN$%'
            order by tname;
      else
        open cur for
          select * from tab where tabtype = 'TABLE'
            and tname not like 'BIN$%'
	    and tname not like filter
            order by tname;

    end case;
    return cur;
  end;

  procedure get(cur out tab_cursor_t) as
  begin
    open cur for
      select * from tab where tabtype = 'TABLE'
        and tname not like 'BIN$%'
        order by tname;
  end;
end;
/
show errors

declare
  cur DYNCUR.tab_cursor_t := DYNCUR.make;
  rec DYNCUR.tab_rowtype_t;
begin
  dbms_output.put_line('DYNCUR.make - while loop');
  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line('table: ' || rec.tname);
    fetch cur into rec;
  end loop;
  close cur;

  dbms_output.put_line('DYNCUR.make(''H_%'') - while loop');
  cur := DYNCUR.make('H_%');
  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line('table: ' || rec.tname);
    fetch cur into rec;
  end loop;
  close cur;

  dbms_output.put_line('DYNCUR.get - plain loop');
  DYNCUR.get(cur);
  loop
    fetch cur into rec;
    exit when cur%notfound;
    dbms_output.put_line('table: ' || rec.tname);
  end loop;
  close cur;

  dbms_output.put_line('DYNCUR.get - while loop');
  DYNCUR.get(cur);
  fetch cur into rec;
  while cur%found loop
    dbms_output.put_line('table: ' || rec.tname);
    fetch cur into rec;
  end loop;
  close cur;

/* Doesn't work
  dbms_output.put_line('DYNCUR.get - cursor for loop');
  DYNCUR.get(cur);
  for row_ in cur loop
    dbms_output.put_line('table: ' || rec.tname);
  end loop;
  close cur;
*/
end;
/
