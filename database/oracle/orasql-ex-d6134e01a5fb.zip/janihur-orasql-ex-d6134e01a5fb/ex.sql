-- -*- mode: plsql -*-

set serveroutput on
alter session set plsql_warnings = 'ENABLE:ALL';

-- Quick and brief PL/SQL examples and trials. Most recent on top.

-- Nested comments not supported

/* Template:

-- DESC:

declare
begin
end;
/

quit

-- ================================================================== --
*/
-- DESC:

declare
  v_foo varchar2(2) := 'AB';
  v_bar number;
begin
  -- raises ORA-01476: divisor is equal to zero
  v_bar := 1/0;
exception
  when others then
    dbms_output.put_line('checkpoint 1');
    v_foo := 'TOO LONG';
    dbms_output.put_line('checkpoint 2');
end;
/

quit

-- ================================================================== --
-- DESC:

declare
  type date_list_t is table of date;

  v_dates constant date_list_t := date_list_t(trunc(sysdate - 8),
                                              trunc(sysdate - 7),
                                              trunc(sysdate),
                                              trunc(sysdate + 1),
                                              trunc(sysdate + 100),
                                              trunc(sysdate + 360),
                                              trunc(sysdate + 361)
                                              );
  
  function is_date_in_range(p_date in date,
                            p_start in date default trunc(sysdate - 7),
                            p_end in date default trunc(sysdate + 360)
                            ) return boolean is
  begin
    return p_date between p_start and p_end;
  end;
begin
  for i in v_dates.first .. v_dates.last
  loop
    if is_date_in_range(v_dates(i)) then
      dbms_output.put_line('VALID: ' || v_dates(i));
    else
      dbms_output.put_line('INVALID: ' || v_dates(i));
    end if;
  end loop;
end;
/

quit

-- ================================================================== --
-- DESC: how to set boolean value with logical operators

declare
  a pls_integer;
  b pls_integer;
  x boolean;

  function to_char (
    p_val in boolean
  ) return varchar2 as
  begin
    return case p_val
      when null then 'NULL'
      when true then 'TRUE'
      else 'FALSE'
    end;
  end;
begin
  a := null;
  b := null;
  x := (a is null and b is null) or (a is not null and b is not null);
  dbms_output.put_line('x should be TRUE: ' || to_char(x));

  a := 1;
  b := null;
  x := (a is null and b is null) or (a is not null and b is not null);
  dbms_output.put_line('x should be FALSE: ' || to_char(x));

  a := 1;
  b := 1;
  x := (a is null and b is null) or (a is not null and b is not null);
  dbms_output.put_line('x should be TRUE: ' || to_char(x));

  a := null;
  b := 1;
  x := a is null and b is null;
  dbms_output.put_line('x should be FALSE: ' || to_char(x));

  a := 2;
  b := 2;
  x := (a is not null and b is not null) and (a <= b);
  dbms_output.put_line('x should be TRUE: ' || to_char(x));

  if not x
  then
    dbms_output.put_line('bing');
  end if;
end;
/

quit

-- ================================================================== --
-- DESC: multiset operations that eliminate duplicates can't be used with
-- records

declare
  type dummy_list_t is table of dual%rowtype;
  v_temp dummy_list_t; -- can be uninitialized
  v_dummys dummy_list_t := dummy_list_t();
begin
  for i in 1 .. 3 loop
    select * bulk collect into v_temp from dual connect by level < 3;
    -- distinct can't be used here
    v_dummys := v_dummys multiset union v_temp;
  end loop;

  -- doesn't work as the elements are records and and there is no way build-in
  -- way to compare record
  --v_dummys := set(v_dummys);

  for i in 1 .. v_dummys.last
  loop
    dbms_output.put_line(v_dummys(i).dummy);
  end loop;
end;
/

quit

-- ================================================================== --
-- DESC: how to use case to set variable value

declare
  v_input varchar2(1) := 'N';
  v_output varchar2(1);
begin
  v_output :=
    case
      when v_input = 'Y' then 'Y'
      else null
    end;
  dbms_output.put_line('v_output = ' || v_output);
end;
/

quit

-- ================================================================== --
-- DESC: how to pass an empty associative array as default parameter

declare
  type strlist_t is table of varchar2(32767);
  type strmap_t is table of varchar2(32767) index by varchar2(32767);

  v_list strlist_t;
  v_map strmap_t;
  v_empty_map strmap_t;

  -- null and strlist() are both ok here
  procedure print_list(p_container in strlist_t default strlist_t()) is
  begin
    if p_container is not null
    and p_container.count > 0
    then
      dbms_output.put_line('list has elems');
    else
      dbms_output.put_line('list has no elems');
    end if;
  end;

  -- we require an empty instance
  procedure print_map(p_container in strmap_t default v_empty_map) is
  begin
    if p_container.count > 0
    then
      dbms_output.put_line('map has elems');
    else
      dbms_output.put_line('map has no elems');
    end if;
  end;
begin
  print_list;
  print_list(v_list);
  v_list := strlist_t('foo');
  print_list(v_list);

  v_map('foo') := 'foo';
  print_map;
  print_map(v_map);
end;
/

quit

-- ================================================================== --
-- DESC: interval can be used in default value

declare
  procedure foo (p_date in date default sysdate - interval '12' month) is
  begin
    dbms_output.put_line(p_date);
  end;
begin
  foo();
  foo(sysdate);
end;
/

quit

-- ================================================================== --
-- DESC: number precision limit hit

declare
  v_num number(38);
begin
  -- fits into the precision of number
  v_num := to_number('A', rpad('X', 63, 'X'));
  dbms_output.put_line(v_num);
  -- don't fit anymore
  v_num := to_number('A', rpad('X', 64, 'X'));
  dbms_output.put_line(v_num);
end;
/

quit

-- ================================================================== --

-- DESC: Caller can't ignore OUT-parameters (it's the same than function
-- return value).

declare
  v_out number;
  procedure foo (p_in in number default 1, p_out out number) is
  begin
    p_out := 2;
  end;
begin
  -- PLS-00306: wrong number or types of arguments in call to 'FOO'
  -- foo(p_in => 1);
  -- these are valid calls
  foo(p_in => 1, p_out => v_out);
  foo(p_out => v_out);
end;
/

quit

-- ================================================================== --
-- DESC: How is number interpreted in boolean context.

declare
  function f(p_num in number) return number as
  begin
    return p_num;
  end;
begin
  if f(0) then -- PLS-00382: expression is of wrong type
    dbms_output.put_line('0');
  end if;

  if f(1) then -- PLS-00382: expression is of wrong type
    dbms_output.put_line('1');
  end if;

end;
/

quit

-- ================================================================== --
-- DESC: how procedure parameter mode affects parameter value when exception
-- is raised

declare
  v_str varchar2(100) := 'default set in main';
  procedure proc1(p_str out varchar2) is
  begin
    p_str := 'default set in proc1()';
    select dummy into p_str from dual where dummy = '1';
  exception
    when no_data_found then null;
  end;
begin
  -- v_str will be the default set in proc1()
  proc1(v_str);
  dbms_output.put_line('v_str = ' || v_str);
end;
/

quit

-- ================================================================== --
-- DESC: how procedure parameter mode affects parameter value when exception
-- is raised

declare
  v_str varchar2(20) := 'FOO';
  procedure proc1(p_str out varchar2) is
  begin
    select dummy into p_str from dual where dummy = '1';
  exception
    when no_data_found then null;
  end;
begin
  -- v_str will be null because p_str is out
  -- v_str would be 'FOO' if p_str is in out
  proc1(v_str);
  dbms_output.put_line('v_str = ' || v_str);
end;
/

quit

-- ================================================================== --
-- DESC: case insensitive string comparison with like

declare
  v_str varchar2(20) := 'Foo and Bar';
  v_true constant boolean := true;
  v_false constant boolean := false;
begin
  if upper(v_str) like 'FOO AND%' then
    dbms_output.put_line('true:' || v_str);
  end if;

  --if v_true then
  if not v_false then
    dbms_output.put_line('true');
  end if;
end;
/

quit

-- ================================================================== --
-- DESC: is a string 'Y' or not ?

declare
  function to_str(p_val in boolean) return varchar2 is
  begin
    if p_val then
      return 'true';
    else
      return 'false';
    end if;
  end;
  function is_internal(p_flag in varchar2) return boolean is
  begin
    return p_flag = 'Y';
  end;
begin
  dbms_output.put_line('Y      = ' || to_str(is_internal('Y')));
  dbms_output.put_line('Yes    = ' || to_str(is_internal('Yes')));
  dbms_output.put_line('N      = ' || to_str(is_internal('N')));
  dbms_output.put_line('null   = ' || to_str(is_internal(null)));
  dbms_output.put_line('123    = ' || to_str(is_internal(123)));
  dbms_output.put_line('foobar = ' || to_str(is_internal('foobar')));
end;
/

quit

-- ================================================================== --
-- DESC: Comparing strings with >

begin
  if 'B2' > 'A2R5' then
    dbms_output.put_line('B2 > A2R5');
  end if;
end;
/

quit

-- ================================================================== --
-- DESC: return a value or if null then a default value

declare
  function get_val_or_def(
    p_str in varchar2,
    p_default in varchar2 default rpad('-', 10, '-')
  ) return varchar2 is
  begin
    return
      case 
        when p_str is null then p_default
        else p_str
      end;
  end;
begin
  dbms_output.put_line(get_val_or_def(p_str => null));
  dbms_output.put_line(get_val_or_def(p_str => null,
                                      p_default => rpad('X', 3, 'X')));
  dbms_output.put_line(get_val_or_def(p_str => 'A happy non-null string !',
                                      p_default => rpad('X', 3, 'X')));
  dbms_output.put_line(get_val_or_def(p_str => 'A second happy non-null string !'));
end;
/

quit

-- ================================================================== --
-- DESC: catch an exception when string doesn't fit into varchar2

declare
  foo varchar2(3);
  too_long_value_ex exception;
  pragma exception_init(too_long_value_ex, -6502);
begin
  foo := '123';
  foo := foo || '4';
exception
  when too_long_value_ex then
    dbms_output.put_line('exception: too_long_value_ex');
    dbms_output.put_line('foo = ' || foo);
end;
/

quit

-- ================================================================== --
-- DESC: empty list

declare
  type list_t is table of varchar2(10);
  -- foos list_t := list_t('a', 'b');
  foos list_t := list_t();
begin
  dbms_output.put_line('count = ' || foos.count);

  --if foos.count = 0 then
  if not foos.exists(1) then
    return;
  end if;

  -- throws ORA-06502: PL/SQL: numeric or value error
  for i in foos.first .. foos.last loop
    dbms_output.put_line('bing!');
  end loop;
end;
/

quit

-- ================================================================== --
-- DESC: a function returning boolean can be used as such in if statement

declare
  function foo return boolean as
  begin
    return true;
  end;
  function foo2 return integer as
  begin
    return 0;
  end;
begin
  if foo then
    dbms_output.put_line('foo was true');
  else
    dbms_output.put_line('foo was false');
  end if;

  -- expression is of wrong type
  if foo2 then
    dbms_output.put_line('foo2 was true');
  else
    dbms_output.put_line('foo2 was false');
  end if;
end;
/

quit

-- ================================================================== --
-- DESC: Pipelined PL/SQL function's return value have to be SQL collection
-- type.

create or replace type str_list_t is table of varchar2(50);
/

create or replace function foo return str_list_t pipelined as
begin
  pipe row('first');
  pipe row('second');
  pipe row('third');
end;
/
show errors

select * from table(foo) order by column_value desc;

drop function foo;
drop type str_list_t;

quit

-- ================================================================== --
-- DESC: rsubstr

declare
  function rsubstr(p_str varchar2, p_len number) return varchar2 as
    v_len constant number := abs(p_len);
  begin
    if length(p_str) <= v_len then
      return p_str;
    end if;
    
    return substr(p_str, -1 * v_len);
  end;
begin
  dbms_output.put_line('null: ' || rsubstr('', 5));
  dbms_output.put_line('-5: ' || rsubstr('1234567890', -5));
  dbms_output.put_line('05: ' || rsubstr('1234567890', 5));
  dbms_output.put_line('09: ' || rsubstr('1234567890', 9));
  dbms_output.put_line('10: ' || rsubstr('1234567890', 10));
  dbms_output.put_line('11: ' || rsubstr('1234567890', 11));
end;
/

quit

-- ================================================================== --
-- DESC: a pair (or a tuple of two)

declare
  type num_pair_t is record(
    r1 number,
    r2 number
  );

  v_duo num_pair_t;

  function tostr(p_pair num_pair_t) return varchar2 as
  begin
    return '((r1 = ' || nvl(to_char(p_pair.r1), 'null') ||
           ')(r2 = ' || nvl(to_char(p_pair.r2), 'null') ||
           '))';
  end;

begin
  dbms_output.put_line('v_duo = ' || tostr(v_duo));
  v_duo.r1 := 111;
  dbms_output.put_line('v_duo = ' || tostr(v_duo));
  v_duo.r2 := 222;
  dbms_output.put_line('v_duo = ' || tostr(v_duo));
  v_duo.r1 := null;
  dbms_output.put_line('v_duo = ' || tostr(v_duo));
end;
/

quit

-- ================================================================== --
-- DESC: How to set decimal separator character

-- p_new_value consists of exactly two characters:
-- 1: decimal_character
-- 2: group_separator
-- usually we are interested only on decimal_character
create or replace function set_session_numeric_characters(
  p_new_value in nls_session_parameters.value%type
) return nls_session_parameters.value%type as
  v_old_value nls_session_parameters.value%type;
begin
  select value into v_old_value from nls_session_parameters where parameter = 'NLS_NUMERIC_CHARACTERS';

  execute immediate 'alter session set nls_numeric_characters = ''' || p_new_value || '''';
  return v_old_value;
end;
/
show errors

create or replace procedure f1 as
  v_num number;
  v_orig varchar2(100) := set_session_numeric_characters('x ');
begin
  dbms_output.put_line('f1: v_orig = ' || v_orig);

  select 0.111 into v_num from dual;

  dbms_output.put_line('f1:  v_num = ' || v_num);

  v_orig := set_session_numeric_characters(v_orig);

  dbms_output.put_line('f1: v_orig = ' || v_orig);
end;
/
show errors

create or replace procedure f2 as
  v_num number;
begin
  select 0.222 into v_num from dual;

  dbms_output.put_line('f2:  v_num = ' || v_num);
end;
/
show errors

declare
begin
  f1;
  f2;
end;
/

drop procedure f2;
drop procedure f1;
drop function set_session_numeric_characters;

quit

-- ================================================================== --
-- DESC: Default value is used only when parameter is missing. Passing null is
-- a valid value and default value is not used.

declare
  procedure foo(p_par in varchar2 default 'DEF') as
  begin
    dbms_output.put_line('p_par: ' || p_par);
  end;
begin
  foo;
  foo(null);
  foo('caller specific value');
end;
/

quit

-- ================================================================== --
-- DESC: local procedure/function

declare
  procedure say_hello_to(p_who in varchar2) as
  begin
    if p_who is not null then
      dbms_output.put_line('Hello ' || p_who || ' !');
    end if;
  end;
begin
  say_hello_to('World');
  say_hello_to(null);
  say_hello_to('Jani');
end;
/

quit

-- ================================================================== --
-- DESC: A difference between rounding and truncating

create table foo(n number);

insert all
into foo values (1.111)
into foo values (5.555)
into foo values (9.999)
select * from dual;

select n, round(n,2), trunc(n, 2) from foo;

drop table foo;

quit

-- ================================================================== --
-- DESC: Implicit default values are NULL.

declare
  a number;
  b pls_integer;
  c varchar2(10);
begin
  dbms_output.put_line('a = ''' || a || '''');
  if a is null then
    dbms_output.put_line('a is null');
  end if;
  
  dbms_output.put_line('b = ''' || b || '''');
  if b is null then
    dbms_output.put_line('b is null');
  end if;
  
  dbms_output.put_line('c = ''' || c || '''');
  if c is null then
    dbms_output.put_line('c is null');
  end if;
  
end;
/

quit

-- ================================================================== --
-- DESC: putil.join (of PL/SQL Commons) example

declare
begin
  dbms_output.put_line(putil.join(stringlist('a', 'b', 'c'), ', '));
end;
/

quit

-- ================================================================== --
-- DESC: How to test if a value is included in a list or not.

create or replace package trial as
  type strlist_t is table of varchar2(32676);
  procedure is_in(expected in strlist_t, got in varchar2);
end;
/
show errors

create or replace package body trial as
  procedure is_in(expected in strlist_t, got in varchar2) as
  begin
    for i in expected.first .. expected.last loop
      if got = expected(i) then
        dbms_output.put_line(got || ' is in');
        return;
      end if;
    end loop;
    dbms_output.put_line(got || ' is not in');
  end;
end;
/
show errors

declare
begin
  trial.is_in(trial.strlist_t('foo', 'bar'), 'foo');
  trial.is_in(trial.strlist_t('foo', 'bar'), 'zoo');
end;
/

drop package trial;

quit

-- ================================================================== --
-- DESC: How to process multiple values in a single when branch

declare
begin
  for i in 1 .. 5 loop
    case
      when i = 1 then
        dbms_output.put('matched ');
        dbms_output.put_line('one');
      when i = 2 then
        dbms_output.put('matched ');
        dbms_output.put_line('two');
      when i in (3, 4) then
        dbms_output.put('matched ');
        dbms_output.put_line('three or four');
      else
        dbms_output.put('matched ');
        dbms_output.put_line('unknown');
    end case;
  end loop;
end;
/

quit

-- ================================================================== --
-- DESC: Variables (declare block) are available in exception block) 

declare
  foo number := 42;
begin
  raise program_error;
exception
  when others then
    dbms_output.put_line('in exception handler: foo = ' || foo);
end;
/

quit

-- ================================================================== --
-- DESC: How to set default values for a record.

declare
  type foo_t is record (
    foo varchar2(20) not null := 'this is foo',
    bar varchar2(20) not null := 'this is bar'
  );
  foo_v foo_t;
begin
  dbms_output.put_line(foo_v.foo);
  foo_v.foo := 'altered foo';
  dbms_output.put_line(foo_v.foo);
end;
/

quit

-- ================================================================== --
-- DESC: else-branch is required or error:
-- ORA-06592: CASE not found while executing CASE statement
-- (CASE_NOT_FOUND predefined exception) is raised

declare
begin
   case
      when sql%rowcount = 0 then
        dbms_output.put_line('sql%rowcount = ' || sql%rowcount);
      when sql%rowcount > 1 then
        dbms_output.put_line('sql%rowcount = ' || sql%rowcount);
      else null;
    end case;
end;
/

quit

-- ================================================================== --
-- DESC: Null values in comparison (http://stackoverflow.com/q/7862014)

create or replace procedure foo1(a in pls_integer, b in pls_integer) as
begin
  dbms_output.put('foo1('||a||','||b||') = ');
  if a > b then
    dbms_output.put_line('no-op');
  else
    dbms_output.put_line('op');
  end if;
end;
/
show errors

create or replace procedure foo2(a in pls_integer, b in pls_integer) as
begin
  dbms_output.put('foo2('||a||','||b||') = ');
  if a <= b then
    dbms_output.put_line('op');
  else
    dbms_output.put_line('no-op');
  end if;
end;
/
show errors

declare
begin
  foo1(1, 1);
  foo1(1, 2);
  foo1(2, 1);
  foo1(null, null);
  foo1(null, 1);
  foo1(1, null);

  dbms_output.put_line('---');

  foo2(1, 1);
  foo2(1, 2);
  foo2(2, 1);
  foo2(null, null);
  foo2(null, 1);
  foo2(1, null);
end;
/

drop procedure foo2;
drop procedure foo1;

-- ================================================================== --

quit

-- DESC: with-clause multiple aliases

with
x1 as (select 1 one from dual),
x2 as (select 2 two from dual)
select * from x1, x2;

quit

-- ================================================================== --
-- DESC: Multi row insert (see also: http://stackoverflow.com/q/39576, http://stackoverflow.com/q/883706)

create table foo (id number);

insert all
into foo values(1)
into foo values(2)
into foo values(10)
select 1 from dual;

select * from foo;
drop table foo;

quit

-- DESC: An answer to SO question: http://stackoverflow.com/q/7712854

    with strings as (
      select 'MAXO_INSTR_INTERFACE' as string from dual
      union all
      select 'MAXIS_VENDOR_INTERFACE' from dual
      union all
      select 'MAXIMOS_EMPS_INTERFACE2' from dual
    )
    select substr(string,
                  instr(string, '_', 1, 1) + 1,
                  instr(string, '_', 1, 2) - instr(string, '_', 1, 1) - 1
                  ) as substr from strings;
    
    create or replace function f (p_str in varchar2) return varchar2 as
      v_begin constant pls_integer := instr(p_str, '_', 1, 1) + 1;
      v_len constant pls_integer := instr(p_str, '_', 1, 2) - v_begin;
    begin
      return substr(p_str, v_begin, v_len);
    end;
    /
    show errors
        
    begin
      dbms_output.put_line('f() = ' || f('MAXO_INSTR_INTERFACE'));
      dbms_output.put_line('f() = ' || f('MAXIS_VENDOR_INTERFACE'));
      dbms_output.put_line('f() = ' || f('MAXIMOS_EMPS_INTERFACE2'));
    end;
    /

    create or replace function f2 (p_str in varchar2) return varchar2 as
    begin
      return regexp_substr(p_str, '[^_]+', 1, 2);
    end;
    /
    show errors

    begin
      dbms_output.put_line('f2() = ' || f2('MAXO_INSTR_INTERFACE'));
      dbms_output.put_line('f2() = ' || f2('MAXIS_VENDOR_INTERFACE'));
      dbms_output.put_line('f2() = ' || f2('MAXIMOS_EMPS_INTERFACE2'));
    end;
    /

drop function f2;
drop function f;

quit

-- ================================================================== --

-- DESC: How to use different columns in where-clause based on a condition ? http://stackoverflow.com/q/7659481

create table foo (f1 number unique, f2 number);
insert into foo values(1, 100);
insert into foo values(2, 200);

variable inputparameter char
variable somevalue number

exec :inputparameter := 'X'
exec :somevalue := 200
     
select * from foo
where 1 = case
            when :inputparameter = 'X' and f1 = :somevalue then 1
            when :inputparameter = 'Y' and f2 = :somevalue then 1 
            --else 0
          end;

select * from foo
where (:inputparameter = 'X' and f1 = :somevalue)
   or (:inputparameter = 'Y' and f2 = :somevalue);

drop table foo;

quit

-- ================================================================== --

-- DESC: how to flatten xml structure with xmltable

column item format a20
column moreitem format a20

with xmldata as (select xmltype('<root>
  <foo id="1">
    <items>
     <item>id 1 item 1</item>
     <item>id 1 item 2</item>
     <item>id 1 item 3</item>
    </items>
    <moreitems>
     <item>id 1 more item 1</item>
     <item>id 1 more item 2</item>
     <item>id 1 more item 3</item>
    </moreitems>
  </foo>
  <foo id="2">
    <items>
     <item>id 2 item 1</item>
     <item>id 2 item 2</item>
    </items>
    <moreitems>
     <item>id 2 more item 1</item>
     <item>id 2 more item 2</item>
    </moreitems>
  </foo>
</root>') object_value from dual)
select rownum, x1.foo_id, x2.item/*, x3.moreitem*/
from xmldata,
     xmltable(
     '$doc/root/foo' passing xmldata.object_value as "doc"
     columns
     foo_id number path '@id',
     items xmltype path 'items/item',
     moreitems xmltype path 'moreitems/item'
     ) x1,
     xmltable(
     '/item' passing x1.items
     columns
     item varchar2(20) path 'text()'
     ) x2/*,
     xmltable(
     '/item' passing x1.moreitems
     columns
     moreitem varchar2(20) path 'text()'
     ) x3*/;

quit

-- ================================================================== --

-- DESC: function and procedure can share a same name in a package

create or replace package foo as
  function foo return number;
  procedure foo;
end;
/
show errors

create or replace package body foo as
  function foo return number as begin dbms_output.put_line('a function'); return 5; end;
  procedure foo as begin dbms_output.put_line('a procedure'); end;
end;
/
show errors

declare
  v_foo number;
begin
  v_foo := foo.foo; -- a function
  foo.foo; -- a procedure
end;
/

drop package foo;

quit

-- ================================================================== --

-- DESC: Wrong use of to_clob with XMLType.

create table ex_table (
  id number,
  data clob
);

insert into ex_table (id) values (1);
insert into ex_table (id) values (2);
insert into ex_table (id) values (3);
insert into ex_table (id) values (4);
insert into ex_table (id) values (5);

declare
  v_xml xmltype := xmltype('<root><foo>This is a foo !</foo></root>');
  v_clob constant clob := 'Content of the element foo. ';
  v_errtext clob;
begin
  -- no problems here: stringified v_xml is 39 chars
  update ex_table set data = to_clob(v_xml) where id = 1;
  commit;

  -- In next examples
  -- root-element is 13 chars
  -- a single foo-element is 26 chars

  -- no problems here: stringified v_xml is 13 + 153 * 26 = 3991 chars
  select xmlelement("root", xmlagg(xmlelement("foo", 'This is a foo !')))
    into v_xml from dual connect by level <= 153;

  update ex_table set data = to_clob(v_xml) where id = 2;
  commit;

  -- throws because stringified v_xml is 13 + 154 * 26 = 4017 chars
  -- that exceeds SQL varchar2 limit of 4000 chars
  begin
    select xmlelement("root", xmlagg(xmlelement("foo", 'This is a foo !')))
      into v_xml from dual connect by level <= 154;

    update ex_table set data = to_clob(v_xml) where id = 3;
    commit;
  exception
    when others then
      v_errtext := to_clob(sqlerrm);
      update ex_table set data = v_errtext where id = 3;
      commit;
  end;

  -- instead of to_clob() use xmltype.getclobval
  select xmlelement("root", xmlagg(xmlelement("foo", 'This is a foo !')))
    into v_xml from dual connect by level <= 10000;

  update ex_table set data = v_xml.getclobval where id = 4;
  commit;

  -- rpad clobs
  select xmlelement("root", xmlagg(xmlelement("foo",
					      rpad(v_clob, 100, v_clob))))
    into v_xml from dual connect by level <= 10;

  update ex_table set data = v_xml.getclobval where id = 5;
  commit;
end;
/

column id format 999
column data format a70
select * from ex_table;

drop table ex_table;

quit

-- ================================================================== --

-- DESC: no not null in function parameters (compilation error)

create or replace function foo(a in varchar2 not null) return varchar2 as
begin
  return a;
end;
/
show errors

begin
  dbms_output.put_line(foo('foo'));
end;
/

drop function foo;

quit

-- ================================================================== --

-- DESC: Using case/decode to select XML element name in xmlforest()

declare
  v_num number := 6;
  v_str varchar2(1) := 'B';
  v_elem xmltype;
begin
  select xmlelement("foo",
		    xmlforest(v_num as evalname(case
						when v_num < 5 then 'small'
						else 'big'
						end),
			      v_str as evalname(decode(v_str,
						       'A', 'aelem',
						       'B', 'belem'))
			      )
		    )
    into v_elem from dual;

  dbms_output.put_line(v_elem.getstringval);
end;
/

quit

-- ================================================================== --

-- DESC: Are two strings equal or not ? http://stackoverflow.com/questions/7286047/oracle-pl-sql-string-compare-problem/7299074#7299074

    create or replace function is_equal(a in varchar2, b in varchar2)
    return pls_integer as
    begin
      if a is null and b is null then
        return 1;
      end if;
    
      if a = b then
        return 1;
      end if;
    
      return 0;
    end;
    /
    show errors
    
    begin
      /* Prints 0 */
      dbms_output.put_line(is_equal('AAA', 'BBB'));
      dbms_output.put_line(is_equal('AAA', null));
      dbms_output.put_line(is_equal(null, 'BBB'));
      dbms_output.put_line(is_equal('AAA', ''));
      dbms_output.put_line(is_equal('', 'BBB'));
    
      /* Prints 1 */
      dbms_output.put_line(is_equal(null, null));
      dbms_output.put_line(is_equal(null, ''));
      dbms_output.put_line(is_equal('', ''));
      dbms_output.put_line(is_equal('AAA', 'AAA'));
    end;
    /
    
    quit

-- ================================================================== --

-- DESC: function with out parameter

create or replace function foo(a in number, b in out number) return number as
begin
  b := b + a;
  return a + 1;
end;
/
show errors

declare
  a number := 3;
  b number := 7;
  c number;
begin
  c := foo(a, b);
  dbms_output.put_line('a = ' || a || ' b = ' || b || ' c = ' || c);
end;
/

drop function foo;

quit

-- ================================================================== --

-- DESC: SQL case statement

create table foo (
  id number,
  debit number,
  credit number,
  value number
);

insert into foo values (1, -1, 0, 10);
insert into foo values (2, 0, 1, 10);

select * from foo;

select
id,
case 
 when debit <> 0 then value
 else null
end as "DEBIT VALUE",
case
  when credit <> 0 then value
  else null
end as "CREDIT VALUE"
from foo;

drop table foo;

quit

-- ================================================================== --

-- DESC: How to replace (delete) a non-printable character with a regexp.

/* PL/SQL */

declare
  in_str constant varchar2(30) := 'foo' || chr(13) || 'bar' || chr(13);
  out_str varchar2(30);
begin
  dbms_output.put_line('in_str = ' || utl_raw.cast_to_raw(in_str));

  select regexp_replace(in_str, chr(13) || '$', '') into out_str from dual;

  dbms_output.put_line('out_str = ' || utl_raw.cast_to_raw(out_str));
end;
/

/* SQL */

-- in emacs  is C-q C-m
select regexp_replace('foobar', '$', '') from dual;

select utl_raw.cast_to_raw('foo' || chr(13) || 'bar' || chr(13)) as BEFORE from dual;

select utl_raw.cast_to_raw(regexp_replace('foo' || chr(13) || 'bar' || chr(13), chr(13) || '$', '')) AS AFTER from dual;

quit

-- ================================================================== --

-- DESC: xmltype constructor and namespaces

declare
  d xmltype;
begin
  --d := xmltype('<A:ratkaisu>r1</A:ratkaisu>');
  d := xmltype('<ratkaisu xmlns="jotain">r1</ratkaisu>');
  d := xmltype('<a:ratkaisu xmlns:a="jotain">r1</a:ratkaisu>');
end;
/

quit

-- ================================================================== --

-- DESC: NULLs are always passed

create or replace procedure foo(a in number, b in varchar2) as
begin
  dbms_output.put_line('procedure foo');
end;
/
show errors

begin
  foo(1, 'foo');
  foo(1, null);
  foo(null, 'foo');
  foo(null, null);
end;
/

drop procedure foo;

quit

-- ================================================================== --

-- DESC: select insert NULL value

create table foo (
  id number,
  text varchar2(20)
);

create table bar (
  id number,
  text varchar2(20)
);

insert into foo values (1, 'foo 1');
insert into foo values (2, 'foo 2');
insert into foo values (3, 'foo 3');

begin
  insert into bar values(10, (select text from foo where id = 1));
  insert into bar values(10, (select text from foo where id = 4));
end;
/

select * from bar;

drop table bar;
drop table foo;

quit

-- ================================================================== --

-- DESC: How to read value from XML: http://stackoverflow.com/questions/6677123/search-xml-for-value-in-oracle

set long 500

create table ccgw_msg_xmldata (
  msg_id number,
  msg_data xmltype
);

insert into ccgw_msg_xmldata values (1, xmltype('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns1:charge-request xmlns:ns1="api">
    <ns1:transaction-id>2315176</ns1:transaction-id>
    <ns1:aoc-done>1</ns1:aoc-done>
</ns1:charge-request>'));

insert into ccgw_msg_xmldata values (2, xmltype('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns1:charge-request xmlns:ns1="api">
    <ns1:transaction-id>2315177</ns1:transaction-id>
    <ns1:aoc-done>1</ns1:aoc-done>
</ns1:charge-request>'));

SELECT x.msg_data
FROM   ccgw_msg_xmldata x
WHERE  EXTRACTVALUE(x.msg_data, '/ns1:charge-request/ns1:aoc-done', 'xmlns:ns1="api"') = 1
AND    x.msg_id < 3;

    SELECT x.msg_data
    FROM   ccgw_msg_xmldata x,
           xmltable(xmlnamespaces(default 'api'),
           '/charge-request'
           passing x.msg_data
           columns
           aocdone number path 'aoc-done') x2
    WHERE  x2.aocdone = 1
    AND    x.msg_id < 3;
    
    SELECT
      xmlquery('declare default element namespace "api"; (: :)
                for $aocdone in $doc/charge-request/aoc-done
                    where $aocdone = 1
                    return $doc'
                   passing x.msg_data as "doc"
                   returning content) as msg_data
    FROM ccgw_msg_xmldata x
    WHERE x.msg_id < 3;

drop table ccgw_msg_xmldata;

quit

-- ================================================================== --

column f format 999
select 123 as f from dual;
quit

-- ================================================================== --

select xmltype('<root>The root.</root>').extract('/root/text()') from dual;

quit

-- ================================================================== --

create or replace function foo(p in number) return number as
  no_return exception;
  pragma exception_init(no_return, -6503);
begin
  if p < 5 then
    return abs(p) * 10;
  end if;
  -- when p >= 5 raises:
  -- ORA-06503: PL/SQL: Function returned without value
exception
  -- not captured here
  when no_return then
    dbms_output.put_line('foo: function returned without value');
    raise;
end;
/

declare
  no_return exception;
  pragma exception_init(no_return, -6503);
  p number;
begin
  p := foo(3);
  dbms_output.put_line('foo(3) = ' || p);
  p := foo(6);
  dbms_output.put_line('foo(6) = ' || p);
exception
  when no_return then
    dbms_output.put_line('function returned without value');
end;
/

drop function foo;

quit

-- ================================================================== --

declare
  i number := 0;
begin
  execute immediate 'create sequence sq_foo';
  execute immediate 'select sq_foo.nextval from dual' into i;
  dbms_output.put_line('i = ' || i);
end;
/

quit

-- ================================================================== --

/* How to create a mock sequence ? */

/* I was planning to have some mock sequences created dynamically in my unit test driver to be able to reproduce some unit tests reliably. Unfortunately I have found out it was not that easy: */

drop sequence sq_foo;

declare
  i number := 0;
begin
  execute immediate 'create sequence sq_foo;';

  /* Sequence is not available at this point at compile time because the
  sequence is created during execution. Thus the statement:

  i := sq_foo.nextval;

  Fails with:
  PLS-00201: identifier 'SQ_FOO.NEXTVAL' must be declared */
end;
/

declare
  i number := 0;
begin

  /* At this point the sequence exists (it was created during the execution of
  previous anonymous PL/SQL block, that takes place before the compilation of
  this block) and can be used. */

  i := sq_foo.nextval;
  dbms_output.put_line('i = ' || i);
  execute immediate 'drop sequence sq_foo';
end;
/

drop sequence sq_foo;

/* So creating the execute immediate */

declare
  i number := 0;
begin
  execute immediate 'create sequence sq_foo';
  execute immediate 'select sq_foo.nextval from dual' into i;
  dbms_output.put_line('i = ' || i);
end;
/

drop sequence sq_foo;

quit

-- ================================================================== --

create sequence exseq;

create or replace function numgen return number as
  i constant number := exseq.nextval;
begin
  return i;
end;
/
show errors

create or replace function numgen2(seq in varchar2) return number as
  g constant varchar2(100) := 'select ' || seq || '.nextval from dual';
  i number := 0;
begin
  execute immediate g into i;
  return i;
end;
/
show errors

create or replace function numgen3(seq in sequence) return number as
begin
  return seq.nextval;
end;
/
show errors
/*
Warning: Function created with compilation errors.

Errors for FUNCTION NUMGEN3:

LINE/COL ERROR
-------- -----------------------------------------------------------------
0/0      PL/SQL: Compilation unit analysis terminated
1/25     PLS-00201: identifier 'SEQUENCE' must be declared
*/

declare
begin
  for i in 1 .. 3 loop
    dbms_output.put_line('.numgen: ' || numgen);
    dbms_output.put_line('numgen2: ' || numgen2('exseq'));
  end loop;
end;
/

drop function numgen3;
drop function numgen2;
drop function numgen;
drop sequence exseq;

quit

declare
  foo number := 0;
  bar number := null;
begin
  if foo = 0 or foo is null then
    dbms_output.put_line('foo');
  end if;

  if bar = 0 or bar is null then
    dbms_output.put_line('bar');
  end if;
end;
/

quit

declare
  type filters_t is table of varchar2(32767);
  filter filters_t := filters_t();
begin
  dbms_output.put_line('count = ' || filter.count);
  if filter.exists(1) then
    dbms_output.put_line('first element exists');
  else
    dbms_output.put_line('no elements');
  end if;
  -- next line will throw
  for i in filter.first .. filter.last loop
    dbms_output.put_line('bing');
  end loop;
end;
/
    
quit

create table extable(
 excol1 number,
 excol2 number,
 excol3 number
);

insert into extable values(1, 10, 100);
insert into extable values(2, 20, 200);
insert into extable values(3, 30, 300);

create or replace procedure foo(id in number) as
  cursor extable_c is select excol2 from extable where excol1 = id;
  data_ extable_c%rowtype;
begin
  open extable_c;
  fetch extable_c into data_;

  if extable_c%found then
    dbms_output.put_line(id || ' -> ' || data_.excol2);
  else
    dbms_output.put_line(id || ': no such id');
  end if;

  close extable_c;
end;
/
show errors

begin
  foo(1);
  foo(2);
  foo(3);
  foo(4);
end;
/

drop procedure foo;
drop table extable;

quit

declare
  text constant varchar2(100) := 'mitasattuu: 1:3:5';
  -- 1. kaksoispisteen sijainti (indeksi) merkkijonossa text
  i constant pls_integer := instr(text, ':');
begin
  -- alusta indeksiin i asti
  dbms_output.put_line(substr(text, 1, i));
  -- alusta indeksiin i-1 asti
  dbms_output.put_line(substr(text, 1, i - 1));
  -- indeksistä i+1 loppuun asti
  dbms_output.put_line(substr(text, i + 1));
end;
/

quit

create or replace function get_bing return varchar2 as
begin
  raise NO_DATA_FOUND;
  return 'bing!';
end;
/
show errors

declare
  -- this exception is not caught by the exception handler as the function
  -- call is not in scope of exception handler
  bing constant varchar(100) := get_bing;
  bing2 varchar(100);
begin
  dbms_output.put_line('start');
  -- this exception will be caught if code ever reach this point
  bing2 := get_bing;
  dbms_output.put_line('end');
exception
  when NO_DATA_FOUND then
    dbms_output.put_line('caught exception: NO_DATA_FOUND: ' || sqlerrm);
end;
/
show errors
    
drop function get_bing;

quit

create table extable(
 excol number
);

insert into extable values(1);
insert into extable values(2);
insert into extable values(3);

declare
  n extable.excol%type;
  st constant varchar(300) := 'select excol from extable where excol = 1';
begin
  execute immediate st into n;
  dbms_output.put_line('n = ' || n);
  
  begin
    select excol into n from extable where excol = 4;
  exception
    when NO_DATA_FOUND then
      dbms_output.put_line('caught exception: NO_DATA_FOUND: ' || sqlerrm);
  end;

  begin
    select excol into n from extable where excol < 4;
  exception
    when TOO_MANY_ROWS then
      dbms_output.put_line('caught exception: TOO_MANY_ROWS: ' || sqlerrm);
  end;
end;
/

drop table extable;
                                                                    
quit

create or replace procedure f1(
  v1 in varchar2,
  v2 in boolean default false
) as
begin
  null;
end;
/
show errors

declare
begin
  f1('Hey Joe !', true);
end;
/

quit

create or replace procedure f2 as
  callstack constant varchar2(2000) := dbms_utility.format_call_stack;
begin
  dbms_output.put_line('call stack = ' || callstack);
end;
/
show errors

create or replace procedure f1 as begin f2; end;
/
show errors

declare
begin
  f1;
end;
/

drop procedure f1;
drop procedure f2;

quit

declare
  foo constant boolean := false;
  bar constant varchar2(20) :=
    case foo
      when null then 'foo is null'
      when true then 'foo is true'
      else 'foo is false'
    end;
begin
  dbms_output.put_line(bar);
end;
/
    
quit

create or replace function foofier(
  foo in boolean
) return varchar2 as
begin
  case
    when foo then return 'foo is true';
    else return 'foo is false';
  end case;
end;
/
show errors

declare
  foo boolean := true;
  bar varchar2(20);
begin
  bar := foofier(foo);
  dbms_output.put_line(bar);

  bar :=
    case foo
      when null then 'foo is null'
      when true then 'foo is true'
      else 'foo is false'
    end;

  dbms_output.put_line(bar);

  foo := false;

  bar :=
    case
      when foo is null then 'foo is null'
      when foo then 'foo is true'
      else 'foo is false'
    end;

  dbms_output.put_line(bar);
end;
/

drop function foofier;

quit
