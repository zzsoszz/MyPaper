/* Adapted from Oracle Docs:
http://download.oracle.com/docs/cd/E11882_01/appdev.112/e17126/triggers.htm#BCFFIBBA
*/

create sequence seq_contact start with 10 increment by 1 nocache nocycle;

create or replace type contact_t as object (
  id integer,
  first_name varchar2(20),
  last_name varchar2(20),
  updated date
);
/
show errors

create table contact of contact_t;

alter table contact add constraint pk_contact primary key (id);

-- columns can't be added later (alter table) to object tables
create table h_contact(version integer, status char, updated date, contact contact_t);

alter table h_contact add constraint pk_h_contact primary key (version);

create or replace trigger tr_contact
before insert or delete or update on contact
for each row
declare
  v_audit h_contact%rowtype;
begin
  v_audit.version := seq_contact.nextval;

  case
    when inserting then v_audit.status := 'I';
    when updating  then v_audit.status := 'U';
    when deleting  then v_audit.status := 'D';
  end case;

  v_audit.updated := sysdate;

  if not deleting then
    :new.updated := v_audit.updated;
    v_audit.contact := :new.object_value;
  else
    v_audit.contact := :old.object_value;
  end if;

  insert into h_contact (version, status, updated, contact) values (v_audit.version, v_audit.status, v_audit.updated, v_audit.contact);

end;
/
show errors

insert into contact (id, first_name, last_name) values
  (1, 'Nick', 'Pierpoint');

insert into contact (id, first_name, last_name) values
  (2, 'John', 'Coltrane');

insert into contact (id, first_name, last_name) values
  (3, 'Sonny', 'Rollins');

insert into contact (id, first_name, last_name) values
  (4, 'Kenny', 'Wheeler');

insert into contact (id, first_name, last_name) values
  (5, 'Jason', 'Button');

delete from contact where id = 2;
update contact set last_name = 'Daglish' where last_name = 'Wheeler';
delete from contact where last_name = 'Daglish';

column id format 99

select * from contact;
select * from h_contact;

drop trigger tr_contact;

drop table h_contact;
drop table contact;
drop type contact_t;
drop sequence seq_contact;

quit
