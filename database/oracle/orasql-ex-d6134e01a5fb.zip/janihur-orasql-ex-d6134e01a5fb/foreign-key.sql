drop sequence psnro;
drop sequence ppnro;

create sequence ppnro;
create sequence psnro;

drop table palvelupaketti;
drop table perintasuoritus;
drop table perintaprosessi;

create table perintaprosessi(
  nro number(5) not null primary key, -- unnamed constraint
  selite varchar2(50)
);

create table perintasuoritus(
  nro number(5) not null,
  selite varchar2(50),
  constraint pk_perintasuoritus primary key(nro) -- named constraint
);

create table palvelupaketti(
 nro number(5) not null primary key,
 ppnro number(5) references perintaprosessi(nro),
 psnro number(5) references perintasuoritus(nro),
 selite varchar2(50)
);

insert into perintaprosessi values(ppnro.nextval, 'Ystävällinen prosessi');
insert into perintasuoritus values(psnro.nextval, 'Avokätinen suoritus');
insert into palvelupaketti values(1, ppnro.currval, psnro.currval, 'Liian hyvä ollaakseen totta paketti.');

insert into perintasuoritus values(psnro.nextval, 'Pihi suoritus');
insert into palvelupaketti values(2, ppnro.currval, psnro.currval, 'Roope Ankka paketti.');

select * from palvelupaketti;
