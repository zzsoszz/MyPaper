create sequence sq_item;

create table item (
  id integer unique,
  name varchar2(20),
  value number(5,2) check (value > 0) not null,
  constraint pk_item primary key (id, name)
);

insert into item values (sq_item.nextval, 'Arduino Uno', 99.99);
insert into item values (sq_item.nextval, 'Arduino Duemilanove', 69.99);
insert into item values (sq_item.nextval, 'Arduino Nano', 49.99);
insert into item values (sq_item.nextval, 'Arduino Mega2560', 49.99);
insert into item values (sq_item.nextval, 'Arduino Pro', 199.99);

create sequence sq_address;

create table address (
  id integer unique,
  address varchar2(20),
  constraint pk_address primary key (id, address)
);

insert into address values(sq_address.nextval, 'Lempäälä');
insert into address values(sq_address.nextval, 'New York');
insert into address values(sq_address.nextval, 'Tampere');
insert into address values(sq_address.nextval, 'Seinäjoki');

create sequence sq_customer;

create table customer (
  id integer unique,
  name varchar2(10),
  billing_address integer references address(id),
  delivery_address integer references address(id),
  constraint pk_customer primary key (id, name)
);

insert into customer values(sq_customer.nextval, 'Antti', 1, 3);
insert into customer values(sq_customer.nextval, 'Mikko', 4, 4);
insert into customer values(sq_customer.nextval, 'Joe', 2, 2);

create or replace view customer_v (
  name, billing_address, delivery_address
) as
select C.name, B.address, D.address
from customer C
inner join address B on C.billing_address = B.id
inner join address D on C.delivery_address = D.id
order by C.id;

create sequence sq_order;

create table order_ (
  id integer not null,
  customer integer references customer(id),
  item integer references item(id),
  nbr integer check (nbr > 0),
  constraint pk_order primary key (id, customer, item)
);

insert into order_ values(sq_order.nextval, 1, 2, 2);
insert into order_ values(sq_order.nextval, 2, 2, 1);
insert into order_ values(sq_order.currval, 2, 3, 1);
insert into order_ values(sq_order.nextval, 3, 5, 1);

create or replace view order_v (
  id, customer, item, amount
) as
select O.id, C.name, I.name, O.nbr
from order_ O
inner join customer C on O.customer = C.id
inner join item I on O.item = I.id
order by O.id;

/*
select C.name as "Customer", I.name as "Item", O.nbr * I.value as "Total"
from customer C
inner join order_ O on C.id = O.customer
inner join item I on O.item = I.id;
*/
