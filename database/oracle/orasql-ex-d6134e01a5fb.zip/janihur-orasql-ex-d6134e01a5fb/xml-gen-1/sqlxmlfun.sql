set long 500

create or replace function get_customer_xml_2 return xmltype as
  v_result xmltype;
begin
  select xmlelement("Customers",
		    xmlagg(xmlelement("Customer",
				      xmlforest(name as "Name",
						billing_address as "BillingAddress",
						delivery_address as "DeliveryAddress")
				      )
			   )
		    )
      into v_result from customer_v;
  return v_result;
end;
/
show errors

create or replace function get_order_xml_2 return xmltype as
  v_result xmltype;
begin
  select
    xmlelement("Orders",
	       xmlagg(xmlelement("Order",
				 xmlattributes(id as "Id"),
				 xmlforest(customer as "Customer",
					   item as "Item",
					   amount as "Amount")
				 )
		      )
	       )
    into v_result from order_v;
  return v_result;
end;
/
show errors

select get_customer_xml_2 from dual;
select get_order_xml_2 from dual;
