set long 500;

create or replace function get_customer_xml_1 return xmltype as
  context dbms_xmlgen.ctxhandle;
  result xmltype;
begin
  context := dbms_xmlgen.newcontext('select * from customer_v');
  dbms_xmlgen.setrowsettag(context, 'Customers');
  dbms_xmlgen.setrowtag(context, 'Customer');
  
  result := dbms_xmlgen.getxmltype(context);
  dbms_xmlgen.closecontext(context);
  return result;
end;
/
show errors

select get_customer_xml_1 from dual;
