drop view order_v;
drop table order_;
drop sequence sq_order;

drop view customer_v;
drop table customer;
drop sequence sq_customer;

drop table address;
drop sequence sq_address;

drop table item;
drop sequence sq_item;

drop function get_customer_xml_1;
drop function get_customer_xml_2;
drop function get_order_xml_2;
