create table first (
  id number,
  status varchar2(1),
  time timestamp(3)
);

create table second (
  text varchar2(100),
  time timestamp(3)
);

create or replace trigger first_tr
after insert or update on first
for each row
begin
  insert into second(text, time) 
  values ('triggered for id: ' || :new.id ||
          ' status: ' || nvl(:old.status, '(null)') || ' -> ' || :new.status,
          systimestamp);
end;
/
show errors

/*
insert into first values(1, 'A', systimestamp);
update first set status = 'B' where id = 1;
update first set status = 'B' where id = 1;

select * from second;
*/
