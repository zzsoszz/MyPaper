/* How to use DBMS_UTILITY.FORMAT_ERROR_STACK and
   DBMS_UTILITY.FORMAT_ERROR_BACKTRACE to format exception stack. */

create or replace package myex as
  ex1 exception; 

  procedure raises1;
  procedure raises2;
  procedure raises3;

  procedure p1;
  procedure p2;
  procedure p3;
end;
/
show errors;

create or replace package body myex as

  procedure raises1 as
  begin
    raise ex1;
  end;

  procedure raises2 as
    ex exception; pragma exception_init (ex, -1476);
  begin
    raise ex;
  end;

  procedure raises3 as
  begin
    raise_application_error(-20001, 'Error message provided by a user.');
  end;

  procedure p1 as
  begin
    p2;
  end;

  procedure p2 as
  begin
    p3;
  end;

  procedure p3 as
  begin
    raises1;
  end;

end;
/
show errors

create or replace function error_stack(
  p_ex in varchar2 default null
) return varchar2 as
  v_stack varchar2(32676) := DBMS_UTILITY.FORMAT_ERROR_STACK;
begin
  if p_ex is not null then
    v_stack := v_stack || 'XXX-00000: MYEX: exception name: ' ||
      upper(p_ex) || chr(10);
  end if;
  v_stack := v_stack || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
  return v_stack;
end;
/
show errors

set lines 300

exec myex.p1

begin
  myex.p1;
exception
  when others then
    dbms_output.put_line('----');
    dbms_output.put_line('Exception handler');
    dbms_output.put_line('sqlcode = ');
    dbms_output.put_line(sqlcode);
    dbms_output.put_line('sqlerrm = ');
    dbms_output.put_line(sqlerrm);
    dbms_output.put_line('DBMS_UTILITY.FORMAT_ERROR_STACK = ');
    dbms_output.put_line(DBMS_UTILITY.FORMAT_ERROR_STACK);
    dbms_output.put_line('DBMS_UTILITY.FORMAT_ERROR_BACKTRACE = ');
    dbms_output.put_line(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    dbms_output.put_line('----');
end;
/

begin
  myex.p1;
exception
  when others then
    dbms_output.put_line('----');
    dbms_output.put_line('Exception handler');
    dbms_output.put_line(error_stack);
    dbms_output.put_line('----');
end;
/

begin
  myex.p1;
exception
  when myex.ex1 then
    dbms_output.put_line('----');
    dbms_output.put_line('Exception handler for myex.ex1');
    dbms_output.put_line(error_stack('myex.ex1'));
    dbms_output.put_line('----');
end;
/

begin
  myex.raises2;
exception
  when others then
    dbms_output.put_line('----');
    dbms_output.put_line('Exception handler');
    dbms_output.put_line(error_stack || '----');
end;
/

begin
  myex.raises3;
exception
  when others then
    dbms_output.put_line('----');
    dbms_output.put_line('Exception handler');
    dbms_output.put_line(error_stack || '----');
end;
/

drop function error_stack;
drop package myex;

quit
