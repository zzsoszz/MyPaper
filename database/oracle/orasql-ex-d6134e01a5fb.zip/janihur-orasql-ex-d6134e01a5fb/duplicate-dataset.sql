/* Duplicate rows in a table based on a configuration. */

-- configuration
create table dup_cfg (
  target varchar2(1) primary key
);

insert into dup_cfg values ('A');
insert into dup_cfg values ('B');
insert into dup_cfg values ('C');

-- initial data set
create table dup_src (
  id number not null, 
  target varchar2(5) not null,
  time_stamp timestamp default systimestamp,
  data varchar2(10),
  constraint dup_src_pk primary key (id, target)
);

insert into dup_src (id, target, data) values (1, 'ORIG', 'foobar1');
insert into dup_src (id, target, data) values (2, 'ORIG', 'foobar2');
insert into dup_src (id, target, data) values (3, 'ORIG', 'foobar3');
insert into dup_src (id, target, data) values (4, 'ORIG', 'foobar4');
insert into dup_src (id, target, data) values (5, 'ORIG', 'foobar5');

-- a useful cross join !
select src.id, cfg.target, src.data
  from dup_src src
 cross join dup_cfg cfg
 where src.target = 'ORIG'
;

prompt ==
prompt == 1. insert run
prompt ==

insert into dup_src (id, target, data) (
  select src.id, cfg.target, src.data
    from dup_src src
   cross join dup_cfg cfg
   where src.target = 'ORIG'
      -- and data is not yet copied (avoids constraint violation)
     and not exists (
       select 1 from dup_src
        where target in (select target from dup_cfg)
          and id = src.id
     )
);

prompt ==
prompt == 2. insert run
prompt ==

insert into dup_src (id, target, data) (
  select src.id, cfg.target, src.data
    from dup_src src
   cross join dup_cfg cfg
   where src.target = 'ORIG'
      -- and data is not yet copied (avoids constraint violation)
     and not exists (
       select 1 from dup_src
        where target in (select target from dup_cfg)
          and id = src.id
     )
);

col id for 990
col time_stamp for a27
select * from dup_src order by time_stamp, target, id;

drop table dup_src;
drop table dup_cfg;

quit
