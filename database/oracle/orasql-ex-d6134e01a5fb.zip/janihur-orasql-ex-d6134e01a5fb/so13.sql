/* Insert large amount of data efficiently with SQL

An answer to SO question: http://stackoverflow.com/q/7681771

Use [Oracle external tables](http://download.oracle.com/docs/cd/E11882_01/server.112/e16508/tablecls.htm#CNCPT1141).

See also e.g.

* [OraFaq about external tables](http://orafaq.com/node/848)
* [What Tom thinks about external tables](http://asktom.oracle.com/pls/apex/f?p=100:11:0::::P11_QUESTION_ID:6611962171229)
* [René Nyffenegger's notes about external tables](http://www.adp-gmbh.ch/ora/misc/ext_table.html)

A simple example that should get you started is:

*/

    SQL> select directory_path from all_directories where directory_name = 'JTEST';
    
    DIRECTORY_PATH
    --------------------------------------------------------------------------------
    c:\data\jtest
    
    SQL> !cat ~/.gvfs/jtest\ on\ 192.168.xxx.xxx/exttable-1.csv
    1,a
    3,bsdf
    4,sdkfj
    5,something
    129,else
    
    create table so13t (
      id number(4),
      data varchar2(20)
    )
    organization external (
      type oracle_loader
      default directory jtest /* jtest is an existing directory object */
      access parameters (
        records delimited by newline
        fields terminated by ','
        missing field values are null
      )
      location ('exttable-1.csv') /* the file located in jtest directory */
    )
    reject limit unlimited;
    
    Now you can use all the power of SQL to access the data:
    
    SQL> select * from so13t order by data;
    
            ID DATA
    ---------- ------------------------------------------------------------
             1 a
             3 bsdf
           129 else
             4 sdkfj
             5 something
