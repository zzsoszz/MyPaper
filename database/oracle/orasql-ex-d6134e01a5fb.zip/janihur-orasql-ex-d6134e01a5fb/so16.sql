/* How to rename an Oracle XMLTYPE node

An answer to SO question: http://stackoverflow.com/q/7798478

Another option is to use [XMLTRANSFORM](http://download.oracle.com/docs/cd/E11882_01/appdev.112/e23094/xdb08tra.htm) to rename a node. See also e.g. [Rename nodes with XSLT](http://stackoverflow.com/q/271218).

*/

    with
    xmldata as (select xmltype('<root>
      <fields>
        <a>foo</a>
        <b>bar</b>
      </fields>
    </root>') val from dual),
    stylesheet as (select '<?xml version="1.0"?>
    <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
      <!-- Identity transformation -->
      <xsl:template match="node()|@*">
        <xsl:copy>
          <xsl:apply-templates select="node()|@*"/>
        </xsl:copy>
      </xsl:template>
      <!-- Identity transformation overridden for element b -->
      <xsl:template match="b">
        <xsl:element name="c">
          <xsl:apply-templates select="node()|@*"/>
        </xsl:element>
      </xsl:template>
    </xsl:stylesheet>' val from dual)
    select xmltransform(x.val, s.val) from xmldata x, stylesheet s;
