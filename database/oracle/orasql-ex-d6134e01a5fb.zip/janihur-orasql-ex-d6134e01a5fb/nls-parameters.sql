set linesize 80
col "LEVEL" for a8
col parameter for a30
col value for a30

with nls_parameters as (
  SELECT 1 as depth, 'SESSION'  as "LEVEL", parameter, value FROM nls_session_parameters
  union all
  SELECT 2 as depth, 'INSTANCE' as "LEVEL", parameter, value FROM nls_instance_parameters
  union all
  SELECT 3 as depth, 'DATABASE' as "LEVEL", parameter, value FROM nls_database_parameters
)
select "LEVEL", parameter, '''' || value || '''' as value
  from nls_parameters
-- where parameter = 'NLS_NUMERIC_CHARACTERS'
 order by parameter, depth
;
