/* Code snippets from OTN: http://forums.oracle.com
*/

/* http://forums.oracle.com/forums/thread.jspa?threadID=1074185
*/

with my_sample_table as (
  select xmltype('
  <request>
    <identification>
      <requestid>12345</requestid>
      <periodunit>1</periodunit>
      <periodunit>2</periodunit>
      <periodunit>3</periodunit>
      <days>MONDAY</days>
    </identification>
  </request>') xmldoc
  from dual
)
select x.*
from my_sample_table t
   , xmltable(
      'let $e := $d/request/identification
       for $i in $e/periodunit
       return element r {
         $e/requestid
       , $e/days
       , $i
       }'
      passing t.xmldoc as "d"
      columns requestid  number       path 'requestid'
            , days       varchar2(30) path 'days'
            , periodunit number       path 'periodunit'
     ) x
;

 with my_sample_table as (
     select xmltype('<?xml version="1.0" encoding="UTF-8" ?>
 <request>
 <identification>
 <requestid>12345</requestid>
 <periodunit>DAY</periodunit>
 <days>MONDAY</days>
 </identification>
 <product>
 <productname>ABC PRODUCT</productname>
 <brand>
 <brandname>CELL</brandname>
 <ndccode>A58048</ndccode>
 <ndccode>A49210</ndccode>
 </brand>
 </product>
 <product>
 <productname>100 bottles</productname>
 </product>
 </request>') xmldoc
     from dual
   )
 select x.*, y.*
   from my_sample_table t
      , xmltable(
         'let $e := $d/request/identification
          for $i in $d/request/product
          return element r {
            $e/requestid
          , $e/days
          , $e/periodunit
          , $i/productname
          , $i/brand/brandname
          , $i/brand/ndccode
          }'
         passing t.xmldoc as "d"
         columns requestid  number       path 'requestid'
               , days       varchar2(30) path 'days'
               , periodunit varchar2(10) path 'periodunit'
               , prductname varchar2(20) path 'productname'
               , brandname  varchar2(20) path 'brandname'
               , ndccodexml xmltype      path 'ndccode'
        ) x,
        xmltable('/ndccode'
                 PASSING x.ndccodexml
                 COLUMNS
                 ndccode    VARCHAR2(10) PATH '.') (+) y;

/* http://forums.oracle.com/forums/thread.jspa?messageID=9696491
*/

with my_sample_table as (
  select xmltype('<days>
  <day>MONDAY</day>
  <day>TUESDAY</day>
  <day>WEDNESDAY</day>
  <day>TUESDAY</day>
  <day>FRIDAY</day>
  <day>SATURDAY</day>
  <day>SUNDAY</day>
</days>') xmldoc
  from dual
)
select x.*
from my_sample_table t
   , xmltable(
      '$d/days/day'
      passing t.xmldoc as "d"
      columns day varchar2(30) path 'if (string-length(.)>6) then lower-case(.) else (.)'
     ) x
;
