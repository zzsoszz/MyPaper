-- http://stackoverflow.com/questions/3760070/pl-sql-parser-to-identify-the-operation-on-table/3762381#3762381

begin
  for i in (select owner, object_type, object_name from dba_objects 
            where owner in ([list of application schemas]
               and object_type in ('TABLE', 'PACKAGE', 'PROCEDURE', 'FUNCTION', 'VIEW')
  loop
    execute immediate 'AUDIT ALL ON ' || i.owner || '.' || i.object_type || 
                      ' BY SESSION';
  end loop;
end;
/
