--
-- scheduler configuration via tailored config table
--

create table scheduler_config (
  Job_name varchar2(100) not null,
  repeat_interval varchar2(100) not null
);

insert into scheduler_config values('logger1', 'FREQ=SECONDLY; BYSECOND=30');
commit;

create or replace trigger scheduler_config_trg
after update of repeat_interval
on scheduler_config
for each row
declare
  pragma autonomous_transaction;
begin
  -- Note: throws an exception if no such job
  dbms_scheduler.set_attribute(name => :new.job_name,
                               attribute => 'repeat_interval',
                               value => :new.repeat_interval);
end;
/
show errors

--
-- a simple job we want to schedule
--

create table scheduler_log (
  job_name varchar2(100),
  time timestamp(3),
  text varchar2(4000)
);

begin
  dbms_scheduler.create_job(
    job_name   => 'logger1',
    job_type   => 'PLSQL_BLOCK',
    job_action => 'BEGIN insert into scheduler_log values(''logger1'', systimestamp, ''Executed!''); commit; END;',
    start_date => systimestamp,
    repeat_interval => 'FREQ=SECONDLY; BYSECOND=30',
    end_date   => null,
    enabled    => true,
    comments   => 'Testing configuration');
end;
/

--
-- check how much work has been done and when
--

col job_name for a10
col time for a25
col text for a20

select * from scheduler_log order by time;

--
-- I want more job for my money !
--

update scheduler_config
   set repeat_interval = 'FREQ=SECONDLY; INTERVAL=10'
 where job_name = 'logger1';
commit;

--
-- remove the job
--

exec dbms_scheduler.drop_job('logger1')
