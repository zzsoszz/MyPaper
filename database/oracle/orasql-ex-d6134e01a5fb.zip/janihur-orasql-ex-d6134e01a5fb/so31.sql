/* Replace not matching values with sub query in pl/sql

An answer to SO question:  http://stackoverflow.com/q/18506109/
*/

-- create table queues as
-- select 'Windows' as queuename, 1 as priority from dual union all
-- select 'Linux'   as queuename, 2 as priority from dual union all
-- select 'Unknown' as queuename, 3 as priority from dual
-- ;

with data_(qname) as (
select 'Windows'   from dual union all
select 'Macintosh' from dual
)
select coalesce(q.queuename, 'Unknown') as queuename,
       coalesce(q.priority, 3) as priority
from data_ d
left outer join queues q on q.queuename = d.qname
;

with data_(qname) as (
select 'Windows'   from dual union all
select 'Macintosh' from dual
)
select coalesce(queues.queuename, default_.queuename) as queuename,
       coalesce(queues.priority, default_.priority) as priority
from data_
left outer join queues on queues.queuename = data_.qname
inner join queues default_ on default_.queuename = 'Unknown'
;

QUEUENA   PRIORITY
------- ----------
Windows 	 1
Unknown 	 3
