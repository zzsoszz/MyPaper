/* I was going to post a question to OTN, but I found an answer before
that. See below and
http://forums.oracle.com/forums/thread.jspa?messageID=9512586 */

/* In both cases A and B register schema parameters are identical but case A complains about insufficient privileges. Why ? */

create or replace package OTN2 as
  procedure register_schema;
end;
/

create or replace package body OTN2 as
  procedure register_schema as
    oradir constant varchar2(30) := 'DATA_TALOUS';
    schemaurl constant varchar2(30) := 'camt.053.001.02.annotated.xsd';
    schemafile constant varchar2(30) := schemaurl;
  begin
    dbms_xmlschema.registerschema(schemaurl => schemaurl,
				  schemadoc => bfilename(oradir, schemafile),
				  local => true,
				  gentypes => true,
				  genbean => false,
				  gentables => true,
				  force => false,
				  owner => '',
				  csid => nls_charset_id('AL32UTF8'),
				  enablehierarchy => dbms_xmlschema.enable_hierarchy_contents,
				  options => 0
				  );
  end;
end;
/

/* CASE A

Schema registration will fail because of insufficient privileges.

grant alter session, create table, create view, create synonym to JANI;

doesn't make any difference.

RESOLVED: grant create type to JANI;

begin
*
ERROR at line 1:
ORA-01031: insufficient privileges
ORA-06512: at "XDB.DBMS_XMLSCHEMA_INT", line 37
ORA-06512: at "XDB.DBMS_XMLSCHEMA", line 65
ORA-06512: at "XDB.DBMS_XMLSCHEMA", line 136
ORA-06512: at "JANI.OTN2", line 7
ORA-06512: at line 2
*/
begin
  OTN2.register_schema;
end;
/

/* CASE B

Schema registration seems to have enough privileges (but there is other serious issues that were resolved with XML Schema annotations).

declare
*
ERROR at line 1:
ORA-31084: error while creating table "JANI"."Document2282_TAB" for element
"Document"
ORA-02320: failure in creating storage table for nested table column
"XMLDATA"."BkToCstmrStmt"."Stmt"
ORA-01792: maximum number of columns in a table or view is 1000
ORA-02310: exceeded maximum number of allowable columns in table
ORA-06512: at "XDB.DBMS_XMLSCHEMA_INT", line 37
ORA-06512: at "XDB.DBMS_XMLSCHEMA", line 65
ORA-06512: at "XDB.DBMS_XMLSCHEMA", line 136
ORA-06512: at line 6

*/
declare
  oradir constant varchar2(30) := 'DATA_TALOUS';
  schemaurl constant varchar2(30) := 'camt.053.001.02.annotated.xsd';
  schemafile constant varchar2(30) := schemaurl;
begin
  dbms_xmlschema.registerschema(schemaurl => schemaurl,
				schemadoc => bfilename(oradir, schemafile),
				local => true,
				gentypes => true,
				genbean => false,
				gentables => true,
				force => false,
				owner => '',
				csid => nls_charset_id('AL32UTF8'),
				enablehierarchy => dbms_xmlschema.enable_hierarchy_contents,
				options => 0
				);
end;
/
