declare
  v_text clob;

  procedure app2lob(p_lob in out nocopy clob, p_str in varchar2) is
  begin
    dbms_lob.writeappend(p_lob, length(p_str), p_str);
  end;

  function from_lob(p_lob in clob) return varchar2 is
    v_buffer varchar2(32767);
    v_chars_read pls_integer := 32767;
  begin
    dbms_lob.read(p_lob, v_chars_read, 1, v_buffer);
    dbms_output.put_line('from_lob: v_chars_read = ' || v_chars_read);
    return v_buffer;
  end;
begin
  if v_text is null then
    dbms_output.put_line('is null');
  end if;

  dbms_output.put_line('len = ' || dbms_lob.getlength(v_text));

  -- persistent lob have to be tied to a table column
  -- use temporary lob instead
  -- v_text := empty_clob(); -- persistent lob
  dbms_lob.createtemporary(v_text, true, dbms_lob.call);

  if v_text is not null then
    dbms_output.put_line('is not null');
  end if;

  dbms_output.put_line('len = ' || dbms_lob.getlength(v_text));

  dbms_output.put_line('chunksize = ' || dbms_lob.getchunksize(v_text));

  -- open and close are not necessary ?
  -- dbms_lob.open(v_text, dbms_lob.lob_readwrite);

  app2lob(v_text, 'foobar');
  app2lob(v_text, 'foobar');

  dbms_output.put_line('len = ' || dbms_lob.getlength(v_text));

  dbms_output.put_line('content = ''' || from_lob(v_text) || '''');
  
  -- dbms_lob.close(v_text);

  dbms_lob.freetemporary(v_text);
end;
/
