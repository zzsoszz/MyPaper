/* How to read CSV data from a Clob column in Oracle using PL/SQL

An answer to SO question: http://stackoverflow.com/questions/7842025

AFAIK Oracle has no ready made goodies for this. One promising candidate is [DBMS_UTILITY.COMMA_TO_TABLE](http://download.oracle.com/docs/cd/E11882_01/appdev.112/e23448/d_util.htm#i1002468), but it's [heavily limited](http://asktom.oracle.com/pls/asktom/f?p=100:11:0::::P11_QUESTION_ID:1415803954123) to a very special task making it no-option. So you have to roll your sleeves and make your own.

Your specification is a bit vague, but one option is a `SPLIT` function:

Of cource Oracle doesn't provide split but [SO helps](http://stackoverflow.com/search?q=%5Bplsql%5D+split). In the example above I have used my own one.

Other resources:

 * [Converting delimited lists to collections (and vice versa)](http://www.oratechinfo.co.uk/delimited_lists_to_collections.html)
 * [Ask Tom "DBMS_UTILITY.COMMA_TO_TABLE limitations ?"](http://asktom.oracle.com/pls/asktom/f?p=100:11:0::::P11_QUESTION_ID:1415803954123)
 * [Parsing CSV string](http://radino.eu/2009/01/01/parsing-csv-list/)
 * [CSV - comma separated values - and PL/SQL](http://plsql.wikidot.com/forum/t-41518)

*/

    create table so18t (
      id number,
      csv clob
    );

    insert all
    into so18t values(1,'1,2,3'||chr(10)||
                        '40,5,6'||chr(10)||
                        '700,80,9'||chr(10))
    into so18t values(2,'aaa,bbb,ccc'||chr(10)||
                        'ddd,eee,fff'||chr(10)||
                        'ggg,hhh,iii'||chr(10))
    select 1 from dual;

select * from so18t;

create or replace function readline(
  p_csv in clob,
  p_line in out number)
return varchar2 as
  v_end pls_integer := 0;
  v_beg pls_integer := 0;
begin
  if p_line < 1 or p_line is null then
    p_line := 1;
  end if;

  v_end := instr(p_csv, chr(10), 1, p_line);

  if v_end = 0 then
    p_line := 0;
    return '';
  end if;
  
  if p_line = 1 then
    v_beg := 1;
  else
    v_beg := instr(p_csv, chr(10), 1, p_line - 1) + 1;
  end if;

  p_line := p_line + 1;

  dbms_output.put_line('cvsread: v_beg = ' || v_beg || ' v_end = ' || v_end);

  return substr(p_csv, v_beg, v_end - v_beg);
end;
/
show errors

declare
  v_str varchar2(32767);
  v_line number := 0;
  v_line_vals jh_util.stringlist_t;
begin
  for rec in (select * from so18t order by id) loop
    loop
      v_str := readline(rec.csv, v_line);
      exit when v_line = 0;
      /* Process v_line */
      dbms_output.put_line('line = ' || v_str);
      v_line_vals := jh_util.split(v_str);
      for i in v_line_vals.first .. v_line_vals.last loop
        dbms_output.put_line('v_line_vals('||i||') = '|| v_line_vals(i));
      end loop;
    end loop;
  end loop;
end;
/
show errors

    declare
      v_lines jh_util.stringlist_t;
      v_values jh_util.stringlist_t;
    begin
      for rec in (select * from so18t order by id) loop
        v_lines := jh_util.split(rec.csv, chr(10));
        for i in v_lines.first .. v_lines.last loop
          dbms_output.put_line('line ' || i || ':');
          v_values := jh_util.split(v_lines(i));
          for j in v_values.first .. v_values.last loop
            dbms_output.put_line('v_values(' || j || ') = ' || v_values(j));
          end loop;
        end loop;
      end loop;
    end;
    /
    show errors

/*
    line 1:
    v_values(1) = 1
    v_values(2) = 2
    v_values(3) = 3
    line 2:
    v_values(1) = 40
    v_values(2) = 5
    v_values(3) = 6
    line 3:
    v_values(1) = 700
    v_values(2) = 80
    v_values(3) = 9
    line 1:
    v_values(1) = aaa
    v_values(2) = bbb
    v_values(3) = ccc
    line 2:
    v_values(1) = ddd
    v_values(2) = eee
    v_values(3) = fff
    line 3:
    v_values(1) = ggg
    v_values(2) = hhh
    v_values(3) = iii
    
    PL/SQL procedure successfully completed.
*/
      
drop function readline;
drop table so18t;

quit
