-- Posted to OTN:
-- http://forums.oracle.com/forums/thread.jspa?threadID=2147453&messageID=9677557#9677557

-- NOTE that using an expressions instead of a static XQuery string disables
-- some precisious optimizations. See the discussion in OTN.

select banner as "Oracle version" from v$version where banner like 'Oracle%';

-- xpath query that returns value attribute of name element of id i
create or replace function otn_make_xpath(
  i in pls_integer default 1
) return varchar2 as
begin
  return '/ceccish.name_xml/name[@id="' || i || '"]/@value';
  --XVM-00311: unsupported feature: fn:id():
  --return '/ceccish.name_xml/id(''' || i || ''')/@value';
end;
/
show errors

declare
  input_str constant varchar2(200) :=
'<ceccish.name_xml>
<name id="1" lang="cz" value="test1" />
<name id="2" lang="en" value="test2" />
<name id="3" lang="sk" value="test3" />
</ceccish.name_xml>';
  i pls_integer := 0;
  i2 number := 0;
  val varchar2(100);
begin
  dbms_output.put_line('First example');

  for i in 1..4 loop -- index off by one on purpose
    select xmlcast(
      -- not recommended to use function instead of static XQuery string.
      xmlquery(otn_make_xpath(i) passing xmltype(input_str) returning content)
      as varchar2(20))
      into val from dual;
    dbms_output.put_line(i || ': ' || val);
  end loop;

  dbms_output.put_line('Second example');

  i := 1;
  loop
    select xmlcast(
      -- not recommended to use function instead of static XQuery string.
      xmlquery(otn_make_xpath(i) passing xmltype(input_str) returning content)
      as varchar2(20))
      into val from dual;
    exit when val is null;
    dbms_output.put_line(i || ': ' || val);
    i := i + 1;
  end loop;

  dbms_output.put_line('Third example');

  i2 := 1; -- xquery as a SQL function doesn't like pls_integer
  loop
    select xmlcast(
      xmlquery('$doc/ceccish.name_xml/name[@id=$id]/@value'
	       passing xmltype(input_str) as "doc",
	       i2 as "id"
	       returning content)
      as varchar2(20))
      into val from dual;
    exit when val is null;
    dbms_output.put_line(i2 || ': ' || val);
    i2 := i2 + 1;
  end loop;
  
end;
/

drop function otn_make_xpath;
