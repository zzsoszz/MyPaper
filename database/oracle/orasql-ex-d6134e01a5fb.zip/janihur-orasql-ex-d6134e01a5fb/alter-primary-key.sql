--
-- Original tables
--

create table if_step_a_header (
  id number not null,
  site varchar2(10) not null,
  data varchar2(20),
  process_status number default 0,
  constraint if_step_a_header_pk primary key(id) using index
);

create table if_step_a_data (
  id number not null,
  header_id number not null,
  site varchar2(10) not null,
  data varchar2(20),
  constraint if_step_a_data_pk primary key(id) using index,
  constraint if_step_a_data_fk foreign key(header_id) references if_step_a_header(id) on delete cascade
);

insert all 
into if_step_a_header values(1, 'TRE', 'abcd', 0)
into if_step_a_header values(2, 'HKI', 'efgh', 0)
select 1 from dual;

insert all
into if_step_a_data values(1, 1, 'TRE', 'real TRE data 1')
into if_step_a_data values(2, 1, 'TRE', 'real TRE data 2')
into if_step_a_data values(3, 1, 'TRE', 'real TRE data 3')
into if_step_a_data values(4, 2, 'HKI', 'real HKI data 1')
into if_step_a_data values(5, 2, 'HKI', 'real HKI data 2')
into if_step_a_data values(6, 2, 'HKI', 'real HKI data 3')
select 1 from dual;

--
-- Modifications to create primary key with two columns
--

alter table if_step_a_header drop primary key cascade;
alter table if_step_a_header add constraint if_step_a_header_pk primary key(id, site) using index;
alter table if_step_a_data add constraint if_step_a_data_fk foreign key(header_id, site) references if_step_a_header(id, site) on delete cascade;
