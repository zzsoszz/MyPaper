/* Matching system date to select file SQL

An answer to SO question: http://stackoverflow.com/q/17977382

Code part only.
*/

declare
  v_filename constant varchar2(32767) :=
    'Files.' || to_char(sysdate, 'YYYYMMDD') || '.xxx';
begin
  dbms_output.put_line('v_filename = ' || v_filename);
end;
/