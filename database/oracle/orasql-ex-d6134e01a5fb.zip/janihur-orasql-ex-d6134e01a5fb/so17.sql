/* How to sort an associative array in PL/SQL?

An answer to SO question: http://stackoverflow.com/q/7800880

You can't sort an associative array by values, but you have to convert the data to some other data structure and make the sorting there. The easiest way would have been to convert to another associative array where keys and values swap places, but that requires your key values should be unique too.

Below is an example adapted to your case from [Sorting PL/SQL Collections](http://technology.amis.nl/blog/1217/sorting-plsql-collections-the-quite-simple-way-part-two-have-the-sql-engine-do-the-heavy-lifting). Please check that article for the details.

*/

    /* The sorting is done with SQL thus these types have to be SQL types. */

    create type sortable_t is object(
      continent varchar2(32767),
      population number
    );
    /

    create type sortable_table_t is table of sortable_t;
    /

    declare
      type continent_population_t is table of pls_integer index by varchar2(32767);
      continent_population continent_population_t;

      i varchar2(32767);

      sorted sortable_table_t := sortable_table_t();
    begin
      /* Populate original data. */

      continent_population('Australia') := 30;
      continent_population('Antarctica') := 90;
      continent_population('UK') := 50;
      continent_population('USA') := 50;

      /* Convert to a helper data type that is used for sorting. */

      i := continent_population.first;

      while i is not null loop
        sorted.extend(1);
        sorted(sorted.last) := new sortable_t(i, continent_population(i));
        -- sorted(sorted.last).continent := i;
        -- sorted(sorted.last).population := continent_population(i);
        i := continent_population.next(i);
      end loop;

      /* Show that the content is not sorted yet. */

      dbms_output.put_line('Unsorted:');
      for j in sorted.first .. sorted.last loop
        dbms_output.put_line(sorted(j).continent || ' = ' || sorted(j).population);
      end loop;

      /* Sorting with SQL. */

      select cast(multiset(select *
                           from table(sorted)
                           order by 2 asc, 1 asc)
                  as sortable_table_t)
        into sorted
        from dual;

      /* Show that the content is now sorted. */

      dbms_output.put_line('Sorted by value:');
      for j in sorted.first .. sorted.last loop
        dbms_output.put_line(sorted(j).continent || ' = ' || sorted(j).population);
      end loop;

    end;
    /

drop type sortable_table_t;
drop type sortable_t;
