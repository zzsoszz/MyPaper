-- A slightly narrated example how to 
-- a) write a package
-- b) generate a random number 

-- TODO: uses number type, but should use some integer type instead
-- pls_integer maybe ?

-- package specification is package's public interface
create or replace package mydice as
  -- default parameter value
  -- sqlplus: > exec mydice.set_size(10);
  procedure set_size(size_ in number := 6);
  -- parameter-less function/procedure - no parentheses
  -- sqlplus: > select mydice.roll from dual;
  function roll return number;
end;
/ 
-- foreslash ('/') executes the block in sqlplus

-- package body is package's private implementation
create or replace package body mydice as
  -- variable has default value
  dice_size number := 6;
  -- TODO: should accept only even dice sizes
  procedure set_size(size_ in number := 6)
  as
  begin
    -- decimal numbers are floored to integers
    dice_size := floor(size_);
    dbms_output.put_line('dice size set to ' || dice_size);
  end;

  function roll return number
  as
  begin
    return floor(dbms_random.value(1, dice_size + 1));
  end;
end;
/

create or replace function ordinal(num in number) return varchar2
as
  num_ number := floor(num);
begin
  case
    when num_ is null then return '';
    when num_ = 1 then return '1st';
    when num_ = 2 then return '2nd';
    when num_ = 3 then return '3rd';
    else return concat(num_, 'th');
  end case;
end;
/

-- a procedure to exercise previously defined packages and procedures
-- sqlplus: > exec runner;
-- sqlplus: > exec runner(20, 8);
create or replace procedure runner(rolls in number := 10, 
                                   dice_size in number := 6)
as
  rolls_ number := floor(rolls);
  dice_size_ number := floor(dice_size);
  num number := 0;
begin
  mydice.set_size(dice_size_);
  for i in 1..rolls_ loop
    num := mydice.roll; 
    dbms_output.put_line(ordinal(i) || ' dice rolled, got ' || num);
  end loop;
end;
/

-- anonymous block to execute procedure runner when the file is sourced
declare
begin
  runner;
end;
/
