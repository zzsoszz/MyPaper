/* An example how to raise a named exception with an user specific message. */

create or replace package jhex3 is
  foo_ex_code constant pls_integer := -20000;
  foo_ex exception;
  pragma exception_init(foo_ex, -20000);

  bar_ex_code constant pls_integer := -20001;
  bar_ex exception;
  pragma exception_init(bar_ex, -20001);

  procedure raise_ex(p_code in number, p_msg in varchar2);

  procedure p1;
  procedure p2;
end;
/
show errors

create or replace package body jhex3 is
  procedure raise_ex(p_code in number, p_msg in varchar2) is
  begin
    raise_application_error(p_code, p_msg, true);
  end;

  procedure p1 is
  begin
    p2;
  end;
  procedure p2 is
  begin
    raise_ex(bar_ex_code, 'wrong bar!');
  end;
end;
/
show errors

declare
  procedure print_ex is
  begin
    dbms_output.put_line('sqlcode');
    dbms_output.put_line('-------');
    dbms_output.put_line(sqlcode);

    dbms_output.put_line('sqlerrm');
    dbms_output.put_line('-------');
    dbms_output.put_line(sqlerrm);

    dbms_output.put_line('dbms_utility.format_error_stack');
    dbms_output.put_line('-------------------------------');
    dbms_output.put_line(dbms_utility.format_error_stack);

    dbms_output.put_line('dbms_utility.format_error_backtrace');
    dbms_output.put_line('-----------------------------------');
    dbms_output.put_line(dbms_utility.format_error_backtrace);
  end;
begin
  jhex3.p1;
exception
  when jhex3.bar_ex then
    print_ex;
  when others then
    print_ex;
end;
/
