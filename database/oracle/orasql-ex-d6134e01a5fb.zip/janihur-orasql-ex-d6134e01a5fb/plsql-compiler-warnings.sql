/* Reasons for disabling in 11gR2

5018: unit omitted optional AUTHID clause; default value DEFINER used
---------------------------------------------------------------------

The default value is good.

6003: unknown inquiry directive
-------------------------------

We're using out own inquiry directives.

7202: bind type would result in conversion away from column type
----------------------------------------------------------------

Looks like Oracle bug: https://community.oracle.com/thread/1115765

*/

alter session set plsql_warnings = 'ENABLE:ALL, DISABLE:(5018, 6003, 7202)';
