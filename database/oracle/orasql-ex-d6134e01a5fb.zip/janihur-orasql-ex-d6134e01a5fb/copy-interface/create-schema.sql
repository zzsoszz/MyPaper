--
-- First part of the interface
--

create table if_step_a_header (
  id number not null,
  site varchar2(10) not null,
  data varchar2(20),
  process_status number not null default 0,
  constraint if_step_a_header_pk primary key(id, site)
);

create sequence if_header_sq;

create table if_step_a_data (
  id number not null,
  header_id number not null,
  site varchar2(10) not null,
  data varchar2(20),
  constraint if_step_a_data_pk primary key(id),
  constraint if_step_a_data_fk foreign key(header_id, site) references if_step_a_header(id, site) on delete cascade
);

create sequence if_data_sq;

--
-- Second part of the interface
-- This is an exact duplicate of the first part
--

create table if_step_b_header (
  id number not null,
  site varchar2(10) not null,
  data varchar2(20),
  process_status number not null default 0,
  constraint if_step_b_header_pk primary key(id, site)
);

create table if_step_b_data (
  id number not null,
  header_id number not null,
  site varchar2(10) not null,
  data varchar2(20),
  constraint if_step_b_data_pk primary key(id),
  constraint if_step_b_data_fk foreign key(header_id, site) references if_step_b_header(id, site) on delete cascade
);
