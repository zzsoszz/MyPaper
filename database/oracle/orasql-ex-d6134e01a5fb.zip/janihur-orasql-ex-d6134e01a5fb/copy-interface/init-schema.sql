delete from if_step_b_header;
delete from if_step_a_header;

insert into if_step_a_header values(if_header_sq.nextval, 'TRE', 'Tampere data set', 0);

insert into if_step_a_data values(if_data_sq.nextval, if_header_sq.currval, 'TRE', 'data ' || if_data_sq.currval);
insert into if_step_a_data values(if_data_sq.nextval, if_header_sq.currval, 'TRE', 'data ' || if_data_sq.currval);
insert into if_step_a_data values(if_data_sq.nextval, if_header_sq.currval, 'TRE', 'data ' || if_data_sq.currval);

insert into if_step_a_header values(if_header_sq.nextval, 'HKI', 'Helsinki data set', 0);

insert into if_step_a_data values(if_data_sq.nextval, if_header_sq.currval, 'HKI', 'data ' || if_data_sq.currval);
insert into if_step_a_data values(if_data_sq.nextval, if_header_sq.currval, 'HKI', 'data ' || if_data_sq.currval);
insert into if_step_a_data values(if_data_sq.nextval, if_header_sq.currval, 'HKI', 'data ' || if_data_sq.currval);
