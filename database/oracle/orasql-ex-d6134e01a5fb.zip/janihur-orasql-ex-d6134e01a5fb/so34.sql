/* Oracle PLSQL truncate datetime to specific hours

An answer to SO question: http://stackoverflow.com/q/18886414/272735

*/

with data(time) as (
  select to_date('2013-09-19 00:00:00', 'YYYY-MM-DD HH24:MI:SS') from dual union all
  select to_date('2013-09-19 06:45:44', 'YYYY-MM-DD HH24:MI:SS') from dual union all
  select to_date('2013-09-19 08:12:25', 'YYYY-MM-DD HH24:MI:SS') from dual union all
  select to_date('2013-09-19 18:59:59', 'YYYY-MM-DD HH24:MI:SS') from dual union all
  select to_date('2013-09-19 19:00:00', 'YYYY-MM-DD HH24:MI:SS') from dual union all
  select to_date('2013-09-19 20:15:35', 'YYYY-MM-DD HH24:MI:SS') from dual union all
  select to_date('2013-09-19 23:59:59', 'YYYY-MM-DD HH24:MI:SS') from dual
)
select d.time,
case
  when to_number(to_char(d.time, 'HH24')) >= 19 then
    trunc(d.time) + 19/24
  when to_number(to_char(d.time, 'HH24')) >= 7 then
    trunc(d.time) + 7/24
  else
    trunc(d.time - 1) + 19/24
end as shift_date
from data d
;
