/* How to generate XML from relational table with DBMS_XMLGEN.

An answer to a question:
http://stackoverflow.com/questions/6809603/dbms-xmlquery-and-select-for-update/6817749#6817749
*/

set long 500

select banner as "Oracle version" from v$version where banner like 'Oracle%';

create table so2in (id number, proc number, desc_ varchar2(20));

insert into so2in values(100, 0, 'desc of 100');
insert into so2in values(101, 0, 'desc of 101');
insert into so2in values(102, 0, 'desc of 102');
insert into so2in values(103, 0, 'desc of 103');
insert into so2in values(104, 0, 'desc of 104');

create table so2out(r1 clob, r2 xmltype);

declare
  qryctx dbms_xmlgen.ctxhandle;
  cur sys_refcursor;
  r1 clob;
  r2 xmltype;
begin
  open cur for
    select id, desc_ from so2in where proc = 0 and rownum <= 2 for update;

  qryctx := dbms_xmlgen.newcontext(cur);
  dbms_xmlgen.setrowtag(qryctx, 'Description');
  dbms_xmlgen.setrowsettag(qryctx, 'Descriptions');

  r1 := dbms_xmlgen.getxml(qryctx);

  update so2in set proc = 1 where proc = 0 and rownum <= 2;

  dbms_xmlgen.restartquery(qryctx);

  r2 := dbms_xmlgen.getxmltype(qryCtx);

  update so2in set proc = 1 where proc = 0 and rownum <= 2;

  insert into so2out values(r1, r2);

  dbms_xmlgen.closecontext(qryctx);

  commit;
end;
/

select * from so2in;

select r1 from so2out;
select r2 from so2out;

drop table so2in;
drop table so2out;

quit
