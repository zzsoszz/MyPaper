-- Posted to OTN:
-- http://forums.oracle.com/forums/thread.jspa?threadID=2251256&messageID=9721970#9721970

/* Text is also an XML node. */

declare
  xmldata constant xmltype := xmltype('<root>
  <item>
    <id>1</id>
    <data>Id 1 updated.</data>
  </item>
  <item>
    This is a text node !
    <id>3</id>
    <data>Id 3 updated.</data>
  </item>
</root>');

  output varchar2(40);
begin
  -- the first sibling of first item element is an element node
  output := xmldata.extract('/root/item[1]/node()[1]').getstringval;
  dbms_output.put_line(output);

  -- the first sibling of second item element is a text node
  output := xmldata.extract('/root/item[2]/node()[1]').getstringval;
  dbms_output.put_line(output);
end;
/
