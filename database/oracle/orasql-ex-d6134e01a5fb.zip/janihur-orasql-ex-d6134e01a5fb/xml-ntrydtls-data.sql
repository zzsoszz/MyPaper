create table xml_data (
  id number,
  data xmltype
);

insert into xml_data values (1, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.053.001.02">
  <TxDtls>
    <Refs>
      <!-- Reference used by the Debtor banks-->
      <InstrId>ISSRBKREF12345678</InstrId>
      <TxId>ISSRBKREF12345678</TxId>
    </Refs>
    <!-- specification of counter values (TITO T11_05) -->
    <AmtDtls>
      <!-- Amount as original instruction, Gross value of the incoming transaction before deductions-->
      <InstdAmt>
        <Amt Ccy="USD">3230</Amt>
      </InstdAmt>
      <!-- Booked Amount after deductions -->
      <TxAmt>
        <Amt Ccy="EUR">2120</Amt>
        <CcyXchg>
          <SrcCcy>USD</SrcCcy>
          <TrgtCcy>EUR</TrgtCcy>
          <!-- denomintor currency in the Exchange rate factor: Exchange rate = Unit Curerency / Quoted Currency -->
          <UnitCcy>EUR</UnitCcy>
          <XchgRate>1.5</XchgRate>
          <CtrctId>FX12345</CtrctId>
          <QtnDt>2010-10-29T10:00:00.000000+02:00</QtnDt>
        </CcyXchg>
      </TxAmt>
      <!-- Amount as CounterValue, Gross value of the incoming transaction before deductions-->
      <CntrValAmt>
        <Amt Ccy="EUR">2140</Amt>
        <CcyXchg>
          <SrcCcy>USD</SrcCcy>
          <TrgtCcy>EUR</TrgtCcy>
          <UnitCcy>EUR</UnitCcy>
          <XchgRate>1.5</XchgRate>
          <CtrctId>FX12345</CtrctId>
          <QtnDt>2010-10-29T10:00:00.000000+02:00</QtnDt>
        </CcyXchg>
      </CntrValAmt>
    </AmtDtls>
    <!-- in case of netted booking, debited charges are given like this.  Note!  Charges can be given without amount deduction also as an information!-->
    <Chrgs>
      <Amt Ccy="EUR">20</Amt>
      <Tp>
        <Cd>COMM</Cd>
      </Tp>
    </Chrgs>
    <RltdPties>
      <Dbtr>
        <Nm>DEBTOR NAME</Nm>
        <!-- Usually OrgId is not available in inernational money transfers -->
        <Id>
          <OrgId>
            <Othr>
              <Id>123456789</Id>
              <SchmeNm>
                <Cd>DUNS</Cd>
              </SchmeNm>
            </Othr>
          </OrgId>
        </Id>
      </Dbtr>
    </RltdPties>
    <RltdAgts>
      <DbtrAgt>
        <FinInstnId>
          <BIC>BOFAUS6H</BIC>
        </FinInstnId>
      </DbtrAgt>
    </RltdAgts>
    <RmtInf>
      <Ustrd>INVOICE US20291092</Ustrd>
    </RmtInf>
  </TxDtls>
</NtryDtls>'));

insert into xml_data values (2, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.053.001.02">
  <TxDtls>
    <Refs>
      <!-- Reference used by the Debtor banks -->
      <InstrId>BKREFDBT0101010</InstrId>
      <TxId>BKREFDBT0101010</TxId>
    </Refs>
    <AmtDtls>
      <!-- Amount as original -->
      <InstdAmt>
        <Amt Ccy="EUR">5500</Amt>
      </InstdAmt>
      <TxAmt>
        <Amt Ccy="EUR">5455</Amt>
      </TxAmt>
    </AmtDtls>
    <Chrgs>
      <Amt Ccy="EUR">45</Amt>
      <Tp>
        <Cd>COMM</Cd>
      </Tp>
    </Chrgs>
    <RltdPties>
      <Dbtr>
        <Nm>PAYERS NAME2</Nm>
        <PstlAdr>
          <StrtNm>GOVERN STREET</StrtNm>
          <BldgNb>22</BldgNb>
          <PstCd>291092</PstCd>
          <TwnNm>LONDON</TwnNm>
          <Ctry>UK</Ctry>
        </PstlAdr>
        <Id>
          <OrgId>
            <Othr>
              <Id>123456789</Id>
              <SchmeNm>
                <Cd>EANG</Cd>
              </SchmeNm>
            </Othr>
          </OrgId>
        </Id>
      </Dbtr>
    </RltdPties>
    <RltdAgts>
      <DbtrAgt>
        <FinInstnId>
          <BIC>BOFSGB22</BIC>
        </FinInstnId>
      </DbtrAgt>
    </RltdAgts>
    <RmtInf>
      <Strd>
        <RfrdDocAmt>
          <RmtdAmt Ccy="EUR">5500</RmtdAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
            <Issr>ISO</Issr>
          </Tp>
          <Ref>RF98123456789012</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
  </TxDtls>
</NtryDtls>'));

insert into xml_data values (3, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.053.001.02">
  <TxDtls>
    <Refs>
      <EndToEndId>EndToEndIdSCT01</EndToEndId>
    </Refs>
    <!-- EPC recommendation -->
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">10000</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Dbtr>
        <Nm>DEBTOR</Nm>
      </Dbtr>
      <UltmtDbtr>
        <Nm>ULTIMATE DEBTOR</Nm>
        <Id>
          <OrgId>
            <Othr>
              <Id>987654321</Id>
              <SchmeNm>
                <Cd>TXID</Cd>
              </SchmeNm>
            </Othr>
          </OrgId>
        </Id>
      </UltmtDbtr>
    </RltdPties>
    <RltdAgts>
      <DbtrAgt>
        <FinInstnId>
          <BIC>NDEAFIHH</BIC>
        </FinInstnId>
      </DbtrAgt>
    </RltdAgts>
    <Purp>
      <Cd>TREA</Cd>
    </Purp>
    <RmtInf>
      <Strd>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
            <Issr>ISO</Issr>
          </Tp>
          <Ref>RF98123456789012</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
    <RltdDts>
      <AccptncDtTm>2010-10-28T03:00:00.000000+02:00</AccptncDtTm>
    </RltdDts>
  </TxDtls>
</NtryDtls>'));

insert into xml_data values (4, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.053.001.02">
  <!-- TX-details defining the type specific charges -->
  <!-- PMJ received Payments -->
  <TxDtls>
    <Refs>
      <AcctSvcrRef>091029ARCH09001</AcctSvcrRef>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">100</Amt>
      </TxAmt>
    </AmtDtls>
    <BkTxCd>
      <Domn>
        <Cd>PMNT</Cd>
        <Fmly>
          <Cd>RCDT</Cd>
          <SubFmlyCd>DMCT</SubFmlyCd>
        </Fmly>
      </Domn>
    </BkTxCd>
    <RltdPties>
      <Dbtr>
        <Nm>SEB Merchant Banking Finland</Nm>
      </Dbtr>
    </RltdPties>
    <RltdQties>
      <Qty>
        <Unit>10000</Unit>
      </Qty>
    </RltdQties>
  </TxDtls>
  <!-- SEPA Received  Payments -->
  <TxDtls>
    <Refs>
      <AcctSvcrRef>091029ARCH09001</AcctSvcrRef>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">100</Amt>
      </TxAmt>
    </AmtDtls>
    <BkTxCd>
      <Domn>
        <Cd>PMNT</Cd>
        <Fmly>
          <Cd>RCDT</Cd>
          <SubFmlyCd>ESCT</SubFmlyCd>
        </Fmly>
      </Domn>
    </BkTxCd>
    <RltdPties>
      <Dbtr>
        <Nm>SEB Merchant Banking Finland</Nm>
      </Dbtr>
    </RltdPties>
    <RltdQties>
      <Qty>
        <Unit>150000</Unit>
      </Qty>
    </RltdQties>
  </TxDtls>
</NtryDtls>'));

insert into xml_data values (5, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.054.001.02">
  <Btch>
    <MsgId>BANKFILEID998765</MsgId>
    <NbOfTxs>2</NbOfTxs>
    <TtlAmt Ccy="EUR">2000</TtlAmt>
    <CdtDbtInd>CRDT</CdtDbtInd>
  </Btch>
  <TxDtls>
    <!-- Transaction 1-->
    <Refs>
      <!-- Archiving code for the transaction level-->
      <AcctSvcrRef>D091029N987654321S001</AcctSvcrRef>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <!-- net value of normal and credit note instances -->
        <Amt Ccy="EUR">1900</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Dbtr>
        <!-- although current reporting allows only 12 letters in camt.054 it is recommended to report whole PMJ-content if available-->
        <Nm>PAYERS NAME1</Nm>
      </Dbtr>
    </RltdPties>
    <RmtInf>
      <Strd>
        <RfrdDocAmt>
          <!-- Normal credited amount -->
          <RmtdAmt Ccy="EUR">2500</RmtdAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
          </Tp>
          <!-- KTL Transaction Reference in Finnish syntax-->
          <Ref>3900</Ref>
        </CdtrRefInf>
      </Strd>
      <Strd>
        <RfrdDocAmt>
          <!--Credit note payment from the same payer as the (negative effect on Entry level amout)t-->
          <CdtNoteAmt Ccy="EUR">600</CdtNoteAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
          </Tp>
          <Ref>12344</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
    <RltdDts>
      <!--Transaction Payment date in the Finnish context (PMJ) -->
      <AccptncDtTm>2010-10-28T09:00:00.000000+02:00</AccptncDtTm>
    </RltdDts>
  </TxDtls>
  <TxDtls>
    <!-- Transaction 2-->
    <Refs>
      <AcctSvcrRef>D091029N987654321S002</AcctSvcrRef>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">100</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Dbtr>
        <Nm>PAYERS NAME2</Nm>
      </Dbtr>
    </RltdPties>
    <RmtInf>
      <Strd>
        <RfrdDocAmt>
          <RmtdAmt Ccy="EUR">100</RmtdAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
          </Tp>
          <Ref>43216</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
    <RltdDts>
      <AccptncDtTm>2010-10-29T09:00:00.000000+02:00</AccptncDtTm>
    </RltdDts>
  </TxDtls>
</NtryDtls>'));

insert into xml_data values (6, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.054.001.02">
  <Btch>
    <MsgId>BANKFILEID998765</MsgId>
    <NbOfTxs>2</NbOfTxs>
    <TtlAmt Ccy="EUR">3000</TtlAmt>
    <CdtDbtInd>CRDT</CdtDbtInd>
  </Btch>
  <TxDtls>
    <!-- Transaction 1-->
    <Refs>
      <!-- Archiving code for the transaction level-->
      <AcctSvcrRef>D091029N123456789S001</AcctSvcrRef>
      <!-- End-to-end-ID / AT-41-->
      <EndToEndId>EndToEndIdAT-41-001</EndToEndId>
    </Refs>
    <AmtDtls>
      <!-- AT-04 in a difrent element than suggested by EPC -->
      <TxAmt>
        <Amt Ccy="EUR">2500</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Dbtr>
        <Nm>AT-02 DEBTOR NAME 01</Nm>
        <Id>
          <OrgId>
            <Othr>
              <Id>AT-10ASDUNS</Id>
              <SchmeNm>
                <Cd>DUNS</Cd>
              </SchmeNm>
            </Othr>
          </OrgId>
        </Id>
      </Dbtr>
    </RltdPties>
    <!-- AT 05 in a model where Finnsh AOS2 is used to report credit notes within SCT-->
    <RmtInf>
      <Strd>
        <RfrdDocAmt>
          <!-- Normal credited amount -->
          <RmtdAmt Ccy="EUR">3500</RmtdAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
            <Issr>ISO</Issr>
          </Tp>
          <!-- Creditor Reference in ISO 11649-->
          <Ref>RF7812345 </Ref>
        </CdtrRefInf>
      </Strd>
      <Strd>
        <RfrdDocAmt>
          <!--Credit note payment from the same payer as the (negative effect on Entry level amout)-->
          <CdtNoteAmt Ccy="EUR">1000</CdtNoteAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
            <Issr>ISO</Issr>
          </Tp>
          <Ref>RF0812344</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
    <RltdDts>
      <!--Finnish AOS1 as payment date (Debtor''s debit date)-->
      <AccptncDtTm>2010-10-28T09:00:00.000000+02:00</AccptncDtTm>
      <!-- AT-42.  There might be only small importance of Settlement date for the creditor but this is also optional to report -->
      <IntrBkSttlmDt>2010-10-28</IntrBkSttlmDt>
    </RltdDts>
  </TxDtls>
  <TxDtls>
    <!-- Transaction 2-->
    <Refs>
      <AcctSvcrRef>D091029N123456789S002</AcctSvcrRef>
      <EndToEndId>EndToEndIdAT-41-002</EndToEndId>
    </Refs>
    <AmtDtls>
      <!-- AT-04 in a difrent element than suggested by EPC -->
      <TxAmt>
        <Amt Ccy="EUR">500</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Dbtr>
        <Nm>AT-02 DEBTOR NAME 02</Nm>
        <Id>
          <OrgId>
            <Othr>
              <Id>AT-10ASEANG</Id>
              <SchmeNm>
                <Cd>EANG</Cd>
              </SchmeNm>
            </Othr>
          </OrgId>
        </Id>
      </Dbtr>
      <UltmtDbtr>
        <Nm>AT-08 ULTIMATE DEBTOR NAME</Nm>
        <Id>
          <OrgId>
            <Othr>
              <Id>AT-09TXID</Id>
              <SchmeNm>
                <Cd>TXID</Cd>
              </SchmeNm>
            </Othr>
          </OrgId>
        </Id>
      </UltmtDbtr>
      <UltmtCdtr>
        <Nm>AT-28 ULTIMATE CREDITOR NAME</Nm>
        <Id>
          <OrgId>
            <Othr>
              <Id>AT-29TXID</Id>
              <SchmeNm>
                <Cd>TXID</Cd>
              </SchmeNm>
            </Othr>
          </OrgId>
        </Id>
      </UltmtCdtr>
    </RltdPties>
    <!-- just for sample AT-44 with void value-->
    <Purp>
      <Cd>CASH</Cd>
    </Purp>
    <RmtInf>
      <Ustrd>RFB/557742358</Ustrd>
    </RmtInf>
    <RltdDts>
      <AccptncDtTm>2010-10-29T09:00:00.000000+02:00</AccptncDtTm>
      <IntrBkSttlmDt>2010-10-28</IntrBkSttlmDt>
    </RltdDts>
  </TxDtls>
</NtryDtls>'));

insert into xml_data values (7, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.053.001.02">
  <Btch>
    <!-- customer made batch and message-references (not in old TS but yes in SALA SCT in case that pain.001 is used and direct corresponding matching can be found).  Purpose: Reconciiation-->
    <!-- Basic recommendation: as much as possible of the original payment instruction material that came from the customer into the bank-->
    <MsgId>MSGSALA0001</MsgId>
    <!-- in LM-batches this is an info given in the batch record and supported by most of the banks as the initiator batch level identification-->
    <PmtInfId>CustRefForSalaBatch</PmtInfId>
    <!-- customer made batch''s transaction total by the initiated material.  Purpose: Reconciiation-->
    <NbOfTxs>4</NbOfTxs>
  </Btch>
  <TxDtls>
    <!-- Applying to CGI-rules and for consistencty purposes indicating always required TxDtls/AmtDtsl/TxAmt as a copy of Ntry/Amt  -->
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">1000.12</Amt>
      </TxAmt>
    </AmtDtls>
    <!-- used to specify what subtype (purpose code) of SCT SALA (category purpose and notice that tx code in this case is PMNT/ICDT/ESCT) debtor has used. Not so critical on debtor stmts but on creditor it  is -->
    <Purp>
      <Cd>SALA</Cd>
    </Purp>
  </TxDtls>
</NtryDtls>'));

insert into xml_data values (8, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.053.001.02">
  <Btch>
    <!-- customer made batch and message-references (not in old LM but yes in SCT in case that pain.001 is used and direct corresponding matching can be found).  Purpose: Reconciiation-->
    <!-- Basic recommendation: as many original payment instruction ids that came from the customer into the bank should be reported -> and let the customer application to choose the ones for its reconciliation-->
    <MsgId>MSGSCT0099</MsgId>
    <PmtInfId>CustRefForPmtBatch</PmtInfId>
    <!-- customer made batch''s transaction total.  Purpose: Reconciiation-->
    <NbOfTxs>3</NbOfTxs>
  </Btch>
  <TxDtls>
    <!-- Applying to CGI-rules and for consistencty purposes indicating always required TxDtls/AmtDtsl/TxAmt as a copy of Ntry/Amt  -->
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">4000</Amt>
      </TxAmt>
    </AmtDtls>
  </TxDtls>
</NtryDtls>'));

/* Workaround for braindead Oracle limitations */

declare
  data9 constant clob := '<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.054.001.02">
  <Btch>
    <MsgId>MSGSCT0100</MsgId>
    <PmtInfId>CustRefForPmtBatch9</PmtInfId>
    <NbOfTxs>3</NbOfTxs>
  </Btch>
  <!-- Debit transaction details level depend on the source given by the originator in its payment material in different formats -->
  <!-- Sufficient amount of references should be reported for reconciliation-->
  <TxDtls>
    <!-- Sub transaction no 1 of the batch /  with reference -->
    <Refs>
      <!-- The contents of Refs used depends on clearing system and / or availablle data on the instruction material -->
      <AcctSvcrRef>091029ARCH03001</AcctSvcrRef>
      <!-- Instruction Id to Indicate TITO_T11_06 id given from the initiatorin specific LM-payment file field -->
      <InstrId>TITOT1106ID01</InstrId>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">2000.02</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Cdtr>
        <Nm>Creditor Company</Nm>
        <!-- unstructured address on LM based material -->
        <PstlAdr>
          <Ctry>FI</Ctry>
          <AdrLine>Mannerheimintie 123</AdrLine>
          <AdrLine>00100 Helsinki</AdrLine>
        </PstlAdr>
        <CtryOfRes>FI</CtryOfRes>
      </Cdtr>
      <!-- Creditor account in BBAN still in PMJ-transactions, banks don''t convert internally into the reports creditor account on debtor reports -->
      <CdtrAcct>
        <Id>
          <Othr>
            <Id>29501800020582</Id>
            <SchmeNm>
              <Cd>BBAN</Cd>
            </SchmeNm>
          </Othr>
        </Id>
      </CdtrAcct>
    </RltdPties>
    <RmtInf>
      <Strd>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
          </Tp>
          <Ref>3900</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
  </TxDtls>
  <TxDtls>
    <!-- Sub transaction no 2 of the batch /  with free text -->
    <Refs>
      <AcctSvcrRef>091029ARCH03002</AcctSvcrRef>
      <InstrId>TITOT1106ID02</InstrId>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">1000.01</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Cdtr>
        <Nm>Creditor Company</Nm>
        <PstlAdr>
          <Ctry>FI</Ctry>
          <AdrLine>Mannerheimintie 123</AdrLine>
          <AdrLine>00100 Helsinki</AdrLine>
        </PstlAdr>
        <CtryOfRes>FI</CtryOfRes>
      </Cdtr>
      <CdtrAcct>
        <Id>
          <Othr>
            <Id>29501800020582</Id>
            <SchmeNm>
              <Cd>BBAN</Cd>
            </SchmeNm>
          </Othr>
        </Id>
        <!-- Creditor Account Changed at Debtor bank for better routing according to Debtor and its bank agreement-->
        <Tp>
          <Prtry>ACWC</Prtry>
        </Tp>
      </CdtrAcct>
    </RltdPties>
    <RmtInf>
      <Ustrd>Invoices 123 and 321</Ustrd>
    </RmtInf>
  </TxDtls>
  <TxDtls>
    <!-- Sub transaction no 3 of the batch /  with PMJ payment type code 2 (TITO T11-02) -->
    <!-- One simple option is to write this type of remittance type into one Unstrcured instance-->
    <Refs>
      <AcctSvcrRef>091029ARCH03003</AcctSvcrRef>
      <InstrId>TITOT1106ID03</InstrId>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">1230.02</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Cdtr>
        <Nm>Creditor Company</Nm>
        <PstlAdr>
          <Ctry>FI</Ctry>
          <AdrLine>Mannerheimintie 123</AdrLine>
          <AdrLine>00100 Helsinki</AdrLine>
        </PstlAdr>
        <CtryOfRes>FI</CtryOfRes>
      </Cdtr>
      <CdtrAcct>
        <Id>
          <Othr>
            <Id>29501800020574</Id>
            <SchmeNm>
              <Cd>BBAN</Cd>
            </SchmeNm>
          </Othr>
        </Id>
      </CdtrAcct>
    </RltdPties>
    <RmtInf>
      <Strd>
        <RfrdDocInf>
          <Tp>
            <CdOrPrtry>
              <Cd>CINV</Cd>
            </CdOrPrtry>
          </Tp>
          <Nb>217827182718</Nb>
        </RfrdDocInf>
        <Invcee>
          <Id>
            <OrgId>
              <Othr>
                <Id>9102910</Id>
              </Othr>
            </OrgId>
          </Id>
        </Invcee>
      </Strd>
    </RmtInf>
  </TxDtls>
</NtryDtls>';
begin
  insert into xml_data values (9, xmltype(data9));
end;
/

insert into xml_data values (10, xmltype('<NtryDtls xmlns="urn:iso:std:iso:20022:tech:xsd:camt.054.001.02">
  <Btch>
    <MsgId>BANKFILEID998799</MsgId>
    <NbOfTxs>2</NbOfTxs>
    <TtlAmt Ccy="EUR">500</TtlAmt>
    <CdtDbtInd>CRDT</CdtDbtInd>
  </Btch>
  <TxDtls>
    <!-- Transaction 1-->
    <Refs>
      <!-- Archiving code for the transaction level-->
      <AcctSvcrRef>D091029N987654321S211</AcctSvcrRef>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">400</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Dbtr>
        <!-- although current reporting allows only 12 letters in camt.054 it is recommended to report whole PMJ-content if available-->
        <Nm>PAYERS NAME1</Nm>
      </Dbtr>
    </RltdPties>
    <RmtInf>
      <Strd>
        <RfrdDocAmt>
          <RmtdAmt Ccy="EUR">400</RmtdAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
          </Tp>
          <Ref>3900</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
    <RltdDts>
      <!--Transaction Payment date in the Finnish context (PMJ) -->
      <AccptncDtTm>2010-10-28T09:00:00.000000+02:00</AccptncDtTm>
    </RltdDts>
  </TxDtls>
  <TxDtls>
    <!-- Transaction 2-->
    <Refs>
      <AcctSvcrRef>D091029N987654321S212</AcctSvcrRef>
    </Refs>
    <AmtDtls>
      <TxAmt>
        <Amt Ccy="EUR">100</Amt>
      </TxAmt>
    </AmtDtls>
    <RltdPties>
      <Dbtr>
        <Nm>PAYERS NAME2</Nm>
      </Dbtr>
    </RltdPties>
    <RmtInf>
      <Strd>
        <RfrdDocAmt>
          <RmtdAmt Ccy="EUR">100</RmtdAmt>
        </RfrdDocAmt>
        <CdtrRefInf>
          <Tp>
            <CdOrPrtry>
              <Cd>SCOR</Cd>
            </CdOrPrtry>
          </Tp>
          <Ref>43216</Ref>
        </CdtrRefInf>
      </Strd>
    </RmtInf>
    <RltdDts>
      <AccptncDtTm>2010-10-29T09:00:00.000000+02:00</AccptncDtTm>
    </RltdDts>
  </TxDtls>
</NtryDtls>'));
