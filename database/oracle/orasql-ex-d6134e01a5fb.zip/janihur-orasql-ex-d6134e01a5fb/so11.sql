/* Replace iteration's fetch to BULK COLLECT

An answer to SO question:

http://stackoverflow.com/q/7605660

*/

create or replace type someobj_o as object
(
  name varchar2(75),
  enroll_date date,
  id number(12)
);
/

create or replace type someobj_t is table of someobj_o;
/

create table someobj_table of someobj_o;

insert into someobj_table values(someobj_o('Joe', current_date, 100));
insert into someobj_table values(someobj_o('Jack', current_date, 101));
insert into someobj_table values(someobj_o('John', current_date, 102));

column name format a10
select * from someobj_table;

declare
  v_objs someobj_t;
begin
  select someobj_o(name, enroll_date, id)
    bulk collect into v_objs
    from someobj_table;

  dbms_output.put_line('number of objects in a collection = ' || v_objs.count);
end;
/

declare
  type objcur_t is ref cursor;
  v_objcur objcur_t;
  v_objs someobj_t;
begin
  open v_objcur for
    select someobj_o(name, enroll_date, id)
    from someobj_table;

  fetch v_objcur bulk collect into v_objs;
  
  close v_objcur;

  dbms_output.put_line('number of objects in a collection = ' || v_objs.count);
end;
/

drop table someobj_table;
drop type someobj_t;
drop type someobj_o;

quit
