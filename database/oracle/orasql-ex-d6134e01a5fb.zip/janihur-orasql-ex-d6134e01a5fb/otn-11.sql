-- From OTN:
-- http://forums.oracle.com/forums/thread.jspa?threadID=2251556
-- See the thread - there's more than in this example !

set long 500

with x as (select xmltype('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Main xmlns="http://www.abc.org.com/FormDetails">
<abcd first="1" second="2"/>
<Fruits>
<fruit name="banana" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="grape" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="banana" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="grape" color="green"/>
<fruit name="orange" color="orange"/>
<fruit name ="lemon" color="yellow"/>
</Fruits>
<Fruits>
<fruit name="banana" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="grape" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="banana" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="grape" color="green"/>
<fruit name="orange" color="orange"/>
<fruit name ="lemon" color="yellow"/>
</Fruits>
<Fruits>
<fruit name="banana" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="grape" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="banana" color="green"/>
<fruit name="apple" color="red"/>
<fruit name="grape" color="green"/>
<fruit name="orange" color="orange"/>
<fruit name ="lemon" color="yellow"/>
</Fruits>
</Main>') object_value from dual)
select
  xmlquery('declare default element namespace "http://www.abc.org.com/FormDetails"; (: :)

(: fn:count($doc/Main/Fruits/fruit/@name) :)

(: for $f in fn:distinct-values($doc/Main/Fruits/fruit/@name) return fn:concat($f, "X") :)

(: for $f in fn:distinct-values($doc/Main/Fruits/fruit/@name) return fn:concat($f, " = ", $f/../@color) :)

(: Works fine ! :)
fn:string-join(
  let $fruits := $doc/Main/Fruits/fruit
  for $name in fn:distinct-values($fruits/@name)
  let $color := $fruits[@name=$name][1]/@color
  return fn:concat($name, " = ", $color),
"|")'
           passing x.object_value as "doc"
           returning content)
from x;
