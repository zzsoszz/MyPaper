-- How to add whitespace between xquery expressions in xml

set long 2000

with xmldata as (
select xmltype('<errors><error><company>Acme Ltd</company><country>DE</country><program>Global</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error></errors>')
data_ from dual)
select xmlquery('
<html>
  <body>
    <h1>Data</h1>
    <table>
      <tbody>
      {
        for $i in $doc/errors/error 
        return
        <tr>
          <td>1: {data($i/company)} ({data($i/country)})</td>
          <td>2: {data($i/company), data($i/country)}</td>
          <!-- put whitespace to an own xquery expression -->
          <td>3: {data($i/company)}{" "}{data($i/country)}</td>
        </tr>
      }
      </tbody>
    </table>
  </body>
</html>
' passing data_ as "doc" returning content) as html
from xmldata
;
