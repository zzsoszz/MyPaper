create table data_t (
  id number,
  org_id number,
  data1 varchar2(10)
);

insert all
into data_t values (1, 1, 'foo')
into data_t values (2, 1, 'bar')
into data_t values (3, 2, 'FOO')
into data_t values (4, 2, 'BAR')
select 1 from dual;

create table org_t (
  id number,
  org_id number,
  org_code varchar2(3)
);

insert all
into org_t values(1, 100, 'low')
into org_t values(2, 200, 'up')
select 1 from dual;

create or replace view org_data_v ( org_id, org_code, data1, curr_date )
as
-- with-statement can be used in create view and shared over union
with curr_date as (select trunc(sysdate) from dual)
select o.org_id, o.org_code, d.data1, (select * from curr_date)
from data_t d
inner join org_t o on o.id = d.org_id
union
select 2, 'XXX', 'UNION2', (select * from curr_date) from dual
;

select * from org_data_v;

drop view org_data_v;
drop table org_t;
drop table data_t;
