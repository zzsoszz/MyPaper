create table orders_table of xmltype
(unique ("XMLDATA"."fileid"))
xmltype store as object relational
xmlschema "schema.xsd"
element "orders";

create or replace view order_batches_view as
select xml.*
from orders_table,
     xmltable(
     '$doc/orders' passing orders_table.object_value as "doc"
     columns
     fileid varchar2(20) path 'fileid',
     order_date date path 'date',
     nbr_of_orders number path 'count(order)'
     ) xml;

create or replace view orders_view as
select (select x1.fileid || '-' || x2.ref from dual) as orderid,
       x2.orderer_name,
       x2.category,
       x2.nbr_of_items
from orders_table,
     xmltable(
     '$doc/orders' passing orders_table.object_value as "doc"
     columns
     fileid varchar2(20) path 'fileid',
     orders xmltype path 'order'
     ) x1,
     xmltable(
     '/order' passing x1.orders
     columns
     ref for ordinality,
     orderer_name varchar2(30) path 'string-join((orderer/firstname, orderer/lastname), " ")',
     category number path 'orderer/category',
     nbr_of_items number path 'count(items/item)'
     ) x2;

column fileid format a15
column orderid format a20
column orderer_name format a15
column category format 999
column nbr_of_items format 999

select * from orders_view order by orderid;

create or replace view order_items_view as
select (select x1.fileid || '-' || x2.ref from dual) as orderid,
       x3.*
from orders_table,
     xmltable(
     '$doc/orders' passing orders_table.object_value as "doc"
     columns
     fileid varchar2(20) path 'fileid',
     orders xmltype path 'order'
     ) x1,
     xmltable(
     '/order' passing x1.orders
     columns
     ref for ordinality,
     items xmltype path 'items/item'
     ) x2,
     xmltable(
     '/item' passing x2.items
     columns
     item_name varchar2(20) path 'name',
     item_id number path 'id'
     ) x3;

column item_name format a15
column item_id format 999

select * from order_items_view;

select o.orderid, o.orderer_name, i.item_name, i.item_id
from orders_view o
inner join order_items_view i on o.orderid = i.orderid
order by orderid, item_id;
