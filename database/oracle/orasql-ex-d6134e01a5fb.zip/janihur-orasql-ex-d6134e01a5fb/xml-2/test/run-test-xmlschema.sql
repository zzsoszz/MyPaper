-- Uses PL/SQL Commons from http://code.google.com/p/plsql-commons/

set linesize 80

spool run-test-xmlschema.log

@@../xmlschema.pks
show errors
@@../xmlschema.pkb
show errors

@@test-xmlschema.pks
show errors
@@test-xmlschema.pkb
show errors

exec plog.switchon(plog.log_test)
exec ptest.runtestsuite('TEST_XMLSCHEMA')

spool off
exit
