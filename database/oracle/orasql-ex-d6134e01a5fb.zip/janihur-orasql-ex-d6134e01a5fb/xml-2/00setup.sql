@@xmlschema.pks
show errors
@@xmlschema.pkb
show errors

exec XMLSCHEMA.register('JTEST', 'types.xsd');
exec XMLSCHEMA.register('JTEST', 'schema.xsd');

quit
