@xml-validator.pks
show errors
@xml-validator.pkb
show errors

declare
  fh nclob;
begin
  XML_VALIDATOR.unregister_schema('example.xsd');
  fh := XML_VALIDATOR.get_utf8_file('example.xsd');
  dbms_output.put_line('.xsd length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.register_schema('example.xsd', fh);
  dbms_lob.freetemporary(fh);

  fh := XML_VALIDATOR.get_utf8_file('example.xml');
  dbms_output.put_line('.xml length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.validate(fh, 'example.xsd');
  dbms_lob.freetemporary(fh);
end;
/

--drop package XML_VALIDATOR;

--quit
