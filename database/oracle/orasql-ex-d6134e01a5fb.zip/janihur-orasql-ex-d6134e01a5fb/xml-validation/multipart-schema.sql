@xml-validator.pks
show errors
@xml-validator.pkb
show errors

-- schemafile and xmlfile have to be on a server on a certain directory
-- expected by XML_VALIDATOR
declare
  schemafile varchar2(30);
  xmlfile constant varchar2(30) := 'multipart-schema.xml';
  fh nclob;
begin
  -- note the order as the schemas have dependencies
  XML_VALIDATOR.unregister_schema('multipart-schema-3.xsd');
  XML_VALIDATOR.unregister_schema('multipart-schema-2.xsd');
  XML_VALIDATOR.unregister_schema('multipart-schema-1.xsd');

  schemafile := 'multipart-schema-1.xsd';
  fh := XML_VALIDATOR.get_utf8_file(schemafile);
  dbms_output.put_line('.xsd length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.register_schema(schemafile, fh);
  dbms_lob.freetemporary(fh);

  schemafile := 'multipart-schema-2.xsd';
  fh := XML_VALIDATOR.get_utf8_file(schemafile);
  dbms_output.put_line('.xsd length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.register_schema(schemafile, fh);
  dbms_lob.freetemporary(fh);

  schemafile := 'multipart-schema-3.xsd';
  fh := XML_VALIDATOR.get_utf8_file(schemafile);
  dbms_output.put_line('.xsd length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.register_schema(schemafile, fh);
  dbms_lob.freetemporary(fh);

  fh := XML_VALIDATOR.get_utf8_file(xmlfile);
  dbms_output.put_line('.xml length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.validate(fh, schemafile);
  dbms_lob.freetemporary(fh);

end;
/
