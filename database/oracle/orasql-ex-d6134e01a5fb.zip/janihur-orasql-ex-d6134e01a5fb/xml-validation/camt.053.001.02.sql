@xml-validator.pks
show errors
@xml-validator.pkb
show errors

-- schemafile and xmlfile have to be on a server on a certain directory
-- expected by XML_VALIDATOR
declare
  schemafile constant varchar2(30) := 'camt.053.001.02.xsd';
  xmlfile constant varchar2(30) := 'camt.053.001.02.xml';
  fh nclob;
begin
  XML_VALIDATOR.unregister_schema(schemafile);

  fh := XML_VALIDATOR.get_utf8_file(schemafile);
  dbms_output.put_line('.xsd length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.register_schema(schemafile, fh);
  dbms_lob.freetemporary(fh);

  fh := XML_VALIDATOR.get_utf8_file(xmlfile);
  dbms_output.put_line('.xml length = ' || dbms_lob.getlength(fh));
  XML_VALIDATOR.validate(fh, schemafile);
  dbms_lob.freetemporary(fh);
end;
/
