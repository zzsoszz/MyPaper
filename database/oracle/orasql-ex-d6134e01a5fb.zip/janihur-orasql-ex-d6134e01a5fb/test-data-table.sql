--
-- How to create a big test data table quickly
--

create table test_data as
select rownum as id, 
       'This is a row #' || rownum as str,
       current_timestamp(3) as time_
from dual
connect by level <= 100;

column id format 999
column str format a20
column time_ format a30
