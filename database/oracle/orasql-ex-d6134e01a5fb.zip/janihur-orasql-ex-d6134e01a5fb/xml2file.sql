/* An example how to write XML data into a file.

See also: http://www.liberidu.com/blog/?p=365

*/

set define off

create table myxml_test (
  data varchar2(80)
);

insert into myxml_test values ('Äijö on kova äijä');
insert into myxml_test values ('à la carte apéritif');
insert into myxml_test values ('Belle Époque');

select * from myxml_test;

create or replace package myxml as

  type error_t is record (
    error boolean not null := false,
    text varchar(32767)
  );

  function xml2file(p_xml in xmltype, p_filename in varchar2) return error_t;
  function xmlgen return xmltype;

  -- http://www.lipsum.com/
  -- 2002 characters
  lorem2k constant clob := 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc pulvinar, est blandit luctus dignissim, dui turpis dignissim tortor, eu imperdiet mi felis eget lectus. Proin vehicula, nunc at mollis tempus, lacus tellus blandit quam, in suscipit justo massa quis purus. Quisque enim mauris, egestas dapibus scelerisque sit amet, ullamcorper at tortor. Fusce fermentum adipiscing lectus, id aliquam nulla suscipit non. Sed mollis ligula sed diam sollicitudin eget pharetra erat vestibulum. Nunc ut porttitor sapien. Etiam diam arcu, pulvinar vitae pulvinar sit amet, adipiscing in eros. Sed consectetur lobortis auctor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam aliquet convallis lorem, nec viverra velit adipiscing in. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean congue, risus eu tristique posuere, nibh tellus auctor tortor, non blandit orci enim ac est. Nunc scelerisque viverra leo sit amet elementum. Nam neque justo, fringilla ut suscipit imperdiet, iaculis at lacus. Sed et commodo erat. Sed fermentum tristique tellus, id facilisis enim hendrerit nec. Morbi gravida neque non eros rhoncus vel commodo eros pellentesque. Nullam ullamcorper fermentum placerat. Sed sem nunc, egestas quis accumsan in, hendrerit ac nunc. Nulla vestibulum, quam et viverra tincidunt, velit nisi laoreet lorem, nec facilisis orci velit at tortor. Nullam vehicula, turpis id iaculis ultricies, urna sapien hendrerit metus, at rhoncus turpis sem nec diam. Pellentesque in elit et tellus mattis cursus et at turpis. Nunc luctus feugiat tellus, euismod aliquam dolor auctor quis. Nulla in dolor vitae arcu fringilla mattis ac rhoncus eros. Praesent pretium eros justo. Aliquam tincidunt, mi eget facilisis condimentum, tellus augue ultricies metus, vitae ultricies purus leo sit amet neque. Vestibulum malesuada aliquet commodo. Nulla mattis laoreet sem, eu condimentum lorem elementum sit amet. Sed id nunc quis magna facilisis elementum metus.';

end;
/
show errors

create or replace package body myxml as

  function xml2file(p_xml in xmltype, p_filename in varchar2) return error_t as
    v_err error_t;
    v_doc dbms_xmldom.domdocument;
  begin
    v_doc := dbms_xmldom.newdomdocument(p_xml); 
    dbms_xmldom.writetofile(v_doc, p_filename, 'UTF-8');
    return v_err;
  exception
    when others then
      v_err.error := true;
      v_err.text := sqlerrm || chr(10) || 'UNK-00000: at "MYXML.XML2FILE"';
      return v_err;
  end;

  function xmlgen return xmltype as
    v_lorems xmltype;
    v_xml xmltype;
  begin
    select xmlagg(xmlelement("lorem",
			     xmlattributes(rownum as "id"),
			     lorem2k || lorem2k || lorem2k))
      into v_lorems from dual connect by level <= 1000;
    
    select xmlelement("root",
		      xmlelement("chars", 'foo & bar <> "Bar Hemingway''s"'),
		      (select xmlagg(xmlelement("data", m.data))
		         from myxml_test m),
		      v_lorems
		      )
      into v_xml from dual;
    return v_xml;
  end;

end;
/
show errors

declare
  v_err myxml.error_t;
begin
  -- assumes directory object JTEST
  v_err := myxml.xml2file(myxml.xmlgen, 'JTEST/file.xml');
  if v_err.error then
    dbms_output.put_line('Error details: ' || chr(10) || v_err.text);
  end if;
end;
/

drop package myxml;
drop table myxml_test;

quit
