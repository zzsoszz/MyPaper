/* XQuery examples

   http://en.wikibooks.org/wiki/XQuery

   http://en.wikibooks.org/wiki/XQuery/Filtering_Nodes
*/

set long 500

with x as (select xmltype('<header><a></a><b></b><c></c></header>') object_value from dual)
select xmlquery('
declare namespace local = "http://example.org"; (: :)
declare function local:apply($node as element())
{
  typeswitch ($node)
  case element(a) return <a>1</a>
  case element(b) return <b>2</b>
  case element(c) return <c>3</c>
  default return element {name($node)} {local:apply($node/*)}
}; (: :)
for $e in $doc/header/* return local:apply($e)
'
  passing x.object_value as "doc"
  returning content)
from x;

/* How to trim text nodes */

/* See OTN: http://forums.oracle.com/forums/thread.jspa?threadID=2252105 
for better implementation. */

with x as (select xmltype('<header>
  <a> 1 A </a>
  <b>   2 B </b>
  <c> 3 C   </c>
</header>') object_value from dual)
select xmlquery('
declare namespace local = "http://my.example.org"; (: :)
declare function local:strip($node as element())
{
  let $t := $node/text()
  let $t := ora:replace($t, "^ +", "-")
  let $t := ora:replace($t, " +$", "-")
  return element {fn:node-name($node)} {$t}
}; (: :)
for $e in $doc/header/* return local:strip($e)
'
  passing x.object_value as "doc"
  returning content)
from x;

with x as (select xmltype('<House>
<Refrigirator> Whirlpool </Refrigirator>
<WashingMachine> Samsung</WashingMachine>
<TV> Samsun TV </TV>
<cooler> L G </cooler>
</House>') object_value from dual)
select xmlquery('
declare namespace local = "http://my.example.org"; (: :)
declare function local:strip($node as element())
{
  let $t := $node/text()
  let $t := ora:replace($t, "^ +", "")
  let $t := ora:replace($t, " +$", "")
  return element {fn:node-name($node)} {$t}
}; (: :)
for $e in $doc/House/* return local:strip($e)
'
  passing x.object_value as "doc"
  returning content) as "Stripped"
from x;

/*
with x as (select xmltype('<header><a> 1 A </a><b>   2 B </b><c> 3 C   </c></header>') object_value from dual)
select xmlquery('
declare namespace local = "http://example.org"; (: :)
declare function local:apply($node as element())
{
  typeswitch ($node)
  case element() return element {fn:node-name($node)} {ora:replace($node/text(), "^ +", "D")}
  case element(b) return <b>2</b>
  default return element {name($node)} {local:apply($node/*)}
}; (: :)
for $e in $doc/header/* return local:apply($e)
'
           passing x.object_value as "doc"
           returning content)
from x;
*/
/*
with x as (select xmltype('<House>
<Refrigirator> Whirlpool </Refrigirator>
<WashingMachine> Samsung</WashingMachine>
<TV> Samsun TV </TV>
<cooler> L G </cooler>
</House>') object_value from dual)
select xmlquery('
(: for $e in $doc return $e :)
(: for $e in $doc return fn:normalize-space($e) :)
declare function local:apply($node as element())
{
  typeswitch($node)
  case element(TV) return <TV>X</TV>
  default return element {name($node)} {local:apply($node/*)}
}; (: :)
local:apply($doc/*)
'
           passing x.object_value as "doc"
           returning content)
from x;
*/
/*
declare function local:apply($node as element())
{
  typeswitch ($node)
  case element(a) return <a>1</a>
  case element(b) return <b>2</b>
  case element(c) return <c>3</c>
  default return element {name($node)} {local:apply($node/*)}
}
*/

/*
fn:string-join(
for $e in $doc//text() return ora:replace($e, "^ +", "D"),
"|")
*/
--fn:replace(subject, pattern, replacement, flags)