declare
  type weekdays_t is table of varchar2(15);
  days1 weekdays_t := weekdays_t('Monday', 'Tuesday', 'Friday');

  procedure print_days(days in weekdays_t) as
  begin
    dbms_output.put_line('Weekdays has ' || days.count || ' days:');
    for i in days.first .. days.last loop
      dbms_output.put_line(days(i));
    end loop;
  end;
begin
  print_days(days1);

  days1.extend(1);
  days1(days1.last) := 'Saturday';

  print_days(days1);

  days1.delete(days1.last);
  days1.trim(1);

  print_days(days1);

  days1.trim(2);

  print_days(days1);
end;
/

/* Sorting: http://technology.amis.nl/blog/1217/sorting-plsql-collections-the-quite-simple-way-part-two-have-the-sql-engine-do-the-heavy-lifting */

-- can't be a local type as SQL statement is used in sorting
create or replace type dates_t is table of date;
/
show errors

declare
  dates dates_t := dates_t();
  dformat varchar2(21) := 'YYYY-MM-DD HH24:MI:SS';

  procedure print(heading in varchar2, dates in dates_t) as
  begin
    dbms_output.put_line(heading);
    for i in dates.first .. dates.last loop
      dbms_output.put_line(i || ' = ' || to_char(dates(i), dformat));
    end loop;
  end;
begin
  -- populate dates
  dates.extend(10);
  for i in 1 .. 10 loop
    dates(i) := to_date('2000-01-01 00:00:00', dformat) + floor(dbms_random.value(1, 10*365+1));
  end loop;

  print('unsorted:', dates);

  -- sort
  select cast(multiset(select * from table(dates) order by 1) as dates_t) into dates from dual;

  print('sorted ascending:', dates);

  select cast(multiset(select * from table(dates) order by 1 desc) as dates_t) into dates from dual;

  print('sorted descending:', dates);

end;
/

drop type dates_t;

declare
  type weekdays_t is table of varchar2(15);
  days weekdays_t;
begin
  -- at this point:
  -- ORA-06531: Reference to uninitialized collection
  days := weekdays_t();
  -- now it's ok
  dbms_output.put_line('days.count: ' || days.count);
  days := weekdays_t('Monday');
  dbms_output.put_line('days.count: ' || days.count);
end;
/