declare
  subtype bar_t is pls_integer;
  type bar_list_t is table of bar_t;
  type foo_list_t is table of bar_list_t index by pls_integer;
  v_foos foo_list_t;
  v_find_me constant pls_integer := 3;
begin
  v_foos(1) := bar_list_t(1,3,5,7,9);
  v_foos(2) := bar_list_t(0,2,4,6,8);

  for i in v_foos.first .. v_foos.last loop
    if v_find_me not member of v_foos(i) then
      dbms_output.put_line('value ' || v_find_me || ' is found from index ' || i);
    end if;
  end loop;
end;
/