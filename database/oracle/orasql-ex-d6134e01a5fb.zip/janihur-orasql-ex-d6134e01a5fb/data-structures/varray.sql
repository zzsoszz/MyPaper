declare
  type weekdays_t is varray(7) of varchar2(15);
  days1 weekdays_t := weekdays_t('Monday', 'Tuesday', 'Friday');

  procedure print_days(days in weekdays_t) as
  begin
    dbms_output.put_line('Weekdays has ' || days.count || ' days, but could have ' || days.limit || ':');
    for i in days.first .. days.last loop
      dbms_output.put_line(days(i));
    end loop;
  end;
begin
  print_days(days1);

  days1.extend(1);
  days1(days1.last) := 'Saturday';

  print_days(days1);

  days1.trim(2);

  print_days(days1);
end;
/