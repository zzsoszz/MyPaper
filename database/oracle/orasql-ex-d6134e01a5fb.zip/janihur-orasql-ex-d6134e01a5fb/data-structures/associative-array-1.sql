-- http://download.oracle.com/docs/cd/E11882_01/appdev.112/e17126/composites.htm#CHDEIDIC
declare
  type population is table of number index by varchar2(64);
  city_population population;
  i varchar2(64);

begin
  city_population('Smallville')  := 2000;
  city_population('Midland')     := 750000;
  city_population('Megalopolis') := 1000000;
 
  city_population('Smallville') := 2001;
 
  i := city_population.first;
 
  while i is not null loop
    dbms_output.put_line
      ('Population of ' || i || ' is ' || city_population(i));
    i := city_population.next(i);
  end loop;

  if city_population.exists('Gotham') then
    dbms_output.put_line
      ('Population of Gotham is ' || city_population('Gotham'));
  else
    dbms_output.put_line('No population data exists for Gotham.');
  end if;

end;
/

create or replace package population as
  subtype index_t is varchar2(64);
  type population_t is table of number index by index_t;

  procedure print(
    p in population_t
  );

end;
/

create or replace package body population as

  procedure print(
    p in population_t
  ) as
    city index_t := p.first;
  begin
    while city is not null loop
      dbms_output.put_line
      ('Population of ' || city || ' is ' || p(city));
      city := p.next(city);
    end loop;
  end;

end;
/

declare
  pop population.population_t;
begin
  pop('Fooville') := 123;
  pop('Bartown') := 758;

  population.print(pop);
end;
/
