--
-- An associative array of associative array.
--
declare
  subtype int_t is pls_integer range 1..10;
  subtype str_t is varchar2(64);

  type subdata_t is table of str_t index by int_t;
  type maindata_t is table of subdata_t index by str_t;

  adata subdata_t;

  thedata maindata_t;

  lang str_t;
  numb int_t;
begin
  thedata('swe')(1) := 'ett';
  thedata('swe')(6) := 'sex';

  thedata('eng')(5) := 'five';
  thedata('eng')(10) := 'ten';

  thedata('fra')(5) := 'cinq';
  thedata('fra')(10) := 'dix';

  thedata('eng')(5) := 'five'; -- duplicate doesn't matter

  lang := thedata.first;

  while lang is not null loop
    numb := thedata(lang).first;
    while numb is not null loop
      dbms_output.put_line('in lang ' || lang || ' numb ' || numb || ' is ' || thedata(lang)(numb));
      numb := thedata(lang).next(numb);
    end loop;
    lang := thedata.next(lang);
  end loop;

end;
/
