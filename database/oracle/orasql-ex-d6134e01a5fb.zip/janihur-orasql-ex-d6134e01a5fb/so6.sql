/* How to use PL/SQL- REGEXP_REPLACE to remove 0D from end of string?

Answer to SO question:
http://stackoverflow.com/questions/7003190/how-to-use-pl-sql-regexp-replace-to-remove-0d-from-end-of-string

*/

    /* PL/SQL */
    
    declare
      in_str constant varchar2(30) := 'foo' || chr(13) || 'bar' || chr(13);
      out_str varchar2(30);
    begin
      dbms_output.put_line('in_str = ' || utl_raw.cast_to_raw(in_str));
    
      select regexp_replace(in_str, chr(13) || '$', '') into out_str from dual;
    
      dbms_output.put_line('out_str = ' || utl_raw.cast_to_raw(out_str));
    end;
    /
    
    /* SQL */
    
    select utl_raw.cast_to_raw('foo' || chr(13) || 'bar' || chr(13)) as BEFORE from dual;
    
    select utl_raw.cast_to_raw(regexp_replace('foo' || chr(13) || 'bar' || chr(13), chr(13) || '$', '')) AS AFTER from dual;
