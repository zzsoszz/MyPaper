declare
  fh utl_file.file_type;
begin
  fh := utl_file.fopen_nchar('c:\data\talous', 'camt.053.001.02.xml', 'r');
  
  if utl_file.is_open(fh) then
    dbms_output.put_line('filehandle is opened');
  else
    dbms_output.put_line('filehandle is closed');
  end if;

  declare
    buf nvarchar2(32767);
    counter pls_integer := 1;
  begin
    loop
      utl_file.get_line_nchar(fh, buf);
      dbms_output.put_line('line ' || counter || ': ' || buf);
      counter := counter + 1;
    end loop;
  exception
    when no_data_found then null; -- all read
  end;

  utl_file.fseek(fh, 0);
  
  declare
    buf nclob;
    counter pls_integer := 1;
    buf2 nclob;
  begin
    loop
      utl_file.get_line_nchar(fh, buf);
      dbms_output.put_line('line ' || counter || ': ' || buf);
      counter := counter + 1;
      dbms_lob.append(buf2, buf);
    end loop;
  exception
    when no_data_found then
      null; -- all read
      dbms_output.put_line(buf2);
  end;
  
  utl_file.fclose(fh);

  if utl_file.is_open(fh) then
    dbms_output.put_line('filehandle is opened');
  else
    dbms_output.put_line('filehandle is closed');
  end if;

/* doesn't work
  declare
    fh utl_file.file_type := utl_file.fopen('c:\data\talous', 'camt.053.001.02.xml', 'r');
    buf raw(32767);
    buf2 nclob;
    doffset integer := 1;
    soffset integer := 1;
    lang_context integer := dbms_lob.default_lang_ctx;
    warning integer := dbms_lob.no_warning;
  begin
    loop
      utl_file.get_raw(fh, buf, 32767);
      dbms_lob.converttoclob(buf2, to_lob(buf), dbms_lob.lobmaxsize, doffset, soffset, dbms_lob.default_csid, lang_context, warning);
    end loop;
  exception
    when no_data_found then null; -- all read
  end;
*/
exception
  when utl_file.invalid_mode then
    dbms_output.put_line('exception: utl_file.invalid_mode');
    dbms_output.put_line('details: ' || sqlerrm);
    utl_file.fclose(fh);
  when utl_file.invalid_operation then
    dbms_output.put_line('exception: utl_file.invalid_operation');
    dbms_output.put_line('details: ' || sqlerrm);
    utl_file.fclose(fh);
  when others then
    dbms_output.put_line('exception: others');
    dbms_output.put_line('details: ' || sqlerrm);
    utl_file.fclose(fh);
end;
/
