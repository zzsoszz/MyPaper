-- http://thinkoracle.blogspot.com/2005/05/enum-in-oracle.html

create or replace package pkg_days
as
  -- PL/SQL set
  type days_t is table of varchar2(3);
  days days_t := days_t('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun');
end;
/

create or replace procedure is_valid_day(p_day in varchar2)
as
begin
  if p_day member of pkg_days.days
  then
    dbms_output.put_line(p_day || ' is a valid day.'); -- concat 1
  elsif not p_day member of pkg_days.days
  then
    dbms_output.put_line(concat(p_day, ' is an invalid day.')); -- concat 2
  else
    dbms_output.put_line('NULL is an invalid day.');
  end if;
end;
/

exec is_valid_day('Mon');
exec is_valid_day(123);
exec is_valid_day(null);

drop procedure is_valid_day;
drop package pkg_days;

-- http://www.petefinnigan.com/weblog/archives/00001246.htm

create or replace package pkg_colors as
  RED constant number(1) := 1;
  GREEN constant number(1) := 2;
  BLUE constant number(1) := 3;
  YELLOW constant number(1) := 4;

  VIOLET constant number(1) := 7;

  subtype colors is binary_integer range 1..4;

  function is_valid(v_color in number) return boolean;
  function is_valid_color(v_color in colors) return boolean;
end;
/

create or replace package body pkg_colors as
  function is_valid(v_color in number) return boolean
  as
    color colors;
  begin
    color := v_color;
    return true;
  exception
    when VALUE_ERROR then
      dbms_output.put_line(v_color || ' is an invalid value.');
      return false;
    when others then 
      dbms_output.put_line('Some other mysterious exception.');
      return false;
  end;

  function is_valid_color(v_color in colors) return boolean
  as
    color colors;
  begin
    color := v_color; -- throws if not in range
    return true;
  end;

end;
/

declare
  r boolean;
begin
  r := pkg_colors.is_valid(1);
  r := pkg_colors.is_valid_color(1);
  
  r := pkg_colors.is_valid(27);
  r := pkg_colors.is_valid_color(27); -- raises an exception
end;
/

exec if pkg_colors.is_valid_color(1) then null; end if;

drop package pkg_colors;
