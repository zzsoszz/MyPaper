/* Dynamically check if a variable has value in PL SQL

An answer to SO question: http://stackoverflow.com/q/8360352

This is essentially the same than APC's answer. I have just made the following modifications:

 - use default parameter values
 - use named parameters
 - separate null check logic into a dedicated procedure

*/

create table syscfg (
  procname varchar2(30) not null,
  varname varchar2(30) not null,
  mandatory varchar2(1) not null
);

insert all
into syscfg values('DO_SOMETHING', 'P_1', 'Y')
into syscfg values('DO_SOMETHING', 'P_2', 'Y')
into syscfg values('DO_SOMETHING', 'P_3', 'N')
into syscfg values('DO_SOMETHING_TWO', 'P_1', 'Y')
into syscfg values('DO_SOMETHING_TWO', 'P_2', 'Y')
into syscfg values('DO_SOMETHING_TWO', 'P_3', 'N')
into syscfg values('DO_SOMETHING_TWO', 'P_4', 'N')
into syscfg values('DO_SOMETHING_TWO', 'P_5', 'N')
select 1 from dual;

col procname for a20
col varname for a5
col mandatory for a1
select * from syscfg;

/* Supports only up to 5 parameters. */
create or replace procedure is_missing_mandatory_args (
  p_procname in varchar2,
  p_1 in varchar2 default null,
  p_2 in varchar2 default null,
  p_3 in varchar2 default null,
  p_4 in varchar2 default null,
  p_5 in varchar2 default null
) as
  args constant sys.dbms_debug_vc2coll :=
    sys.dbms_debug_vc2coll(p_1, p_2, p_3, p_4, p_5);
begin
  for r in ( select s.varname, a.position
             from syscfg s
             join user_arguments a 
             on (    s.procname = a.object_name
                 and s.varname = a.argument_name)
             where s.procname = upper(p_procname)
             and s.mandatory = 'Y' 
             order by a.position
           )
  loop
    if args(r.position) is null then
      raise_application_error(-20000, upper(p_procname) || '.' || r.varname
                              ||' cannot be null');       
    end if;        
  end loop;
end;
/
show errors

create or replace procedure do_something (
  p_1 in varchar2 default null,
  p_2 in varchar2 default null,
  p_3 in varchar2 default null
) as
begin
  is_missing_mandatory_args('do_something', p_1, p_2, p_3);
  /* The real work takes place here. */
  dbms_output.put_line('do_something() executed successfully !');
end;
/
show errors

create or replace procedure do_something_two (
  p_1 in varchar2 default null,
  p_2 in varchar2 default null,
  p_3 in varchar2 default null,
  p_4 in varchar2 default null,
  p_5 in varchar2 default null
) as
begin
  is_missing_mandatory_args('do_something_two', p_1, p_2, p_3, p_4, p_5);
  /* The real work takes place here. */
  dbms_output.put_line('do_something_two() executed successfully !');
end;
/
show errors

exec do_something(p_1 => 'foo', p_2 => 'foo');
exec do_something(p_2 => 'foo');
exec do_something(p_1 => 'foo');

exec do_something_two(p_2 => 'baz', p_1 => 'buz', p_5 => 'boz');
exec do_something_two(p_1 => 'baz');

drop procedure do_something_two;
drop procedure do_something;
drop procedure is_missing_mandatory_args;
drop table syscfg;

quit
