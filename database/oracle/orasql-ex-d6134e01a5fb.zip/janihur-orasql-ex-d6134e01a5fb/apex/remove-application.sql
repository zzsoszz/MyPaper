/* Taken from APEX generated application files. Removes application app_nbr
from security_group. */

declare
  /* One have to know these numbers */
  security_group constant number := 1292318753879060;
  app_nbr constant number := 133;
begin
  wwv_flow_api.set_security_group_id(security_group);
  
  wwv_flow.g_flow_id := nvl(wwv_flow_application_install.get_application_id,
			    app_nbr);
  
  wwv_flow_api.g_id_offset := nvl(wwv_flow_application_install.get_offset, 0);

  wwv_flow_api.remove_flow(nvl(wwv_flow_application_install.get_application_id,
			       app_nbr));

  wwv_flow_audit.remove_audit_trail(
    nvl(wwv_flow_application_install.get_application_id, app_nbr)
  );
end;
/
