/* Convert query from MySQL to Oracle using MATCH AGAINST

An answer to SO question: http://stackoverflow.com/q/18581527

*/

create table so32 as
select 1 as id, 'Lorem grand ipsum dolor sit amet, consectetur adipiscing elit. Cras faucibus.' as text from dual union all
select 2 as id, 'Lorem ipsum hotel dolor sit amet, consectetur adipiscing elit. Cras faucibus.' as text from dual union all
select 3 as id, 'Lorem ipsum dolor sit amet, grand consectetur adipiscing elit. Cras faucibus.' as text from dual union all
select 4 as id, 'Lorem ipsum dolor sit amet, consectetur hotel adipiscing elit. Cras faucibus.' as text from dual union all
select 5 as id, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit grand. Cras faucibus.' as text from dual union all
select 6 as id, 'Lorem ipsum dolor sit amet grand hotel, consectetur adipiscing elit. Cras faucibus.' as text from dual
;

create index so32_index on so32(text) indextype is ctxsys.context;

select id, 
       score(1) as grand,
       score(2) as hotel,
       score(3) as grandhotel
  from so32
 where contains(text, 'grand', 1) > 0
    or contains(text, 'hotel', 2) > 0
    or contains(text, 'grand hotel', 3) > 0
 order by score(3), score(2), score(1)
;

        ID      GRAND      HOTEL GRANDHOTEL
---------- ---------- ---------- ----------
         1          4          0          0
         3          4          0          0
         5          4          0          0
         4          0          4          0
         2          0          4          0
         6          4          4          4

6 rows selected.
