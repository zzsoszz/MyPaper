/* Checking for a Particular String Format in Oracle 11g

An answer to SO question: http://stackoverflow.com/q/22801433/272735

*/

with
data_ as (
  select 1 id, 'PWOOOE12s3' str from dual union
  select 2 id, 'PwoooE12s3' str from dual
)
select id, str from data_
where regexp_like(str, '^P[[:upper:]|[:digit:]]{4}[ED][[:digit:]]+')
;
