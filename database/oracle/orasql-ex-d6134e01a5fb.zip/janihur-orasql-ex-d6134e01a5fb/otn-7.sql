select banner as "Oracle version" from v$version where banner like 'Oracle%';

create table otn7test(
  id number,
  data xmltype
);

insert into otn7test values (1, xmltype('<catalog xmlns="http://cd.catalog.com">
<cd>
<title>Hide your heart</title>
<artist>Bonnie Tyler</artist>
<country>UK</country>
<company>CBS Records</company>
<price>9.90</price>
<year>1988</year>
</cd>
<cd>
<title>Empire Burlesque</title>
<artist>Bob Dylan</artist>
<country>USA</country>
<company>Columbia</company>
<price>10.90</price>
<year>1985</year>
</cd>
</catalog>
'));

column "#" format 999
column id format 999

select 1 as "#", otn7test.id, x.*
from otn7test,
     xmltable(xmlnamespaces(default 'http://cd.catalog.com'),
     '/catalog/cd[artist/text()="Bob Dylan"]' passing otn7test.data
     columns title varchar2(20) path 'title') x;

select 2 as "#", otn7test.id, x.*
from otn7test,
     xmltable(xmlnamespaces('http://cd.catalog.com' as "cdns"),
     '/cdns:catalog/cdns:cd[cdns:artist/text()="Bob Dylan"]' passing otn7test.data
     columns title varchar2(20) path 'cdns:title') x;

select 3 as "#", otn7test.id,
       xmlcast(xmlquery('declare default element namespace "http://cd.catalog.com"; (: :)
                         /catalog/cd[artist/text()="Bob Dylan"]/title' 
               passing otn7test.data returning content)
       as varchar2(20)) from otn7test;

drop table otn7test;

quit
