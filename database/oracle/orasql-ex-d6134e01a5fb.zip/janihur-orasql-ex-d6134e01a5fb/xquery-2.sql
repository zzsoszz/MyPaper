-- Convert XML to HTML with XQuery

set long 2000

with xmldata as (
select xmltype('<errors><error><company>Acme Ltd</company><country>DE</country><program>Global</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>PL</country><program>Global</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>DE</country><program>Global</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>PL</country><program>Global</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>DE</country><program>Global</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error><error><company>Acme Ltd</company><country>CZ</country><program>Partners (Central Europe)</program></error></errors>')
data_ from dual)
select xmlquery('
<html>
  <body>
    <h1>Errors</h1>
    <table>
      <tbody>
      {
        for $i in $doc/errors/error 
        return
        <tr>
          <td>{data($i/company)}</td>
          <td>{data($i/country)}</td>
          <td>{data($i/program)}</td>
        </tr>
      }
      </tbody>
    </table>
  </body>
</html>
' passing data_ as "doc" returning content) as html
from xmldata
;
