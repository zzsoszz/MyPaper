/* Custom type spanning as many columns as it has fields in a DML statement

Answer to SO question:
http://stackoverflow.com/questions/6948177/custom-type-spanning-as-many-columns-as-it-has-fields-in-a-dml-statement/6952646#6952646

I'm not sure what you are looking for as you very much list the alternatives and then refuse to use any of them without solid argumentation. I don't think any of them is messy (a matter of personal opinion) or inefficient (I don't have any profiling to prove that either).

There should be no problems to pass parameters to `myTypeFunction` and `anotherTypeFunction` in your examples.

This example will give you the output you were asking. `myTypeToTable` is independent of members of `myType`.

*/

    create or replace type myType as object(
      field1 number,
      field2 varchar2(20),
      field3 varchar2(20)
    );
    /
    
    create or replace function myTypeFunction(id in number default 1)
    return myType as
    begin
      return myType(id, 'field2 of id ' || id, 'field3 of id ' || id);
    end;
    /
    
    select myTypeFunction from dual;
    select myTypeFunction(67) from dual;
    
    create or replace type myTypeList as table of myType;
    /
    
    create or replace function myTypeFunction2(id in number default 1)
    return myTypeList pipelined as
    begin
      pipe row(myType(id, 'field2 of id ' || id, 'field3 of id ' || id));
      return;
    end;
    /
    
    select * from table(myTypeFunction2);
    
    create or replace function myTypeToTable(obj in myType)
    return myTypeList pipelined as
    begin
      pipe row(obj);
      return;
    end;
    /
    
    select * from table(myTypeToTable(myType(34, 'foo', 'and more foo')));
    
    drop function myTypeToTable;
    drop function myTypeFunction2;
    drop function myTypeFunction;
    drop type myTypeList;
    drop type myType;
