create or replace function get_namespace(elem in xmltype) return varchar2 as
begin
  return elem.getnamespace;
end;
/
show errors

create or replace function bool2str(b in boolean) return varchar2 as
begin
  case
    when b is null then return 'NULL';
    when b then return 'true';
    else return 'false';
  end case;
end;
/
show errors

create or replace function is_camt054(elem in xmltype) return boolean as
begin
  case elem.getnamespace
    when 'urn:iso:std:iso:20022:tech:xsd:camt.053.001.02' then return false;
    when 'urn:iso:std:iso:20022:tech:xsd:camt.054.001.02' then return true;
    else return null;
  end case;
end;
/
show errors

create or replace function is_camt054_sql(elem in xmltype) return number as
begin
  case elem.getnamespace
    when 'urn:iso:std:iso:20022:tech:xsd:camt.053.001.02' then return 0;
    when 'urn:iso:std:iso:20022:tech:xsd:camt.054.001.02' then return 1;
    else return null;
  end case;
end;
/
show errors

col id format 99
col NS format a50
col ER format 9
select id,
       is_camt054_sql(data) as ER,
       get_namespace(data) as NS
from xml_data order by id;

declare
  ns varchar2(32676);
begin
  for rec in (select id, data from xml_data order by id) loop
    ns := get_namespace(rec.data);
    dbms_output.put_line('id = ' || rec.id ||
			 ' er = ' || bool2str(is_camt054(rec.data)) ||
			 ' ns = ' || ns);
  end loop;
end;
/

declare
  type rec_t is record (
    acctsvcrref varchar2(35),
    amt number,
    ccy varchar2(3)
  );
  rec rec_t;

  cur sys_refcursor;
begin
  for ntry in (select * from xml_data order by id) loop

    /* XMLNAMESPACES expects XQuery string literal. Therefore an own cursor
    for each namespace. A lot of redundant code but no idea how to eliminate
    it. Note that the return structure is compatible with record rect_t. */

    declare
      ns constant varchar2(32767) := get_namespace(ntry.data);
    begin
      case ns
	when 'urn:iso:std:iso:20022:tech:xsd:camt.053.001.02' then
	  open cur for select nvl(acctsvcrref, 'N/A'), amt, ccy from
	    xmltable(xmlnamespaces(default
				   'urn:iso:std:iso:20022:tech:xsd:camt.053.001.02'),
		     'NtryDtls/TxDtls' passing ntry.data
		     columns
		     acctsvcrref varchar2(35) path 'Refs/AcctSvcrRef',
		     amt number path 'AmtDtls/TxAmt/Amt',
		     ccy varchar2(3) path 'AmtDtls/TxAmt/Amt/@Ccy');
	when 'urn:iso:std:iso:20022:tech:xsd:camt.054.001.02' then
	  open cur for select nvl(acctsvcrref, 'N/A'), amt, ccy from
	    xmltable(xmlnamespaces(default
				   'urn:iso:std:iso:20022:tech:xsd:camt.054.001.02'),
		     'NtryDtls/TxDtls' passing ntry.data
		     columns
		     acctsvcrref varchar2(35) path 'Refs/AcctSvcrRef',
		     amt number path 'AmtDtls/TxAmt/Amt',
		     ccy varchar2(3) path 'AmtDtls/TxAmt/Amt/@Ccy');
      end case;
    end;

    fetch cur into rec;
    while cur%found loop
      dbms_output.put_line('id = ' || ntry.id ||
			   ' acctsvcrref = ' || rec.acctsvcrref ||
			   ' amt = ' || rec.amt || ' ' || rec.ccy);
      fetch cur into rec;
    end loop;

    close cur;
    
  end loop;
end;
/
