/* Posted to OTN:
   http://forums.oracle.com/forums/thread.jspa?threadID=2245985
*/

/* A view over XML that is not 1:1

I'm going to provide a simple view over a rather complex XML structure. For
the view it makes sense (to the legacy application) to split and join some XML
elements. But how to do it ? This seems to be impossible with a plain
xmltable(). Do I have to resort to separate xmlquery() function calls for
those items I need to manipulate ? How to do it ?

I'm running Oracle 11gR2 (11.2.0.1.0) */

create table otn4test(
  id number,
  data xmltype
);

insert into otn4test values (1, xmltype('
<root>
  <elem>
    <code>123descriptivetext</code>
    <issuer>abcd</issuer>
  </elem>
  <elem>
    <code>124descriptivetext</code>
    <issuer>efgh</issuer>
  </elem>
</root>'));

create or replace view otn4view as
select
t.data.extract('/root/elem/code/text()') code
from otn4test t;

/* this works fine as expected */

create or replace view otn4view as
select x.*
from otn4test,
     xmltable('/root/elem' passing otn4test.data
     columns
     code varchar2(30) path 'code',
     issuer varchar2(4) path 'issuer'
     ) x;

select * from otn4view;

/* But how to

A) Split the output like:

CODE TEXT            ISSU
---- --------------- ----
123  descriptivetext abcd
124  descriptivetext efgh

B) Join the output like:

TEXT
-----------------------------------------------
code = 123 text = descriptivetext issuer = abcd
code = 124 text = descriptivetext issuer = efgh
*/

/* The answer */

column text format a10
column fulltext1 format a25
column fulltext2 format a25

select x.*
from otn4test,
     xmltable('/root/elem' passing otn4test.data
     columns
     code varchar2(3) path 'substring(code,1,3)',
     text varchar2(30) path 'substring(code,4)',
     issuer varchar2(4) path 'issuer',
     fulltext1 varchar2(72) path 'string-join(("code = ", substring(code,1,3), " text = ", substring(code,4), " issuer = ", issuer), "")',
     fulltext2 varchar2(72) path 'concat("code = ", substring(code,1,3), " text = ", substring(code,4), " issuer = ", issuer)'
     ) x;

drop view otn4view;
drop table otn4test;

quit
