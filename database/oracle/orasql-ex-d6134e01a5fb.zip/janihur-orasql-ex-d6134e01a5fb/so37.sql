/* PL/SQL: splitting numbers;

An answer to SO question: http://stackoverflow.com/q/22335342/272735

*/

create or replace function calc_length(
  start_time in number,
  finish_time in number
) return varchar2 is
  v_start_hours constant pls_integer :=
    floor(start_time / 100);
  v_start_minutes constant pls_integer :=
    start_time - (v_start_hours * 100);
  
  v_finish_hours constant pls_integer :=
    floor(finish_time / 100);
  v_finish_minutes constant pls_integer :=
    finish_time - (v_finish_hours * 100);

  v_start_time constant date :=
    to_date(v_start_hours, 'HH24') + (v_start_minutes / 1440);
  v_finish_time constant date :=
    to_date(v_finish_hours, 'HH24') + (v_finish_minutes / 1440);

  v_len_hours constant pls_integer :=
    extract(hour from (v_finish_time - v_start_time) day to second);
  v_len_minutes constant pls_integer :=
    extract(minute from (v_finish_time - v_start_time) day to second); 
begin
  -- dbms_output.put_line('v_start_time: ' || v_start_time);
  -- dbms_output.put_line(v_finish_time);
  -- v_len_hours := extract(hour from (v_finish_time - v_start_time) day to second);
  -- v_len_minutes := extract(minute from (v_finish_time - v_start_time) day to second); 
  return v_len_hours || ':' || v_len_minutes;
end;
/
show errors

col start_ for 99999
col finish for 99999
col length for a10

with data_ as (
  select 0000 as start_, 0127 finish from dual union
  select 0800,           1000        from dual union
  select 1000,           1038        from dual union
  select 1000,           1100        from dual union
  select 1000,           1145        from dual union
  select 1145,           1000        from dual union
  select 2345,           0115        from dual
)
select start_, finish, calc_length(start_, finish) as length from data_;
