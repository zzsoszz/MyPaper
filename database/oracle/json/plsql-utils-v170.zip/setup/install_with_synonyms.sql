
prompt Installing with synonyms...

@@install.sql
@@synonyms.sql

prompt Done installing with synonyms!

