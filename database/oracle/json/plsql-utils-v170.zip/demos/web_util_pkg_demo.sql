-- get domain name from email address

select web_util_pkg.get_email_domain('someone@somewhere.net')
from dual

