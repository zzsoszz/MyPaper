
The Alexandria Utility Library for PL/SQL
=========================================

This library is a collection of utility packages for PL/SQL,
as well as links to selected libraries hosted and maintained elsewhere.

For more details and the latest source code, see

  http://code.google.com/p/plsql-utils/

Also check out the "demos" folder for some examples.

This is (and will always be!) a work in progress... :-)

Regards,
Morten Braten
Chief Scribe of the Library 
http://ora-00001.blogspot.com

