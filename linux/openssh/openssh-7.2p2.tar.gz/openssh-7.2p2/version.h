/* $OpenBSD: version.h,v 1.76 2016/02/23 09:14:34 djm Exp $ */

#define SSH_VERSION	"OpenSSH_7.2"

#define SSH_PORTABLE	"p2"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
